package luckytnt.tnteffects;

import net.minecraft.server.level.ServerLevel;
import luckytnt.block.TrollTNTMk3Block;
import luckytnt.registry.BlockRegistry;
import luckytntlib.util.IExplosiveEntity;
import luckytntlib.util.explosions.IBlockExplosionCondition;
import luckytntlib.util.explosions.IForEachBlockExplosionEffect;
import luckytntlib.util.explosions.ImprovedExplosion;
import luckytntlib.util.tnteffects.PrimedTNTEffect;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.entity.Entity;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;

public class TrollTNTMk3Effect extends PrimedTNTEffect{

	@Override
	public void serverExplosion(IExplosiveEntity entity) {
		ImprovedExplosion explosion = new ImprovedExplosion(entity.getLevel(), (Entity)entity, entity.getPos(), 10);
		explosion.doBlockExplosion(new IBlockExplosionCondition() {
			
			@Override
			public boolean conditionMet(Level level, BlockPos pos, BlockState state, double distance) {
				return state.getBlock() instanceof TrollTNTMk3Block;
			}
		}, new IForEachBlockExplosionEffect() {
			
			@Override
			public void doBlockExplosion(Level level, BlockPos pos, BlockState state, double distance) {
				state.getBlock().wasExploded((ServerLevel)level, pos, explosion);
				level.setBlock(pos, Blocks.AIR.defaultBlockState(), 3);
			}
		});
	}
	
	@Override
	public Block getBlock() {
		return BlockRegistry.TROLL_TNT_MK3.get();
	}
	
	@Override
	public int getDefaultFuse(IExplosiveEntity entity) {
		return 1;
	}
}
