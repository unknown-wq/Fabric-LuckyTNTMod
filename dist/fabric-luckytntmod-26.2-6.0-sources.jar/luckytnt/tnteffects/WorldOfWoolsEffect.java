package luckytnt.tnteffects;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.joml.Math;
import org.joml.Vector3f;

import com.mojang.datafixers.util.Pair;

import luckytnt.event.LevelEvents;
import luckytnt.registry.BlockRegistry;
import luckytntlib.util.IExplosiveEntity;
import luckytntlib.util.explosions.ExplosionHelper;
import luckytntlib.util.explosions.IForEachBlockExplosionEffect;
import luckytntlib.util.tnteffects.PrimedTNTEffect;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.BaseCoralPlantTypeBlock;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.animal.sheep.Sheep;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.item.DyeColor;
import net.minecraft.core.BlockPos;
import net.minecraft.world.phys.AABB;
import net.minecraft.util.Mth;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.EntityTypes;

public class WorldOfWoolsEffect extends PrimedTNTEffect {
	// TODO(port-26.2): DISABLED — the map-color→wool-shade classification uses ~60 yarn MapColor
	// constant names (WHITE, OFF_WHITE, IRON_GRAY, STONE_GRAY, PALE_YELLOW, EMERALD_GREEN,
	// BRIGHT_TEAL, DIAMOND_BLUE, WATER_BLUE, LAPIS_BLUE, ...) that have no verified 1:1 Mojang
	// mapping (Mojang uses SNOW / COLOR_* / TERRACOTTA_* / DEEPSLATE). The rest of the effect
	// (water/coral/seagrass/waterlogged/lava → glass & wool, rings, legs, sheep) is preserved.
	/*
	public static List<MapColor> WHITE = List.of(MapColor.WHITE, MapColor.OFF_WHITE, MapColor.TERRACOTTA_WHITE, MapColor.WHITE_GRAY);
	public static List<MapColor> LIGHT_GRAY = List.of(MapColor.IRON_GRAY, MapColor.LIGHT_BLUE_GRAY, MapColor.LIGHT_GRAY);
	public static List<MapColor> GRAY = List.of(MapColor.STONE_GRAY, MapColor.GRAY, MapColor.TERRACOTTA_CYAN, MapColor.DEEPSLATE_GRAY);
	public static List<MapColor> BLACK = List.of(MapColor.BLACK);
	public static List<MapColor> BROWN = List.of(MapColor.DIRT_BROWN, MapColor.OAK_TAN, MapColor.BROWN, MapColor.SPRUCE_BROWN, MapColor.TERRACOTTA_BLACK, MapColor.TERRACOTTA_BROWN, MapColor.TERRACOTTA_GRAY, MapColor.TERRACOTTA_LIGHT_GRAY, MapColor.RAW_IRON_PINK);
	public static List<MapColor> RED = List.of(MapColor.BRIGHT_RED, MapColor.RED, MapColor.DARK_RED, MapColor.TERRACOTTA_RED, MapColor.DULL_RED, MapColor.DARK_CRIMSON, MapColor.TERRACOTTA_PINK);
	public static List<MapColor> ORANGE = List.of(MapColor.ORANGE, MapColor.TERRACOTTA_ORANGE);
	public static List<MapColor> YELLOW = List.of(MapColor.PALE_YELLOW, MapColor.YELLOW, MapColor.GOLD, MapColor.TERRACOTTA_YELLOW);
	public static List<MapColor> LIME = List.of(MapColor.PALE_GREEN, MapColor.LIME, MapColor.EMERALD_GREEN, MapColor.LICHEN_GREEN);
	public static List<MapColor> GREEN = List.of(MapColor.DARK_GREEN, MapColor.GREEN, MapColor.TERRACOTTA_LIME, MapColor.TERRACOTTA_GREEN);
	public static List<MapColor> CYAN = List.of(MapColor.CYAN, MapColor.TEAL, MapColor.DARK_AQUA, MapColor.BRIGHT_TEAL);
	public static List<MapColor> LIGHT_BLUE = List.of(MapColor.PALE_PURPLE, MapColor.LIGHT_BLUE, MapColor.DIAMOND_BLUE);
	public static List<MapColor> BLUE = List.of(MapColor.WATER_BLUE, MapColor.BLUE, MapColor.LAPIS_BLUE, MapColor.TERRACOTTA_LIGHT_BLUE);
	public static List<MapColor> PURPLE = List.of(MapColor.PURPLE, MapColor.TERRACOTTA_BLUE, MapColor.DARK_DULL_PINK);
	public static List<MapColor> MAGENTA = List.of(MapColor.MAGENTA, MapColor.TERRACOTTA_MAGENTA, MapColor.TERRACOTTA_PURPLE, MapColor.DULL_PINK);
	public static List<MapColor> PINK = List.of(MapColor.PINK);
	*/

	@Override
	public void serverExplosion(IExplosiveEntity ent) {
		List<Pair<BlockPos, Block>> blocks = new ArrayList<>();
		
		ExplosionHelper.doSphericalExplosion(ent.getLevel(), ent.getPos(), 100, new IForEachBlockExplosionEffect() {
			
			@Override
			public void doBlockExplosion(Level level, BlockPos pos, BlockState state, double distance) {
				// TODO(port-26.2): DISABLED — map-color→wool-shade classification (see field block above).
				/*
				MapColor color = state.getMapColor(level, pos);
				if(color != MapColor.CLEAR & !state.getCollisionShape(level, pos, CollisionContext.empty()).isEmpty() && state.getBlock().getExplosionResistance() <= 200) {
					if(WHITE.contains(color)) {
						blocks.add(Pair.of(pos, Blocks.WHITE_WOOL));
					} else if(LIGHT_GRAY.contains(color)) {
						blocks.add(Pair.of(pos, Blocks.LIGHT_GRAY_WOOL));
					} else if(GRAY.contains(color)) {
						blocks.add(Pair.of(pos, Blocks.GRAY_WOOL));
					} else if(BLACK.contains(color)) {
						blocks.add(Pair.of(pos, Blocks.BLACK_WOOL));
					} else if(BROWN.contains(color)) {
						blocks.add(Pair.of(pos, Blocks.BROWN_WOOL));
					} else if(RED.contains(color)) {
						blocks.add(Pair.of(pos, Blocks.RED_WOOL));
					} else if(ORANGE.contains(color)) {
						blocks.add(Pair.of(pos, Blocks.ORANGE_WOOL));
					} else if(YELLOW.contains(color)) {
						blocks.add(Pair.of(pos, Blocks.YELLOW_WOOL));
					} else if(LIME.contains(color)) {
						blocks.add(Pair.of(pos, Blocks.LIME_WOOL));
					} else if(GREEN.contains(color)) {
						blocks.add(Pair.of(pos, Blocks.WOOL.green()));
					} else if(CYAN.contains(color)) {
						blocks.add(Pair.of(pos, Blocks.CYAN_WOOL));
					} else if(LIGHT_BLUE.contains(color)) {
						blocks.add(Pair.of(pos, Blocks.LIGHT_BLUE_WOOL));
					} else if(BLUE.contains(color)) {
						blocks.add(Pair.of(pos, Blocks.BLUE_WOOL));
					} else if(PURPLE.contains(color)) {
						blocks.add(Pair.of(pos, Blocks.PURPLE_WOOL));
					} else if(MAGENTA.contains(color)) {
						blocks.add(Pair.of(pos, Blocks.MAGENTA_WOOL));
					} else if(PINK.contains(color)) {
						blocks.add(Pair.of(pos, Blocks.PINK_WOOL));
					}
				}
				*/

				if((state.is(Blocks.WATER) || state.is(Blocks.BUBBLE_COLUMN) || state.getBlock() instanceof BaseCoralPlantTypeBlock) && state.getBlock().getExplosionResistance() <= 200) {
					blocks.add(Pair.of(pos, Blocks.STAINED_GLASS.blue()));
				}
				
				if(state.getBlock() == Blocks.SEAGRASS || state.getBlock() == Blocks.TALL_SEAGRASS || state.getBlock() == Blocks.KELP || state.getBlock() == Blocks.SEA_PICKLE || state.getBlock() == Blocks.KELP_PLANT) {
					blocks.add(Pair.of(pos, Blocks.WOOL.green()));
				}
				
				if(state.hasProperty(BlockStateProperties.WATERLOGGED) && state.getValue(BlockStateProperties.WATERLOGGED) && state.getBlock().getExplosionResistance() <= 200) {
					blocks.add(Pair.of(pos, Blocks.STAINED_GLASS.blue()));
				}
				
				if(state.is(Blocks.LAVA) && state.getBlock().getExplosionResistance() <= 200) {
					blocks.add(Pair.of(pos, Blocks.STAINED_GLASS.orange()));
				}
			}
		});
		
		for(Pair<BlockPos, Block> pair : blocks) {
			ent.getLevel().setBlock(pair.getFirst(), pair.getSecond().defaultBlockState(), 3);
		}
		
		for(int i = 0; i < 3 + new Random().nextInt(6); i++) {
			int x = new Random().nextInt(151) - 75;
			int z = new Random().nextInt(151) - 75;
			
			BlockPos origin = new BlockPos(Mth.floor(ent.x() + x), Mth.floor(LevelEvents.getTopBlock(ent.getLevel(), ent.x() + x, ent.z() + z, true) + 1), Mth.floor(ent.z() + z));
			boolean xOrZ = new Random().nextBoolean();
			int rr = 16 + new Random().nextInt(11);
			Block block = Blocks.CONCRETE.red();
			
			for(int j = 0; j < 6; j++) {
				placeRing(ent, origin, block, rr, xOrZ);
				placeLegs(ent, origin, block, rr--, xOrZ);
				
				if(j == 0) {
					block = Blocks.CONCRETE.orange();
				} else if(j == 1) {
					block = Blocks.CONCRETE.yellow();
				} else if(j == 2) {
					block = Blocks.CONCRETE.lime();
				} else if(j == 3) {
					block = Blocks.CONCRETE.blue();
				} else if(j == 4) {
					block = Blocks.CONCRETE.purple();
				}
			}
		}
		
		for(int i = 0; i <= 60 + new Random().nextInt(21); i++) {
			Sheep sheep = new Sheep(EntityTypes.SHEEP, ent.getLevel());
			
			int x = new Random().nextInt(151) - 75;
			int z = new Random().nextInt(151) - 75;
			
			sheep.setPos(ent.x() + x, LevelEvents.getTopBlock(ent.getLevel(), ent.x() + x, ent.z() + z, true) + 1, ent.z() + z);
			sheep.finalizeSpawn((ServerLevel)ent.getLevel(), ((ServerLevel)ent.getLevel()).getCurrentDifficultyAt(toBlockPos(ent.getPos())), EntitySpawnReason.MOB_SUMMONED, null);
			ent.getLevel().addFreshEntity(sheep);
		}
		
		BlockPos min = toBlockPos(ent.getPos()).offset(100, 100, 100);
		BlockPos max = toBlockPos(ent.getPos()).offset(-100, -100, -100);
		List<Sheep> list = ent.getLevel().getEntitiesOfClass(Sheep.class, new AABB(min.getX(), min.getY(), min.getZ(), max.getX(), max.getY(), max.getZ()));
		for(Sheep sheep : list) {
			sheep.setColor(randomColor());
		}
	}
	
	@Override
	public void spawnParticles(IExplosiveEntity ent) {
		for(int i = 0; i < 50; i++) {
			ent.getLevel().addParticle(new DustParticleOptions(((int)(20f*255)<<16)|((int)(20f*255)<<8)|(int)(20f*255), 1f), ent.x() + Math.random() * 2 - Math.random() * 2, ent.y() + 1D + Math.random() * 2 - Math.random() * 2, ent.z() + Math.random() * 2 - Math.random() * 2, 0, 0, 0);
		}
	}
	
	@Override
	public Block getBlock() {
		return BlockRegistry.WORLD_OF_WOOLS.get();
	}
	
	@Override
	public int getDefaultFuse(IExplosiveEntity ent) {
		return 150;
	}
	
	public DyeColor randomColor() {
		int random = new Random().nextInt(DyeColor.values().length);
		return DyeColor.values()[random];
	}
	
	public void placeRing(IExplosiveEntity ent, BlockPos origin, Block block, int radius, boolean xOrZ) {
		if(xOrZ) {
			for(int offX = -radius - 1; offX <= radius + 1; offX++) {
				for(int offY = 0; offY <= radius + 1; offY++) {
					BlockPos pos = origin.offset(offX, offY, 0);
					double distance = Math.sqrt(offX * offX + offY * offY);
					if(distance > radius && distance <= (radius + 1) && ent.getLevel().getBlockState(pos).getBlock().getExplosionResistance() <= 100) {
						ent.getLevel().setBlock(pos, block.defaultBlockState(), 3);
					}
				}
			}
		} else {
			for(int offZ = -radius - 1; offZ <= radius + 1; offZ++) {
				for(int offY = 0; offY <= radius + 1; offY++) {
					BlockPos pos = origin.offset(0, offY, offZ);
					double distance = Math.sqrt(offZ * offZ + offY * offY);
					if(distance > radius && distance <= (radius + 1) && ent.getLevel().getBlockState(pos).getBlock().getExplosionResistance() <= 100) {
						ent.getLevel().setBlock(pos, block.defaultBlockState(), 3);
					}
				}
			}
		}
	}
	
	public void placeLegs(IExplosiveEntity ent, BlockPos origin, Block block, int radius, boolean xOrZ) {
		if(xOrZ) {
			for(int offY = -1; offY > -200; offY--) {
				BlockPos pos = origin.offset(radius + 1, offY, 0);
				if(ent.getLevel().getBlockState(pos).getCollisionShape(ent.getLevel(), pos, CollisionContext.empty()).isEmpty() && ent.getLevel().getBlockState(pos).getBlock().getExplosionResistance() <= 100) {
					ent.getLevel().setBlock(pos, block.defaultBlockState(), 3);
				} else {
					break;
				}
			}
			
			for(int offY = -1; offY > -200; offY--) {
				BlockPos pos = origin.offset(-radius - 1, offY, 0);
				if(ent.getLevel().getBlockState(pos).getCollisionShape(ent.getLevel(), pos, CollisionContext.empty()).isEmpty() && ent.getLevel().getBlockState(pos).getBlock().getExplosionResistance() <= 100) {
					ent.getLevel().setBlock(pos, block.defaultBlockState(), 3);
				} else {
					break;
				}
			}
		} else {
			for(int offY = -1; offY > -200; offY--) {
				BlockPos pos = origin.offset(0, offY, radius + 1);
				if(ent.getLevel().getBlockState(pos).getCollisionShape(ent.getLevel(), pos, CollisionContext.empty()).isEmpty() && ent.getLevel().getBlockState(pos).getBlock().getExplosionResistance() <= 100) {
					ent.getLevel().setBlock(pos, block.defaultBlockState(), 3);
				} else {
					break;
				}
			}
			
			for(int offY = -1; offY > -200; offY--) {
				BlockPos pos = origin.offset(0, offY, -radius - 1);
				if(ent.getLevel().getBlockState(pos).getCollisionShape(ent.getLevel(), pos, CollisionContext.empty()).isEmpty() && ent.getLevel().getBlockState(pos).getBlock().getExplosionResistance() <= 100) {
					ent.getLevel().setBlock(pos, block.defaultBlockState(), 3);
				} else {
					break;
				}
			}
		}
	}
}
