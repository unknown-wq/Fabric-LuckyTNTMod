package luckytnt.tnteffects;

import net.minecraft.world.entity.EntitySpawnReason;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.Random;

import luckytnt.registry.BlockRegistry;
import luckytnt.registry.EntityRegistry;
import luckytntlib.entity.PrimedLTNT;
import luckytntlib.util.IExplosiveEntity;
import luckytntlib.util.tnteffects.PrimedTNTEffect;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.item.FallingBlockEntity;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.SoundSource;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.level.Level;

public class GrandeFinaleEffect extends PrimedTNTEffect {

	@Override
	public void serverExplosion(IExplosiveEntity ent) {
		
	}
	
	@Override
	public void explosionTick(IExplosiveEntity ent) {
		if(ent.getTNTFuse() % (int)(1 + Math.random() * 50) == 0) {
			PrimedLTNT entity = EntityRegistry.SAND_FIREWORK.get().create(ent.getLevel(), EntitySpawnReason.MOB_SUMMONED);
			int random = new Random().nextInt(4);
			switch(random){
				case 0: entity = EntityRegistry.SAND_FIREWORK.get().create(ent.getLevel(), EntitySpawnReason.MOB_SUMMONED); break;
				case 1: entity = EntityRegistry.GRAVEL_FIREWORK.get().create(ent.getLevel(), EntitySpawnReason.MOB_SUMMONED); break;
				case 2: entity = EntityRegistry.RAINBOW_FIREWORK.get().create(ent.getLevel(), EntitySpawnReason.MOB_SUMMONED);; break;
				case 3: entity = EntityRegistry.NEW_YEARS_FIREWORK.get().create(ent.getLevel(), EntitySpawnReason.MOB_SUMMONED);
						CompoundTag tag = entity.getPersistentData();
						tag.putInt("type", 1);
						entity.setPersistentData(tag); break;
			}
			ent.getLevel().playSound(null, toBlockPos(ent.getPos()), SoundEvents.FIREWORK_ROCKET_LAUNCH, SoundSource.MASTER, 3, 1);
			entity.setPos(ent.getPos());
			entity.setOwner(ent.owner());
			entity.setDeltaMovement(Math.random() * 5 - Math.random() * 5, 0, Math.random() * 5 - Math.random() * 5);
			entity.setTNTFuse(40 + new Random().nextInt(41));
			ent.getLevel().addFreshEntity(entity);
		}
		ent.getLevel().setBlock(toBlockPos(ent.getPos()), Blocks.AIR.defaultBlockState(), 3);
		ent.getLevel().setBlock(toBlockPos(ent.getPos()).offset(0, 1, 0), Blocks.AIR.defaultBlockState(), 3);
		if(ent.getTNTFuse() <= 40) {
			((Entity)ent).setDeltaMovement(((Entity)ent).getDeltaMovement().x, 1.6f, ((Entity)ent).getDeltaMovement().z);
			ent.getLevel().addParticle(ParticleTypes.LARGE_SMOKE, ent.x(), ent.y(), ent.z(), 0, -0.5f, 0);
			if(ent.getTNTFuse() == 0) {
				Block template = Blocks.CONCRETE.pick(DyeColor.WHITE);
				for(int count = 0; count < 1000; count++) {
					int rand = new Random().nextInt(12);
					switch (rand) {
						case 0: template = Blocks.CONCRETE.pick(DyeColor.RED); break;
						case 1: template = Blocks.CONCRETE.pick(DyeColor.GREEN); break;
						case 2: template = Blocks.CONCRETE.pick(DyeColor.BLUE); break;
						case 3: template = Blocks.CONCRETE.pick(DyeColor.YELLOW); break;
						case 4: template = Blocks.CONCRETE.pick(DyeColor.BROWN); break;
						case 5: template = Blocks.CONCRETE.pick(DyeColor.CYAN); break;
						case 6: template = Blocks.CONCRETE.pick(DyeColor.LIME); break;
						case 7: template = Blocks.CONCRETE.pick(DyeColor.PURPLE); break;
						case 8: template = Blocks.CONCRETE.pick(DyeColor.PINK); break;
						case 9: template = Blocks.CONCRETE.pick(DyeColor.MAGENTA); break;
						case 10: template = Blocks.CONCRETE.pick(DyeColor.ORANGE); break;
						case 11: template = Blocks.CONCRETE.pick(DyeColor.LIGHT_BLUE); break;
					}
					FallingBlockEntity block = null;
					try {
						@SuppressWarnings("rawtypes")
						Class[] classes = new Class[]{Level.class, double.class, double.class, double.class, BlockState.class};
						Constructor<FallingBlockEntity> constructor = FallingBlockEntity.class.getDeclaredConstructor(classes);
						constructor.setAccessible(true);
						block = constructor.newInstance(ent.getLevel(), ent.x(), ent.y(), ent.z(), template.defaultBlockState());
					} catch (NoSuchMethodException | SecurityException | InstantiationException | IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
						e.printStackTrace();
					}
					if(block != null) {
						block.dropItem = false;
						block.setDeltaMovement(Math.random() * 5f - Math.random() * 5f, Math.random() * 5f - Math.random() * 5f, Math.random() * 5f - Math.random() * 5f);
						ent.getLevel().addFreshEntity(block);
					}
				}
				for(int count = 0; count < 500; count++) {
					PrimedLTNT tnt = EntityRegistry.TNT.get().create(ent.getLevel(), EntitySpawnReason.MOB_SUMMONED);
					tnt.setOwner(ent.owner());
					tnt.setPos(ent.getPos());
					tnt.setTNTFuse(80 + (int)(Math.random() * 100));
					tnt.setDeltaMovement(Math.random() * 5f - Math.random() * 5f, Math.random() * 5f - Math.random() * 5f, Math.random() * 5f - Math.random() * 5f);
					ent.getLevel().addFreshEntity(tnt);
				}
			}
		}
	}
	
	@Override
	public Block getBlock() {
		return BlockRegistry.GRANDE_FINALE.get();
	}
	
	@Override
	public int getDefaultFuse(IExplosiveEntity ent) {
		return 440;
	}
}
