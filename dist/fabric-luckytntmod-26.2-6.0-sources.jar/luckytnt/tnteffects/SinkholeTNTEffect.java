package luckytnt.tnteffects;

import net.minecraft.server.level.ServerLevel;
import luckytnt.registry.BlockRegistry;
import luckytntlib.util.IExplosiveEntity;
import luckytntlib.util.explosions.ImprovedExplosion;
import luckytntlib.util.tnteffects.PrimedTNTEffect;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.entity.Entity;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.core.BlockPos;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;

public class SinkholeTNTEffect extends PrimedTNTEffect {

	@Override
	public void explosionTick(IExplosiveEntity ent) {
		if(ent.getTNTFuse() == 250) {
			CompoundTag tag = ent.getPersistentData();
			tag.putInt("depth", 20);
			ent.setPersistentData(tag);
		}
		if(ent.getTNTFuse() <= 150) {
			((Entity)ent).setDeltaMovement(Vec3.ZERO);
			((Entity)ent).setNoGravity(true);
		}
		if(ent.getTNTFuse() <= 150 && !ent.getLevel().isClientSide() && ent.getTNTFuse() % 2 == 0) {
			for(int offX = -33; offX <= 33; offX++) {
				for(int offY = -33; offY <= 33; offY++) {
					for(int offZ = -33; offZ <= 33; offZ++) {
						double distance = Math.sqrt(offX * offX + offY * offY + offZ * offZ) + Math.random() * 4D - 2D;
						BlockPos pos = new BlockPos(Mth.floor(ent.x() + offX), Mth.floor(ent.y() + offY + ent.getPersistentData().getIntOr("depth", 0)), Mth.floor(ent.z() + offZ));
						if(distance <= 30 && ent.getLevel().getBlockState(pos).getBlock().getExplosionResistance() < 200) {
							ent.getLevel().getBlockState(pos).getBlock().wasExploded((ServerLevel)ent.getLevel(), pos, ImprovedExplosion.dummyExplosion(ent.getLevel()));
							ent.getLevel().setBlock(pos, Blocks.AIR.defaultBlockState(), 3);
						}
					}
				}
			}
			
			CompoundTag tag = ent.getPersistentData();
			tag.putInt("depth", ent.getPersistentData().getIntOr("depth", 0) - 1);
			ent.setPersistentData(tag);
		}
	}
	
	@Override
	public Block getBlock() {
		return BlockRegistry.SINKHOLE_TNT.get();
	}
	
	@Override
	public int getDefaultFuse(IExplosiveEntity ent) {
		return 250;
	}
}
