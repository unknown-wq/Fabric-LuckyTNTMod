package luckytnt.tnteffects.projectile;

import java.util.Random;

import luckytnt.block.PresentBlock;
import luckytnt.config.LuckyTNTConfigValues;
import luckytnt.registry.BlockRegistry;
import luckytnt.util.BlockSurviveChecks;
import luckytntlib.util.IExplosiveEntity;
import luckytntlib.util.explosions.ExplosionHelper;
import luckytntlib.util.explosions.IForEachBlockExplosionEffect;
import luckytntlib.util.explosions.ImprovedExplosion;
import luckytntlib.util.tnteffects.PrimedTNTEffect;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.SnowLayerBlock;
import net.minecraft.world.entity.Entity;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.Level;

public class PresentMeteorEffect extends PrimedTNTEffect {
	
	@Override
	public void serverExplosion(IExplosiveEntity entity) {
		((ServerLevel)entity.getLevel()).sendParticles(ParticleTypes.WAX_OFF, entity.x(), entity.y() + 2, entity.z(), 500, 3f, 3f, 3f, 0f);
		Random random = new Random();
		if(LuckyTNTConfigValues.PRESENT_DROP_DESTROY_BLOCKS.get()) {
			ImprovedExplosion explosion = new ImprovedExplosion(entity.getLevel(), (Entity)entity, entity.getPos(), 40);
			explosion.doEntityExplosion(3, true);
			ExplosionHelper.doSphericalExplosion(entity.getLevel(), entity.getPos(), 40, new IForEachBlockExplosionEffect() {
				
				@Override
				public void doBlockExplosion(Level level, BlockPos pos, BlockState state, double distance) {
					if(distance <= (35) && state.getBlock().getExplosionResistance() <= 100) {
						state.getBlock().wasExploded((ServerLevel) level, pos, explosion);
						level.setBlock(pos, Blocks.AIR.defaultBlockState(), 3);
					}
					else if(!state.isAir() && Math.random() < 0.6f && state.getBlock().getExplosionResistance() <= 100) {
						state.getBlock().wasExploded((ServerLevel) level, pos, explosion);
						level.setBlock(pos, Blocks.AIR.defaultBlockState(), 3);
						if(Math.random() < 0.25f) {
							level.setBlockAndUpdate(pos, Math.random() < 0.5f ? Blocks.BLUE_ICE.defaultBlockState() : Blocks.PACKED_ICE.defaultBlockState());
						}
					}
				}
			});
		}
		ExplosionHelper.doTopBlockExplosionForAll(entity.getLevel(), entity.getPos(), 70, new IForEachBlockExplosionEffect() {
			
			@Override
			public void doBlockExplosion(Level level, BlockPos pos, BlockState state, double distance) {
				if(Math.random() < 0.025f) {
					Direction dir = Direction.NORTH;
					switch(random.nextInt(4)) {
						case 1: dir = Direction.EAST; break;
						case 2: dir = Direction.SOUTH; break;
						case 3: dir = Direction.WEST; break;
					}
					level.setBlockAndUpdate(pos, BlockRegistry.PRESENT.get().defaultBlockState().setValue(PresentBlock.FACING, dir).setValue(PresentBlock.TYPE, random.nextInt(4)));
				}
				else if(BlockSurviveChecks.canSnowPlaceAt(state, level, pos) && (distance < 60 || Math.random() < 0.7f)) {
					level.setBlockAndUpdate(pos, Blocks.SNOW.defaultBlockState().setValue(SnowLayerBlock.LAYERS, random.nextInt(1, 3)));
				}
			}
		});
	}
	
	@Override
	public void spawnParticles(IExplosiveEntity entity) {
		entity.getLevel().addParticle(ParticleTypes.SNOWFLAKE, entity.x(), entity.y() + 4, entity.z(), 0, 0, 0);
	}

	@Override
	public float getSize(IExplosiveEntity entity) {
		return 4;
	}

	@Override
	public BlockState getBlockState(IExplosiveEntity entity) {
		if(!entity.getPersistentData().getBooleanOr("has_present", false)) {
			CompoundTag tag = entity.getPersistentData();
			tag.putBoolean("has_present", true);
			tag.putInt("type", new Random().nextInt(4));
			entity.setPersistentData(tag);
		}
		return BlockRegistry.PRESENT.get().defaultBlockState().setValue(PresentBlock.TYPE, entity.getPersistentData().getIntOr("type", 0));
	}
}
