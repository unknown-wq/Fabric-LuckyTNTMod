package luckytnt.tnteffects.projectile;

import net.minecraft.world.entity.EntitySpawnReason;


import luckytnt.registry.EntityRegistry;
import luckytnt.registry.ItemRegistry;
import luckytntlib.entity.LExplosiveProjectile;
import luckytntlib.util.IExplosiveEntity;
import luckytntlib.util.explosions.ImprovedExplosion;
import luckytntlib.util.tnteffects.PrimedTNTEffect;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.Item;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.level.Level;

public class MultiplyingDynamiteEffect extends PrimedTNTEffect{

	@Override
	public void baseTick(IExplosiveEntity entity) {
		Level level = entity.getLevel();
		if(entity instanceof LExplosiveProjectile ent) {
			if(ent.inGround() && ent.getPersistentData().getIntOr("level", 0) >= 3 && level instanceof ServerLevel) {
				serverExplosion(ent);
				ent.destroy();
			}
			if(ent.getTNTFuse() == 0 && level instanceof ServerLevel) {
				serverExplosion(ent);
				ent.destroy();
			}
			if(ent.getPersistentData().getIntOr("level", 0) < 3) {
				explosionTick(ent);
				ent.setTNTFuse(ent.getTNTFuse() - 1);
			}
			if(level.isClientSide()) {
				spawnParticles(entity);
			}
		}
	}
	
	@Override
	public void serverExplosion(IExplosiveEntity entity) {
		Level level = entity.getLevel();
		if(entity.getPersistentData().getIntOr("level", 0) < 3) {	
			for(int count = 0; count < 4; count++) {
				LExplosiveProjectile dynamite = EntityRegistry.MULTIPLYING_DYNAMITE.get().create(entity.getLevel(), EntitySpawnReason.MOB_SUMMONED);
				dynamite.setPos(entity.getPos());
				dynamite.setOwner(entity.owner());
				dynamite.setDeltaMovement(((Entity)entity).getDeltaMovement().add(Math.random() * 0.5f - 0.25f, Math.random() * 0.5f - 0.25f, Math.random() * 0.5f - 0.25f));
				CompoundTag tag = dynamite.getPersistentData();
				tag.putInt("level", entity.getPersistentData().getIntOr("level", 0) + 1);
				dynamite.setPersistentData(tag);
				entity.getLevel().addFreshEntity(dynamite);
			}
		}
		else {
			ImprovedExplosion explosion = new ImprovedExplosion(entity.getLevel(), (Entity)entity, entity.getPos(), 8);
			explosion.doEntityExplosion(0.75f, true);
			explosion.doBlockExplosion(1f, 1f, 1f, 1.25f, false, false);
			level.playSound((Entity)entity, toBlockPos(entity.getPos()), SoundEvents.GENERIC_EXPLODE.value(), SoundSource.BLOCKS, 4f, (1f + (level.getRandom().nextFloat() - level.getRandom().nextFloat()) * 0.2f) * 0.7f);
		}
	}
	
	@Override
	public void explosionTick(IExplosiveEntity entity) {
		if(entity.getPersistentData().getIntOr("level", 0) < 3) {
			((Entity)entity).setDeltaMovement(((Entity)entity).getDeltaMovement().add(0f, 0.08f, 0f));
		}
	}
	
	@Override
	public Item getItem() {
		return ItemRegistry.MULTIPLYING_DYNAMITE.get();
	}
	
	@Override
	public int getDefaultFuse(IExplosiveEntity entity) {
		return 20;
	}
}
