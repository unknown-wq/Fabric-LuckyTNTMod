package luckytnt.registry;

import java.util.Collections;
import java.util.List;
import java.util.function.Predicate;
import java.util.function.Supplier;

import org.joml.Vector3f;

import luckytnt.LuckyTNTMod;
import luckytnt.block.entity.ItemFireworkBlockEntity;
import luckytnt.block.entity.SmokeTNTBlockEntity;
import luckytnt.entity.AngryMiner;
import luckytnt.entity.BouncingDynamite;
import luckytnt.entity.HailstoneProjectile;
import luckytnt.entity.OreTNTMinecart;
import luckytnt.entity.PrimedCustomFirework;
import luckytnt.entity.PrimedItemFirework;
import luckytnt.entity.PrimedOreTNT;
import luckytnt.entity.PrimedReplayTNT;
import luckytnt.entity.PrimedResetTNT;
import luckytnt.tnteffects.*;
import luckytnt.tnteffects.projectile.AcceleratingDynamiteEffect;
import luckytnt.tnteffects.projectile.AnimalDynamiteEffect;
import luckytnt.tnteffects.projectile.BigDynamiteEffect;
import luckytnt.tnteffects.projectile.BombEffect;
import luckytnt.tnteffects.projectile.ChemicalDynamiteEffect;
import luckytnt.tnteffects.projectile.ChicxulubMeteorEffect;
import luckytnt.tnteffects.projectile.ChristmasDynamiteEffect;
import luckytnt.tnteffects.projectile.ChristmasDynamiteProjectileEffect;
import luckytnt.tnteffects.projectile.ClusterBombEffect;
import luckytnt.tnteffects.projectile.ClusterDynamiteEffect;
import luckytnt.tnteffects.projectile.DeathRayRayEffect;
import luckytnt.tnteffects.projectile.DeimosMeteorEffect;
import luckytnt.tnteffects.projectile.DiggingDynamiteEffect;
import luckytnt.tnteffects.projectile.DisintegratingProjectileEffect;
import luckytnt.tnteffects.projectile.DynamiteFireworkEffect;
import luckytnt.tnteffects.projectile.EruptingDynamiteEffect;
import luckytnt.tnteffects.projectile.FloatingDynamiteEffect;
import luckytnt.tnteffects.projectile.GravityDynamiteEffect;
import luckytnt.tnteffects.projectile.HailstoneEffect;
import luckytnt.tnteffects.projectile.HomingDynamiteEffect;
import luckytnt.tnteffects.projectile.HydrogenBombBombEffect;
import luckytnt.tnteffects.projectile.IceMeteorDynamiteEffect;
import luckytnt.tnteffects.projectile.IceMeteorEffect;
import luckytnt.tnteffects.projectile.LightningDynamiteEffect;
import luckytnt.tnteffects.projectile.MeteorDynamiteEffect;
import luckytnt.tnteffects.projectile.MeteorEffect;
import luckytnt.tnteffects.projectile.MiniIceMeteorEffect;
import luckytnt.tnteffects.projectile.MiniMeteorEffect;
import luckytnt.tnteffects.projectile.MultiplyingDynamiteEffect;
import luckytnt.tnteffects.projectile.PhobosMeteorEffect;
import luckytnt.tnteffects.projectile.PresentMeteorEffect;
import luckytnt.tnteffects.projectile.PulseDynamiteEffect;
import luckytnt.tnteffects.projectile.RainbowDynamiteEffect;
import luckytnt.tnteffects.projectile.ReactionDynamiteEffect;
import luckytnt.tnteffects.projectile.RingDynamiteEffect;
import luckytnt.tnteffects.projectile.SensorDynamiteEffect;
import luckytnt.tnteffects.projectile.ShatterproofDynamiteEffect;
import luckytnt.tnteffects.projectile.ShrapnelEffect;
import luckytnt.tnteffects.projectile.SolarEruptionProjectileEffect;
import luckytnt.tnteffects.projectile.SpiralDynamiteEffect;
import luckytnt.tnteffects.projectile.TimerDynamiteEffect;
import luckytnt.tnteffects.projectile.TsarBombaBombEffect;
import luckytnt.tnteffects.projectile.TunnelingDynamiteEffect;
import luckytnt.tnteffects.projectile.UltralightDynamiteEffect;
import luckytnt.tnteffects.projectile.VacuumShotEffect;
import luckytnt.tnteffects.projectile.VredefortProjectileEffect;
import luckytntlib.entity.LExplosiveProjectile;
import luckytntlib.entity.LTNTMinecart;
import luckytntlib.entity.LivingPrimedLTNT;
import luckytntlib.entity.LuckyTNTMinecart;
import luckytntlib.entity.PrimedLTNT;
import luckytntlib.util.tnteffects.GeneralDynamiteEffect;
import luckytntlib.util.tnteffects.StackedPrimedTNTEffect;
import luckytntlib.util.tnteffects.TNTXStrengthEffect;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.ai.goal.OpenDoorGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.RandomStrollGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.util.ARGB;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.Registry;
import net.minecraft.resources.Identifier;
import net.minecraft.world.level.Level;

public class EntityRegistry {

	public static final TNTXStrengthEffect.Builder WEAK_TNT_EFFECT = new TNTXStrengthEffect.Builder().strength(2).knockbackStrength(0.5f);	
	public static final TNTXStrengthEffect.Builder TNT_EFFECT = new TNTXStrengthEffect.Builder();
	public static final TNTXStrengthEffect.Builder TNT_X5_EFFECT = new TNTXStrengthEffect.Builder().strength(10).randomVecLength(1.25f).knockbackStrength(1.5f);
	public static final TNTXStrengthEffect.Builder TNT_X20_EFFECT = new TNTXStrengthEffect.Builder().strength(20).randomVecLength(1.5f).knockbackStrength(2f);
	public static final TNTXStrengthEffect.Builder TNT_X100_EFFECT = new TNTXStrengthEffect.Builder().strength(50).yStrength(1.3f).knockbackStrength(3f);
	public static final TNTXStrengthEffect.Builder TNT_X500_EFFECT = new TNTXStrengthEffect.Builder().strength(80).yStrength(1.3f).knockbackStrength(5f);
	public static final TNTXStrengthEffect.Builder TNT_X2000_EFFECT = new TNTXStrengthEffect.Builder().strength(160).resistanceImpact(0.167f).randomVecLength(0.05f).knockbackStrength(15f).isStrongExplosion(true);
	public static final TNTXStrengthEffect.Builder TNT_X10000_EFFECT = new TNTXStrengthEffect.Builder().strength(300).resistanceImpact(0.167f).randomVecLength(0.05f).knockbackStrength(30f).isStrongExplosion(true);
	
	//TNT
	public static final Supplier<EntityType<PrimedLTNT>> TNT = LuckyTNTMod.RH.registerTNTEntity("tnt", TNT_EFFECT.buildTNT(() -> BlockRegistry.TNT));

	//Normal TNT
	public static final Supplier<EntityType<PrimedLTNT>> TNT_X5 = LuckyTNTMod.RH.registerTNTEntity("tnt_x5", TNT_X5_EFFECT.fuse(120).buildTNT(() -> BlockRegistry.TNT_X5));
	public static final Supplier<EntityType<PrimedLTNT>> TNT_X20 = LuckyTNTMod.RH.registerTNTEntity("tnt_x20", TNT_X20_EFFECT.fuse(160).buildTNT(() -> BlockRegistry.TNT_X20));
	public static final Supplier<EntityType<PrimedLTNT>> TNT_X100 = LuckyTNTMod.RH.registerTNTEntity("tnt_x100", TNT_X100_EFFECT.fuse(200).buildTNT(() -> BlockRegistry.TNT_X100));
	public static final Supplier<EntityType<PrimedLTNT>> TNT_X500 = LuckyTNTMod.RH.registerTNTEntity("tnt_x500", TNT_X500_EFFECT.fuse(240).buildTNT(() -> BlockRegistry.TNT_X500));
	public static final Supplier<EntityType<PrimedLTNT>> COBBLESTONE_HOUSE_TNT = LuckyTNTMod.RH.registerTNTEntity("cobblestone_house_tnt", new HouseTNTEffect(() -> BlockRegistry.COBBLESTONE_HOUSE_TNT, "cobblehouse", -5, -3));
	public static final Supplier<EntityType<PrimedLTNT>> WOOD_HOUSE_TNT = LuckyTNTMod.RH.registerTNTEntity("woodhouse_tnt", new HouseTNTEffect(() -> BlockRegistry.WOOD_HOUSE_TNT, "woodhouse", -5, -3));
	public static final Supplier<EntityType<PrimedLTNT>> BRICK_HOUSE_TNT = LuckyTNTMod.RH.registerTNTEntity("brickhouse_tnt", new HouseTNTEffect(() -> BlockRegistry.BRICK_HOUSE_TNT, "brickhouse", -5, -3));
	public static final Supplier<EntityType<PrimedLTNT>> DIGGING_TNT = LuckyTNTMod.RH.registerTNTEntity("digging_tnt", new DiggingTNTEffect());
	public static final Supplier<EntityType<PrimedLTNT>> DRILLING_TNT = LuckyTNTMod.RH.registerTNTEntity("drilling_tnt", new DrillingTNTEffect());
	public static final Supplier<EntityType<PrimedLTNT>> SPHERE_TNT = LuckyTNTMod.RH.registerTNTEntity("sphere_tnt", new SphereTNTEffect(() -> BlockRegistry.SPHERE_TNT, 9));
	public static final Supplier<EntityType<PrimedLTNT>> FLOATING_ISLAND = LuckyTNTMod.RH.registerTNTEntity("floating_island", new FloatingIslandEffect(20));
	public static final Supplier<EntityType<PrimedLTNT>> OCEAN_TNT = LuckyTNTMod.RH.registerTNTEntity("ocean_tnt", new OceanTNTEffect(() -> BlockRegistry.OCEAN_TNT, 30, 10, 10));
	public static final Supplier<EntityType<PrimedLTNT>> HELLFIRE_TNT = LuckyTNTMod.RH.registerTNTEntity("hellfire_tnt", new HellfireTNTEffect(20, 5));
	public static final Supplier<EntityType<PrimedLTNT>> FIRE_TNT = LuckyTNTMod.RH.registerTNTEntity("fire_tnt", new FireTNTEffect(10));
	public static final Supplier<EntityType<PrimedLTNT>> SNOW_TNT = LuckyTNTMod.RH.registerTNTEntity("snow_tnt", new SnowTNTEffect(10));
	public static final Supplier<EntityType<PrimedLTNT>> FREEZE_TNT = LuckyTNTMod.RH.registerTNTEntity("freeze_tnt", new FreezeTNTEffect(10));
	public static final Supplier<EntityType<PrimedLTNT>> VAPORIZE_TNT = LuckyTNTMod.RH.registerTNTEntity("vaporize_tnt", new VaporizeTNTEffect(12));
	public static final Supplier<EntityType<PrimedLTNT>> GRAVITY_TNT = LuckyTNTMod.RH.registerTNTEntity("gravity_tnt", new GravityTNTEffect());
	public static final Supplier<EntityType<PrimedLTNT>> LIGHTNING_TNT = LuckyTNTMod.RH.registerTNTEntity("lightning_tnt", new LightningTNTEffect());
	public static final Supplier<EntityType<PrimedLTNT>> CUBIC_TNT = LuckyTNTMod.RH.registerTNTEntity("cubic_tnt", new CubicTNTEffect(3));
	public static final Supplier<EntityType<PrimedLTNT>> FLOATING_TNT = LuckyTNTMod.RH.registerTNTEntity("floating_tnt", new StackedPrimedTNTEffect(new FloatingTNTEffect(), Collections.singletonList(TNT_X100_EFFECT.build())));
	public static final Supplier<EntityType<PrimedLTNT>> TNT_FIREWORK = LuckyTNTMod.RH.registerTNTEntity("tnt_firework", new TNTFireworkEffect());
	public static final Supplier<EntityType<PrimedLTNT>> SAND_FIREWORK = LuckyTNTMod.RH.registerTNTEntity("sand_firework", new SandFireworkEffect());
	public static final Supplier<EntityType<PrimedLTNT>> ARROW_TNT = LuckyTNTMod.RH.registerTNTEntity("arrow_tnt", new ArrowTNTEffect(300));
	public static final Supplier<EntityType<PrimedLTNT>> TIMER_TNT = LuckyTNTMod.RH.registerTNTEntity("timer_tnt", new StackedPrimedTNTEffect(new TimerTNTEffect(), Collections.singletonList(TNT_X5_EFFECT.build())));
	public static final Supplier<EntityType<PrimedLTNT>> FLAT_TNT = LuckyTNTMod.RH.registerTNTEntity("flat_tnt", new FlatTNTEffect(() -> BlockRegistry.FLAT_TNT, 18, 9, 80));
	public static final Supplier<EntityType<PrimedLTNT>> MININGFLAT_TNT = LuckyTNTMod.RH.registerTNTEntity("miningflat_tnt", new MiningflatTNTEffect(30, 9));
	public static final Supplier<EntityType<PrimedLTNT>> COMPACT_TNT = LuckyTNTMod.RH.registerTNTEntity("compact_tnt", new StackedPrimedTNTEffect(TNT_X5_EFFECT.fire(true).fuse(120).buildTNT(() -> BlockRegistry.COMPACT_TNT), Collections.singletonList(new CompactTNTEffect(0.05D, 9, () -> BlockRegistry.TNT))));
	public static final Supplier<EntityType<PrimedLTNT>> ANIMAL_TNT = LuckyTNTMod.RH.registerTNTEntity("animal_tnt", new AnimalTNTEffect());
	public static final Supplier<EntityType<PrimedLTNT>> METEOR_TNT = LuckyTNTMod.RH.registerTNTEntity("meteor_tnt", new DropProjectileTNTEffect(() -> EntityRegistry.METEOR));
	public static final Supplier<EntityType<PrimedLTNT>> SPIRAL_TNT = LuckyTNTMod.RH.registerTNTEntity("spiral_tnt", new SpiralTNTEffect());
	public static final Supplier<EntityType<PrimedLTNT>> ERUPTING_TNT = LuckyTNTMod.RH.registerTNTEntity("erupting_tnt", new EruptingTNTEffect());
	public static final Supplier<EntityType<PrimedLTNT>> GROVE_TNT = LuckyTNTMod.RH.registerTNTEntity("grove_tnt", new GroveTNTEffect(20));
	public static final Supplier<EntityType<PrimedLTNT>> ENDER_TNT = LuckyTNTMod.RH.registerTNTEntity("ender_tnt", new EnderTNTEffect(20));
	public static final Supplier<EntityType<PrimedLTNT>> METEOR_SHOWER = LuckyTNTMod.RH.registerTNTEntity("meteor_shower", new MeteorShowerEffect());
	public static final Supplier<EntityType<PrimedLTNT>> INVERTED_TNT = LuckyTNTMod.RH.registerTNTEntity("inverted_tnt", new InvertedTNTEffect());
	public static final Supplier<EntityType<PrimedLTNT>> NUCLEAR_TNT = LuckyTNTMod.RH.registerTNTEntity("nuclear_tnt", new NuclearTNTEffect(50));
	public static final Supplier<EntityType<PrimedLTNT>> CHEMICAL_TNT = LuckyTNTMod.RH.registerTNTEntity("chemical_tnt", new ChemicalTNTEffect());
	public static final Supplier<EntityType<PrimedLTNT>> REACTION_TNT = LuckyTNTMod.RH.registerTNTEntity("reaction_tnt", new ReactionTNTEffect());
	public static final Supplier<EntityType<PrimedLTNT>> EASTER_EGG = LuckyTNTMod.RH.registerTNTEntity("easter_egg", new EasterEggEffect());
	public static final Supplier<EntityType<PrimedLTNT>> DAY_TNT = LuckyTNTMod.RH.registerTNTEntity("day_tnt", new DayTNTEffect());
	public static final Supplier<EntityType<PrimedLTNT>> NIGHT_TNT = LuckyTNTMod.RH.registerTNTEntity("night_tnt", new NightTNTEffect());
	public static final Supplier<EntityType<PrimedLTNT>> VILLAGE_DEFENSE = LuckyTNTMod.RH.registerTNTEntity("village_defense", new VillageDefenseEffect());
	public static final Supplier<EntityType<PrimedLTNT>> ZOMBIE_APOCALYPSE = LuckyTNTMod.RH.registerTNTEntity("zombie_apocalypse", new ZombieApocalypseEffect());
	public static final Supplier<EntityType<PrimedLTNT>> SHATTERPROOF_TNT = LuckyTNTMod.RH.registerTNTEntity("shatterproof_tnt", new ShatterproofTNTEffect());
	public static final Supplier<EntityType<PrimedLTNT>> GRAVEL_FIREWORK = LuckyTNTMod.RH.registerTNTEntity("gravel_firework", new GravelFireworkEffect());
	public static final Supplier<EntityType<PrimedLTNT>> LAVA_OCEAN_TNT = LuckyTNTMod.RH.registerTNTEntity("lava_ocean_tnt", new LavaOceanTNTEffect(15, 10));
	public static final Supplier<EntityType<LivingPrimedLTNT>> ATTACKING_TNT = LuckyTNTMod.RH.registerLivingTNTEntity("attacking_tnt", () -> EntityType.Builder.<LivingPrimedLTNT>of((EntityType<LivingPrimedLTNT> type, Level level) -> new LivingPrimedLTNT(type, level, TNT_EFFECT.fuse(400).buildTNT(() -> BlockRegistry.ATTACKING_TNT)) {		
		@Override
		public void registerGoals() {
			super.registerGoals();
			targetSelector.addGoal(0, new NearestAttackableTargetGoal<Player>(this, Player.class, 10, false, false, PREDICATE));
			goalSelector.addGoal(1, new MeleeAttackGoal(this, 1, false));
			goalSelector.addGoal(2, new OpenDoorGoal(this, true));
			goalSelector.addGoal(3, new RandomStrollGoal(this, 1));
			goalSelector.addGoal(4, new RandomLookAroundGoal(this));
			goalSelector.addGoal(5, new FloatGoal(this));
		}	
	}, MobCategory.MISC).fireImmune().sized(1f, 1f).build(ek("attacking_tnt")));
	public static final Supplier<EntityType<LivingPrimedLTNT>> WALKING_TNT = LuckyTNTMod.RH.registerLivingTNTEntity("walking_tnt", () -> EntityType.Builder.<LivingPrimedLTNT>of((EntityType<LivingPrimedLTNT> type, Level level) -> new LivingPrimedLTNT(type, level, TNT_EFFECT.fuse(400).buildTNT(() -> BlockRegistry.WALKING_TNT)) {		
		@Override
		public void registerGoals() {
			super.registerGoals();
			goalSelector.addGoal(0, new RandomStrollGoal(this, 1));
			goalSelector.addGoal(1, new RandomLookAroundGoal(this));
			goalSelector.addGoal(2, new FloatGoal(this));
		}	
	}, MobCategory.MISC).fireImmune().sized(1f, 1f).build(ek("walking_tnt")));
	public static final Supplier<EntityType<PrimedLTNT>> WOOL_TNT = LuckyTNTMod.RH.registerTNTEntity("wool_tnt", new WoolTNTEffect(40));
	public static final Supplier<EntityType<PrimedLTNT>> SAY_GOODBYE = LuckyTNTMod.RH.registerTNTEntity("say_goodbye", new SayGoodbyeEffect());
	public static final Supplier<EntityType<PrimedLTNT>> ANGRY_MINERS = LuckyTNTMod.RH.registerTNTEntity("angry_miners", new AngryMinersEffect());
	public static final Supplier<EntityType<PrimedLTNT>> WITHERING_TNT = LuckyTNTMod.RH.registerTNTEntity("withering_tnt", new WitheringTNTEffect(20));
	public static final Supplier<EntityType<PrimedLTNT>> NUCLEAR_WASTE_TNT = LuckyTNTMod.RH.registerTNTEntity("nuclear_waste_tnt", new NuclearWasteTNTEffect(15));
	public static final Supplier<EntityType<PrimedLTNT>> STATIC_TNT = LuckyTNTMod.RH.registerTNTEntity("static_tnt", new StackedPrimedTNTEffect(new StaticTNTEffect(), Collections.singletonList(TNT_EFFECT.build())));
	public static final Supplier<EntityType<PrimedLTNT>> PUMPKIN_BOMB = LuckyTNTMod.RH.registerTNTEntity("pumpkin_bomb", new PumpkinBombEffect());
	public static final Supplier<EntityType<PrimedLTNT>> SMOKE_TNT = LuckyTNTMod.RH.registerTNTEntity("smoke_tnt", new SmokeTNTEffect());
	public static final Supplier<EntityType<PrimedLTNT>> TROLL_TNT = LuckyTNTMod.RH.registerTNTEntity("troll_tnt", new TrollTNTEffect());
	public static final Supplier<EntityType<PrimedLTNT>> TROLL_TNT_MK2 = LuckyTNTMod.RH.registerTNTEntity("troll_tnt_mk2", new TrollTNTEffect());
	public static final Supplier<EntityType<PrimedLTNT>> TROLL_TNT_MK3 = LuckyTNTMod.RH.registerTNTEntity("troll_tnt_mk3", new TrollTNTMk3Effect());
	public static final Supplier<EntityType<PrimedLTNT>> CLUSTER_BOMB_TNT = LuckyTNTMod.RH.registerTNTEntity("cluster_bomb_tnt", new DropProjectileTNTEffect(() -> EntityRegistry.CLUSTER_BOMB));
	public static final Supplier<EntityType<PrimedLTNT>> AIR_STRIKE = LuckyTNTMod.RH.registerTNTEntity("air_strike", new AirStrikeEffect());
	public static final Supplier<EntityType<PrimedLTNT>> SPAMMING_TNT = LuckyTNTMod.RH.registerTNTEntity("spamming_tnt", new SpammingTNTEffect());
	public static final Supplier<EntityType<PrimedLTNT>> BOUNCING_TNT = LuckyTNTMod.RH.registerTNTEntity("bouncing_tnt", new BouncingTNTEffect());
	public static final Supplier<EntityType<PrimedLTNT>> ROULETTE_TNT = LuckyTNTMod.RH.registerTNTEntity("roulette_tnt", new RouletteTNTEffect(10));
	public static final Supplier<EntityType<PrimedLTNT>> SENSOR_TNT = LuckyTNTMod.RH.registerTNTEntity("sensor_tnt", new SensorTNTEffect());
	public static final Supplier<EntityType<PrimedLTNT>> RAINBOW_FIREWORK = LuckyTNTMod.RH.registerTNTEntity("rainbow_firework", new RainbowFireworkEffect());
	public static final Supplier<EntityType<PrimedLTNT>> XRAY_TNT = LuckyTNTMod.RH.registerTNTEntity("xray_tnt", new XRayTNTEffect(40));
	public static final Supplier<EntityType<PrimedLTNT>> FARMING_TNT = LuckyTNTMod.RH.registerTNTEntity("farming_tnt", new FarmingTNTEffect(10));
	public static final Supplier<EntityType<PrimedLTNT>> PHANTOM_TNT = LuckyTNTMod.RH.registerTNTEntity("phantom_tnt", new PhantomTNTEffect());
	public static final Supplier<EntityType<PrimedLTNT>> SWAP_TNT = LuckyTNTMod.RH.registerTNTEntity("swap_tnt", new SwapTNTEffect());
	public static final Supplier<EntityType<PrimedLTNT>> IGNITER_TNT = LuckyTNTMod.RH.registerTNTEntity("igniter_tnt", new IgniterTNTEffect(12));
	public static final Supplier<EntityType<PrimedLTNT>> MULTIPLYING_TNT = LuckyTNTMod.RH.registerTNTEntity("multiplying_tnt", new MultiplyingTNTEffect());
	public static final Supplier<EntityType<PrimedLTNT>> BUTTER_TNT = LuckyTNTMod.RH.registerTNTEntity("butter_tnt", new ButterTNTEffect());
	public static final Supplier<EntityType<PrimedLTNT>> TUNNELING_TNT = LuckyTNTMod.RH.registerTNTEntity("tunneling_tnt", new TunnelingTNTEffect());
	public static final Supplier<EntityType<PrimedLTNT>> PHYSICS_TNT = LuckyTNTMod.RH.registerTNTEntity("physics_tnt", new PhysicsTNTEffect(15));
	public static final Supplier<EntityType<PrimedLTNT>> ORE_TNT = LuckyTNTMod.RH.registerTNTEntity(LuckyTNTMod.MODID, "ore_tnt", () -> EntityType.Builder.<PrimedLTNT>of(PrimedOreTNT::new, MobCategory.MISC).clientTrackingRange(64).fireImmune().sized(1f, 1f).build(ek("ore_tnt")));
	public static final Supplier<EntityType<PrimedLTNT>> REDSTONE_TNT = LuckyTNTMod.RH.registerTNTEntity("redstone_tnt", new RedstoneTNTEffect());
	public static final Supplier<EntityType<PrimedLTNT>> RANDOM_TNT = LuckyTNTMod.RH.registerTNTEntity("random_tnt", new RandomTNTEffect(20));
	public static final Supplier<EntityType<PrimedLTNT>> TURRET_TNT = LuckyTNTMod.RH.registerTNTEntity("turret_tnt", new TurretTNTEffect());
	public static final Supplier<EntityType<PrimedLTNT>> PULSE_TNT = LuckyTNTMod.RH.registerTNTEntity("pulse_tnt", new PulseTNTEffect());
	public static final Supplier<EntityType<PrimedLTNT>> DIVIDING_TNT = LuckyTNTMod.RH.registerTNTEntity("dividing_tnt", new DividingTNTEffect());
	public static final Supplier<EntityType<PrimedLTNT>> PICKY_TNT = LuckyTNTMod.RH.registerTNTEntity("picky_tnt", new PickyTNTEffect(10));
	public static final Supplier<EntityType<PrimedLTNT>> BIG_TNT = LuckyTNTMod.RH.registerTNTEntity("big_tnt", new BigTNTEffect());
	public static final Supplier<EntityType<PrimedLTNT>> ICE_METEOR_TNT = LuckyTNTMod.RH.registerTNTEntity("ice_meteor_tnt", new DropProjectileTNTEffect(() -> EntityRegistry.ICE_METEOR));
	public static final Supplier<EntityType<PrimedLTNT>> HONEY_TNT = LuckyTNTMod.RH.registerTNTEntity("honey_tnt", new HoneyTNTEffect(20));
	public static final Supplier<EntityType<PrimedLTNT>> EATING_TNT = LuckyTNTMod.RH.registerTNTEntity("eating_tnt", new EatingTNTEffect());
	public static final Supplier<EntityType<PrimedLTNT>> LUSH_TNT = LuckyTNTMod.RH.registerTNTEntity("lush_tnt", new LushTNTEffect(20));
	public static final Supplier<EntityType<PrimedLTNT>> GEODE_TNT = LuckyTNTMod.RH.registerTNTEntity("geode_tnt", new GeodeTNTEffect());
	public static final Supplier<EntityType<PrimedLTNT>> NETHER_GROVE_TNT = LuckyTNTMod.RH.registerTNTEntity("nether_grove_tnt", new NetherGroveTNTEffect(30));
	public static final Supplier<EntityType<PrimedLTNT>> DRIPSTONE_TNT = LuckyTNTMod.RH.registerTNTEntity("dripstone_tnt", new DripstoneTNTEffect(20));
	public static final Supplier<EntityType<PrimedLTNT>> GRAVEYARD_TNT = LuckyTNTMod.RH.registerTNTEntity("graveyard_tnt", new StackedPrimedTNTEffect(new GraveyardTNTEffect(), Collections.singletonList(new HouseTNTEffect(() -> BlockRegistry.GRAVEYARD_TNT, "graveyard", -10, -10))));
	public static final Supplier<EntityType<PrimedLTNT>> REPLAY_TNT = LuckyTNTMod.RH.registerTNTEntity(LuckyTNTMod.MODID, "replay_tnt", () -> EntityType.Builder.<PrimedLTNT>of(PrimedReplayTNT::new, MobCategory.MISC).clientTrackingRange(64).fireImmune().sized(1f, 1f).build(ek("replay_tnt")));
	public static final Supplier<EntityType<PrimedLTNT>> END_TNT = LuckyTNTMod.RH.registerTNTEntity("end_tnt", new EndTNTEffect(20));
	public static final Supplier<EntityType<PrimedLTNT>> CHRISTMAS_TNT = LuckyTNTMod.RH.registerTNTEntity("christmas_tnt", new StackedPrimedTNTEffect(new ChristmasTNTEffect(), Collections.singletonList(new SnowTNTEffect(50))));
	public static final Supplier<EntityType<PrimedLTNT>> EARTHQUAKE_TNT = LuckyTNTMod.RH.registerTNTEntity("earthquake_tnt", new EarthquakeTNTEffect());
	public static final Supplier<EntityType<PrimedLTNT>> PRISM_TNT = LuckyTNTMod.RH.registerTNTEntity("prism_tnt", new PrismTNTEffect(10));
	public static final Supplier<EntityType<PrimedLTNT>> RING_TNT = LuckyTNTMod.RH.registerTNTEntity("ring_tnt", new RingTNTEffect());
	public static final Supplier<EntityType<PrimedLTNT>> SCULK_TNT = LuckyTNTMod.RH.registerTNTEntity("sculk_tnt", new SculkTNTEffect(20));
	
	//God TNT
	public static final Supplier<EntityType<PrimedLTNT>> GLOBAL_DISASTER = LuckyTNTMod.RH.registerTNTEntity("global_disaster", new GlobalDisasterEffect());
	public static final Supplier<EntityType<PrimedLTNT>> HEAVENS_GATE = LuckyTNTMod.RH.registerTNTEntity("heavens_gate", new HeavensGateEffect());
	public static final Supplier<EntityType<PrimedLTNT>> HELLS_GATE = LuckyTNTMod.RH.registerTNTEntity("hells_gate", new HellsGateEffect());
	public static final Supplier<EntityType<PrimedLTNT>> MANKINDS_MARK = LuckyTNTMod.RH.registerTNTEntity("mankinds_mark", new MankindsMarkEffect());
	public static final Supplier<EntityType<PrimedLTNT>> POSEIDONS_WAVE = LuckyTNTMod.RH.registerTNTEntity("poseidons_wave", new PoseidonsWaveEffect());
	public static final Supplier<EntityType<PrimedLTNT>> HEXAHEDRON = LuckyTNTMod.RH.registerTNTEntity("hexahedron", new HexahedronEffect());
	public static final Supplier<EntityType<PrimedLTNT>> MOUNTAINTOP_REMOVAL = LuckyTNTMod.RH.registerTNTEntity("mountaintop_removal", new MountaintopRemovalEffect());
	public static final Supplier<EntityType<PrimedLTNT>> DUST_BOWL = LuckyTNTMod.RH.registerTNTEntity("dust_bowl", new DustBowlEffect());
	public static final Supplier<EntityType<PrimedLTNT>> THE_REVOLUTION = LuckyTNTMod.RH.registerTNTEntity("the_revolution", new TheRevolutionEffect());
	public static final Supplier<EntityType<PrimedLTNT>> POMPEII = LuckyTNTMod.RH.registerTNTEntity("pompeii", new PompeiiEffect());
	public static final Supplier<EntityType<PrimedLTNT>> CHICXULUB = LuckyTNTMod.RH.registerTNTEntity("chicxulub", new DropProjectileTNTEffect(() -> EntityRegistry.CHICXULUB_METEOR));
	public static final Supplier<EntityType<PrimedLTNT>> UNBREAKABLE_TNT = LuckyTNTMod.RH.registerTNTEntity("unbreakable_tnt", new UnbreakableTNTEffect());
	public static final Supplier<EntityType<PrimedLTNT>> END_GATE = LuckyTNTMod.RH.registerTNTEntity("end_gate", new EndGateEffect());
	public static final Supplier<EntityType<PrimedLTNT>> DENSE_TNT = LuckyTNTMod.RH.registerTNTEntity("dense_tnt", new StackedPrimedTNTEffect(new TNTXStrengthEffect.Builder().strength(12).randomVecLength(1.1f).knockbackStrength(1.5f).fire(true).fuse(160).buildTNT(() -> BlockRegistry.DENSE_TNT), Collections.singletonList(new CompactTNTEffect(0.02D, 11, () -> BlockRegistry.COMPACT_TNT))));
	public static final Supplier<EntityType<PrimedLTNT>> HYPERION = LuckyTNTMod.RH.registerTNTEntity("hyperion", new HyperionEffect());
	public static final Supplier<EntityType<PrimedLTNT>> TNT_X2000 = LuckyTNTMod.RH.registerTNTEntity("tnt_x2000", TNT_X2000_EFFECT.fuse(400).buildTNT(() -> BlockRegistry.TNT_X2000));
	public static final Supplier<EntityType<PrimedLTNT>> TSAR_BOMBA = LuckyTNTMod.RH.registerTNTEntity("tsar_bomba", new DropProjectileTNTEffect(() -> EntityRegistry.TSAR_BOMBA_BOMB));
	public static final Supplier<EntityType<PrimedLTNT>> TOXIC_CLOUDS = LuckyTNTMod.RH.registerTNTEntity("toxic_clouds", new DisasterTNTEffect("toxic_clouds", false));
	public static final Supplier<EntityType<PrimedLTNT>> DISASTER_CLEARER = LuckyTNTMod.RH.registerTNTEntity("disaster_clearer", new DisasterTNTEffect("clear", false));
	public static final Supplier<EntityType<PrimedLTNT>> WITHER_STORM = LuckyTNTMod.RH.registerTNTEntity("wither_storm", new WitherStormEffect());
	public static final Supplier<EntityType<PrimedLTNT>> LEAPING_TNT = LuckyTNTMod.RH.registerTNTEntity("leaping_tnt", new LeapingTNTEffect());
	public static final Supplier<EntityType<PrimedLTNT>> RUSSIAN_ROULETTE = LuckyTNTMod.RH.registerTNTEntity("russian_roulette", new RussianRouletteEffect());
	public static final Supplier<EntityType<PrimedLTNT>> KNOCKBACK_TNT = LuckyTNTMod.RH.registerTNTEntity("knockback_tnt", new KnockbackTNTEffect());
	public static final Supplier<EntityType<PrimedLTNT>> MIDAS_TNT = LuckyTNTMod.RH.registerTNTEntity("midas_tnt", new MidasTNTEffect());
	public static final Supplier<EntityType<PrimedLTNT>> NEW_YEARS_FIREWORK = LuckyTNTMod.RH.registerTNTEntity("new_years_firework", new NewYearsFireworkEffect());
	public static final Supplier<EntityType<PrimedLTNT>> PULSAR_TNT = LuckyTNTMod.RH.registerTNTEntity("pulsar_tnt", new PulsarTNTEffect());
	public static final Supplier<EntityType<PrimedLTNT>> LIGHTNING_STORM = LuckyTNTMod.RH.registerTNTEntity("lightning_storm", new LightningStormEffect());
	public static final Supplier<EntityType<PrimedLTNT>> SILK_TOUCH_TNT = LuckyTNTMod.RH.registerTNTEntity("silk_touch_tnt", new SilkTouchTNTEffect());
	public static final Supplier<EntityType<PrimedLTNT>> ITEM_FIREWORK = LuckyTNTMod.RH.registerTNTEntity(LuckyTNTMod.MODID, "item_firework", () -> EntityType.Builder.<PrimedLTNT>of(PrimedItemFirework::new, MobCategory.MISC).clientTrackingRange(64).fireImmune().sized(1f, 1f).build(ek("item_firework")));
	public static final Supplier<EntityType<PrimedLTNT>> ANIMAL_KINGDOM = LuckyTNTMod.RH.registerTNTEntity("animal_kingdom", new AnimalKingdomEffect());
	public static final Supplier<EntityType<PrimedLTNT>> ICE_AGE = LuckyTNTMod.RH.registerTNTEntity("ice_age", new DisasterTNTEffect("ice_age", true));
	public static final Supplier<EntityType<PrimedLTNT>> GIANT_TNT = LuckyTNTMod.RH.registerTNTEntity("giant_tnt", new GiantTNTEffect(), 10f, true);
	public static final Supplier<EntityType<PrimedLTNT>> MIMIC_TNT = LuckyTNTMod.RH.registerTNTEntity("mimic_tnt", new MimicTNTEffect());
	public static final Supplier<EntityType<PrimedLTNT>> REVERSED_TNT = LuckyTNTMod.RH.registerTNTEntity("reversed_tnt", new ReversedTNTEffect());
	public static final Supplier<EntityType<PrimedLTNT>> ENTITY_FIREWORK = LuckyTNTMod.RH.registerTNTEntity("entity_firework", new EntityFireworkEffect());
	public static final Supplier<EntityType<PrimedLTNT>> CUSTOM_TNT = LuckyTNTMod.RH.registerTNTEntity("custom_tnt", new CustomTNTEffect());
	public static final Supplier<EntityType<PrimedLTNT>> RESET_TNT = LuckyTNTMod.RH.registerTNTEntity(LuckyTNTMod.MODID, "reset_tnt", () -> EntityType.Builder.<PrimedLTNT>of(PrimedResetTNT::new, MobCategory.MISC).clientTrackingRange(64).fireImmune().sized(1f, 1f).build(ek("reset_tnt")));
	public static final Supplier<EntityType<LivingPrimedLTNT>> VICIOUS_TNT = LuckyTNTMod.RH.registerLivingTNTEntity("vicious_tnt", () -> EntityType.Builder.<LivingPrimedLTNT>of((EntityType<LivingPrimedLTNT> type, Level level) -> new LivingPrimedLTNT(type, level, TNT_X5_EFFECT.fuse(400).buildTNT(() -> BlockRegistry.VICIOUS_TNT)) {		
		@Override
		public void registerGoals() {
			super.registerGoals();
			targetSelector.addGoal(0, new NearestAttackableTargetGoal<Player>(this, Player.class, 10, false, false, PREDICATE));
			goalSelector.addGoal(1, new MeleeAttackGoal(this, 1.2D, false));
			goalSelector.addGoal(2, new OpenDoorGoal(this, true));
			goalSelector.addGoal(3, new RandomStrollGoal(this, 1));
			goalSelector.addGoal(4, new RandomLookAroundGoal(this));
			goalSelector.addGoal(5, new FloatGoal(this));
		}	
	}, MobCategory.MISC).fireImmune().sized(1f, 1f).build(ek("vicious_tnt")));
	public static final Supplier<EntityType<PrimedLTNT>> HUNGRY_TNT = LuckyTNTMod.RH.registerTNTEntity("hungry_tnt", new HungryTNTEffect());
	public static final Supplier<EntityType<PrimedLTNT>> SINKHOLE_TNT = LuckyTNTMod.RH.registerTNTEntity("sinkhole_tnt", new SinkholeTNTEffect());
	public static final Supplier<EntityType<PrimedLTNT>> FIRESTORM_TNT = LuckyTNTMod.RH.registerTNTEntity("firestorm_tnt", new FirestormTNTEffect());
	public static final Supplier<EntityType<PrimedLTNT>> SNOWSTORM_TNT = LuckyTNTMod.RH.registerTNTEntity("snowstorm_tnt", new SnowstormTNTEffect());
	public static final Supplier<EntityType<PrimedLTNT>> ACIDIC_TNT = LuckyTNTMod.RH.registerTNTEntity("acidic_tnt", new AcidicTNTEffect());
	public static final Supplier<EntityType<PrimedLTNT>> CATALYST_TNT = LuckyTNTMod.RH.registerTNTEntity("catalyst_tnt", new CatalystTNTEffect());
	public static final Supplier<EntityType<PrimedLTNT>> CANNON_TNT = LuckyTNTMod.RH.registerTNTEntity("cannon_tnt", new CannonTNTEffect());
	public static final Supplier<EntityType<PrimedLTNT>> PLANTATION_TNT = LuckyTNTMod.RH.registerTNTEntity("plantation_tnt", new PlantationTNTEffect());
	public static final Supplier<EntityType<PrimedLTNT>> GOTTHARD_TUNNEL = LuckyTNTMod.RH.registerTNTEntity("gotthard_tunnel", new GotthardTunnelEffect());
	public static final Supplier<EntityType<PrimedLTNT>> LEVITATING_TNT = LuckyTNTMod.RH.registerTNTEntity("levitating_tnt", new StackedPrimedTNTEffect(TNT_X500_EFFECT.fuse(160).buildTNT(() -> BlockRegistry.LEVITATING_TNT), List.of(new LevitatingTNTEffect())));
	public static final Supplier<EntityType<PrimedLTNT>> SQUARING_TNT = LuckyTNTMod.RH.registerTNTEntity("squaring_tnt", new SquaringTNTEffect());
	public static final Supplier<EntityType<PrimedLTNT>> MINERAL_TNT = LuckyTNTMod.RH.registerTNTEntity("mineral_tnt", new MineralTNTEffect());
	public static final Supplier<EntityType<PrimedLTNT>> FLOWER_FOREST_TNT = LuckyTNTMod.RH.registerTNTEntity("flower_forest_tnt", new FlowerForestTNTEffect());
	public static final Supplier<EntityType<PrimedLTNT>> ICY_TNT = LuckyTNTMod.RH.registerTNTEntity("icy_tnt", new IcyTNTEffect());
	public static final Supplier<EntityType<PrimedLTNT>> GHOST_TNT = LuckyTNTMod.RH.registerTNTEntity("ghost_tnt", new GhostTNTEffect());
	public static final Supplier<EntityType<PrimedLTNT>> PARTICLE_PHYSICS_TNT = LuckyTNTMod.RH.registerTNTEntity("particle_physics_tnt", new ParticlePhysicsTNTEffect());
	public static final Supplier<EntityType<PrimedLTNT>> HEAT_DEATH = LuckyTNTMod.RH.registerTNTEntity("heat_death", new DisasterTNTEffect("heat_death", false));
	public static final Supplier<EntityType<PrimedLTNT>> CONTINENTAL_DRIFT = LuckyTNTMod.RH.registerTNTEntity("continental_drift", new ContinentalDriftEffect());
	public static final Supplier<EntityType<PrimedLTNT>> TETRAHEDRON_TNT = LuckyTNTMod.RH.registerTNTEntity("tetrahedron_tnt", new TetrahedronTNTEffect());
	public static final Supplier<EntityType<PrimedLTNT>> EYE_OF_THE_SAHARA = LuckyTNTMod.RH.registerTNTEntity("eye_of_the_sahara", new EyeOfTheSaharaEffect());
	public static final Supplier<EntityType<PrimedLTNT>> WORLD_OF_WOOLS = LuckyTNTMod.RH.registerTNTEntity("world_of_wools", new WorldOfWoolsEffect());
	public static final Supplier<EntityType<PrimedLTNT>> DEIMOS = LuckyTNTMod.RH.registerTNTEntity("deimos", new DropProjectileTNTEffect(() -> EntityRegistry.DEIMOS_METEOR));
	public static final Supplier<EntityType<PrimedLTNT>> PRESENT_DROP = LuckyTNTMod.RH.registerTNTEntity("present_drop", new DropProjectileTNTEffect(() -> EntityRegistry.PRESENT_METEOR));
	
	//Doomsday
	public static final Supplier<EntityType<PrimedLTNT>> SUPERNOVA = LuckyTNTMod.RH.registerTNTEntity("supernova", new SupernovaEffect());
	public static final Supplier<EntityType<PrimedLTNT>> CITY_FIREWORK = LuckyTNTMod.RH.registerTNTEntity("city_firework", new CityFireworkEffect());
	public static final Supplier<EntityType<PrimedLTNT>> METEOR_STORM = LuckyTNTMod.RH.registerTNTEntity("meteor_storm", new MeteorStormEffect());
	public static final Supplier<EntityType<PrimedLTNT>> CHUNK_TNT = LuckyTNTMod.RH.registerTNTEntity("chunk_tnt", new ChunkTNTEffect());
	public static final Supplier<EntityType<PrimedLTNT>> COMPRESSED_TNT = LuckyTNTMod.RH.registerTNTEntity("compressed_tnt", new StackedPrimedTNTEffect(new TNTXStrengthEffect.Builder().strength(15).randomVecLength(1.1f).knockbackStrength(1.5f).fire(true).fuse(240).buildTNT(() -> BlockRegistry.COMPRESSED_TNT), Collections.singletonList(new CompactTNTEffect(0.01D, 14, () -> BlockRegistry.DENSE_TNT))));
	public static final Supplier<EntityType<PrimedLTNT>> EXTINCTION = LuckyTNTMod.RH.registerTNTEntity("extinction", new ExtinctionEffect());
	public static final Supplier<EntityType<PrimedLTNT>> MANSION = LuckyTNTMod.RH.registerTNTEntity("mansion", new MansionEffect());
	public static final Supplier<EntityType<PrimedLTNT>> HELIX = LuckyTNTMod.RH.registerTNTEntity("helix", new HelixEffect());
	public static final Supplier<EntityType<PrimedLTNT>> DEATH_RAY = LuckyTNTMod.RH.registerTNTEntity("death_ray", new DeathRayEffect());
	public static final Supplier<EntityType<PrimedLTNT>> DOOMSDAY = LuckyTNTMod.RH.registerTNTEntity("doomsday", new DisasterTNTEffect("doomsday", true));
	public static final Supplier<EntityType<PrimedLTNT>> FIERY_HELL = LuckyTNTMod.RH.registerTNTEntity("fiery_hell", new FieryHellEffect());
	public static final Supplier<EntityType<PrimedLTNT>> STONE_COLD = LuckyTNTMod.RH.registerTNTEntity("stone_cold", new StoneColdEffect());
	public static final Supplier<EntityType<PrimedLTNT>> JUNGLE_TNT = LuckyTNTMod.RH.registerTNTEntity("jungle_tnt", new JungleTNTEffect());
	public static final Supplier<EntityType<PrimedLTNT>> JUMPING_TNT = LuckyTNTMod.RH.registerTNTEntity("jumping_tnt", new JumpingTNTEffect());
	public static final Supplier<EntityType<PrimedLTNT>> WASTELAND_TNT = LuckyTNTMod.RH.registerTNTEntity("wasteland_tnt", new WastelandTNTEffect());
	public static final Supplier<EntityType<PrimedLTNT>> TNT_X10000 = LuckyTNTMod.RH.registerTNTEntity("tnt_x10000",  TNT_X10000_EFFECT.fuse(480).buildTNT(() -> BlockRegistry.TNT_X10000));
	public static final Supplier<EntityType<PrimedLTNT>> CUSTOM_FIREWORK = LuckyTNTMod.RH.registerTNTEntity(LuckyTNTMod.MODID, "custom_firework", () -> EntityType.Builder.<PrimedLTNT>of(PrimedCustomFirework::new, MobCategory.MISC).clientTrackingRange(64).fireImmune().sized(1f, 1f).build(ek("custom_firework")));
	public static final Supplier<EntityType<PrimedLTNT>> ATLANTIS = LuckyTNTMod.RH.registerTNTEntity("atlantis", new AtlantisEffect());
	public static final Supplier<EntityType<PrimedLTNT>> SOLAR_ERUPTION = LuckyTNTMod.RH.registerTNTEntity("solar_eruption", new SolarEruptionEffect());
	public static final Supplier<EntityType<PrimedLTNT>> VREDEFORT = LuckyTNTMod.RH.registerTNTEntity("vredefort", new DropProjectileTNTEffect(() -> EntityRegistry.VREDEFORT_PROJECTILE));
	public static final Supplier<EntityType<PrimedLTNT>> COLOSSAL_TNT = LuckyTNTMod.RH.registerTNTEntity("colossal_tnt", new ColossalTNTEffect());
	public static final Supplier<EntityType<PrimedLTNT>> STRUCTURE_TNT = LuckyTNTMod.RH.registerTNTEntity("structure_tnt", new StructureTNTEffect());
	public static final Supplier<EntityType<PrimedLTNT>> GRANDE_FINALE = LuckyTNTMod.RH.registerTNTEntity("grande_finale", new GrandeFinaleEffect());
	public static final Supplier<EntityType<PrimedLTNT>> FLAT_EARTH = LuckyTNTMod.RH.registerTNTEntity("flat_earth", new FlatTNTEffect(() -> BlockRegistry.FLAT_EARTH, 200, 50, 200));
	public static final Supplier<EntityType<LivingPrimedLTNT>> EVIL_TNT = LuckyTNTMod.RH.registerLivingTNTEntity("evil_tnt", () -> EntityType.Builder.<LivingPrimedLTNT>of((EntityType<LivingPrimedLTNT> type, Level level) -> new LivingPrimedLTNT(type, level, TNT_X20_EFFECT.fuse(400).buildTNT(() -> BlockRegistry.EVIL_TNT)) {		
		@Override
		public void registerGoals() {
			super.registerGoals();
			targetSelector.addGoal(0, new NearestAttackableTargetGoal<Player>(this, Player.class, 10, false, false, PREDICATE));
			goalSelector.addGoal(1, new MeleeAttackGoal(this, 1.2D, false));
			goalSelector.addGoal(2, new OpenDoorGoal(this, true));
			goalSelector.addGoal(3, new RandomStrollGoal(this, 1));
			goalSelector.addGoal(4, new RandomLookAroundGoal(this));
			goalSelector.addGoal(5, new FloatGoal(this));
		}	
	}, MobCategory.MISC).fireImmune().sized(1f, 1f).build(ek("evil_tnt")));
	public static final Supplier<EntityType<PrimedLTNT>> KOLA_BOREHOLE_TNT = LuckyTNTMod.RH.registerTNTEntity("kola_borehole_tnt", new KolaBoreholeTNTEffect());
	public static final Supplier<EntityType<PrimedLTNT>> HYDROGEN_BOMB = LuckyTNTMod.RH.registerTNTEntity("hydrogen_bomb", new DropProjectileTNTEffect(() -> EntityRegistry.HYDROGEN_BOMB_BOMB));
	public static final Supplier<EntityType<PrimedLTNT>> FLUORINE_TNT = LuckyTNTMod.RH.registerTNTEntity("fluorine_tnt", new FluorineTNTEffect());
	public static final Supplier<EntityType<PrimedLTNT>> DISINTEGRATING_TNT = LuckyTNTMod.RH.registerTNTEntity("disintegrating_tnt", new DisintegratingTNTEffect());
	public static final Supplier<EntityType<PrimedLTNT>> FLYING_TNT = LuckyTNTMod.RH.registerTNTEntity("flying_tnt", new StackedPrimedTNTEffect(TNT_X2000_EFFECT.fuse(200).buildTNT(() -> BlockRegistry.FLYING_TNT), List.of(new LevitatingTNTEffect())));
	public static final Supplier<EntityType<PrimedLTNT>> HEAT_WAVE = LuckyTNTMod.RH.registerTNTEntity("heat_wave", new HeatWaveEffect());
	public static final Supplier<EntityType<PrimedLTNT>> WINTER_TNT = LuckyTNTMod.RH.registerTNTEntity("winter_tnt", new WinterTNTEffect());
	public static final Supplier<EntityType<PrimedLTNT>> BLACK_HOLE_TNT = LuckyTNTMod.RH.registerTNTEntity("black_hole_tnt", new BlackHoleTNTEffect());
	public static final Supplier<EntityType<PrimedLTNT>> FLAK_TNT = LuckyTNTMod.RH.registerTNTEntity("flak_tnt", new FlakTNTEffect());
	public static final Supplier<EntityType<PrimedLTNT>> TNT_RAIN = LuckyTNTMod.RH.registerTNTEntity("tnt_rain", new DisasterTNTEffect("tnt_rain", false));
	public static final Supplier<EntityType<PrimedLTNT>> ILLUMINATI_TNT = LuckyTNTMod.RH.registerTNTEntity("illuminati_tnt", new IlluminatiTNTEffect());
	public static final Supplier<EntityType<PrimedLTNT>> ASTEROID_BELT = LuckyTNTMod.RH.registerTNTEntity("asteroid_belt", new AsteroidBeltEffect());
	public static final Supplier<EntityType<PrimedLTNT>> NETHER_TNT = LuckyTNTMod.RH.registerTNTEntity("nether_tnt", new NetherTNTEffect());
	public static final Supplier<EntityType<PrimedLTNT>> AETHER_TNT = LuckyTNTMod.RH.registerTNTEntity("aether_tnt", new AetherTNTEffect());
	public static final Supplier<EntityType<PrimedLTNT>> PHOBOS = LuckyTNTMod.RH.registerTNTEntity("phobos", new DropProjectileTNTEffect(() -> EntityRegistry.PHOBOS_METEOR));
	
	//Dynamite
	public static final Supplier<EntityType<LExplosiveProjectile>> DYNAMITE = LuckyTNTMod.RH.registerExplosiveProjectile("dynamite", WEAK_TNT_EFFECT.buildDynamite(() -> ItemRegistry.DYNAMITE), 0.25f, false);
	public static final Supplier<EntityType<LExplosiveProjectile>> DYNAMITE_X5 = LuckyTNTMod.RH.registerExplosiveProjectile("dynamite_x5", TNT_EFFECT.buildDynamite(() -> ItemRegistry.DYNAMITE_X5), 0.25f, false);
	public static final Supplier<EntityType<LExplosiveProjectile>> DYNAMITE_X20 = LuckyTNTMod.RH.registerExplosiveProjectile("dynamite_x20", TNT_X5_EFFECT.buildDynamite(() -> ItemRegistry.DYNAMITE_X20), 0.25f, false);
	public static final Supplier<EntityType<LExplosiveProjectile>> DYNAMITE_X100 = LuckyTNTMod.RH.registerExplosiveProjectile("dynamite_x100", new TNTXStrengthEffect.Builder().strength(25).randomVecLength(1.5f).knockbackStrength(2.5f).buildDynamite(() -> ItemRegistry.DYNAMITE_X100), 0.25f, false);
	public static final Supplier<EntityType<LExplosiveProjectile>> DYNAMITE_X500 = LuckyTNTMod.RH.registerExplosiveProjectile("dynamite_x500", new TNTXStrengthEffect.Builder().strength(60).yStrength(1.4f).knockbackStrength(3.5f).buildDynamite(() -> ItemRegistry.DYNAMITE_X500), 0.25f, false);
	public static final Supplier<EntityType<LExplosiveProjectile>> FIRE_DYNAMITE = LuckyTNTMod.RH.registerExplosiveProjectile("fire_dynamite", new GeneralDynamiteEffect(() -> ItemRegistry.FIRE_DYNAMITE, ParticleTypes.FLAME, new FireTNTEffect(5)), 0.25f, false);
	public static final Supplier<EntityType<LExplosiveProjectile>> SNOW_DYNAMITE = LuckyTNTMod.RH.registerExplosiveProjectile("snow_dynamite", new GeneralDynamiteEffect(() -> ItemRegistry.SNOW_DYNAMITE, new SnowTNTEffect(5)), 0.25f, false);
	public static final Supplier<EntityType<LExplosiveProjectile>> DYNAMITE_FIREWORK = LuckyTNTMod.RH.registerExplosiveProjectile("dynamite_firework", new DynamiteFireworkEffect(), 0.25f, false);
	public static final Supplier<EntityType<LExplosiveProjectile>> NUCLEAR_DYNAMITE = LuckyTNTMod.RH.registerExplosiveProjectile("nuclear_dynamite", new GeneralDynamiteEffect(() -> ItemRegistry.NUCLEAR_DYNAMITE, dustParticle(0.9f, 1f, 0f, 1f), new NuclearTNTEffect(25)), 0.25f, false);
	public static final Supplier<EntityType<LExplosiveProjectile>> FREEZE_DYNAMITE = LuckyTNTMod.RH.registerExplosiveProjectile("freeze_dynamite", new GeneralDynamiteEffect(() -> ItemRegistry.FREEZE_DYNAMITE, new FreezeTNTEffect(5)), 0.25f, false);
	public static final Supplier<EntityType<LExplosiveProjectile>> FLOATING_DYNAMITE = LuckyTNTMod.RH.registerExplosiveProjectile("floating_dynamite", new FloatingDynamiteEffect(), 0.25f, false);
	public static final Supplier<EntityType<LExplosiveProjectile>> SPHERE_DYNAMITE = LuckyTNTMod.RH.registerExplosiveProjectile("sphere_dynamite", new GeneralDynamiteEffect(() -> ItemRegistry.SPHERE_DYNAMITE, new SphereTNTEffect(() -> BlockRegistry.SPHERE_TNT, 5)), 0.25f, false);
	public static final Supplier<EntityType<LExplosiveProjectile>> FLAT_DYNAMITE = LuckyTNTMod.RH.registerExplosiveProjectile("flat_dynamite", new GeneralDynamiteEffect(() -> ItemRegistry.FLAT_DYNAMITE, new FlatTNTEffect(9, 5, 0)), 0.25f, false);
	public static final Supplier<EntityType<LExplosiveProjectile>> MININGFLAT_DYNAMITE = LuckyTNTMod.RH.registerExplosiveProjectile("miningflat_dynamite", new GeneralDynamiteEffect(() -> ItemRegistry.MININGFLAT_DYNAMITE, new MiningflatTNTEffect(15, 5)), 0.25f, false);
	public static final Supplier<EntityType<LExplosiveProjectile>> VAPORIZE_DYNAMITE = LuckyTNTMod.RH.registerExplosiveProjectile("vaporize_dynamite", new GeneralDynamiteEffect(() -> ItemRegistry.VAPORIZE_DYNAMITE, new VaporizeTNTEffect(6)), 0.25f, false);
	public static final Supplier<EntityType<LExplosiveProjectile>> METEOR_DYNAMITE = LuckyTNTMod.RH.registerExplosiveProjectile("meteor_dynamite", new MeteorDynamiteEffect(), 0.25f, false);
	public static final Supplier<EntityType<LExplosiveProjectile>> CUBIC_DYNAMITE = LuckyTNTMod.RH.registerExplosiveProjectile("cubic_dynamite", new GeneralDynamiteEffect(() -> ItemRegistry.CUBIC_DYNAMITE, new CubicTNTEffect(2)), 0.25f, false);
	public static final Supplier<EntityType<LExplosiveProjectile>> GROVE_DYNAMITE = LuckyTNTMod.RH.registerExplosiveProjectile("grove_dynamite", new GeneralDynamiteEffect(() -> ItemRegistry.GROVE_DYNAMITE, new GroveTNTEffect(10)), 0.25f, false);
	public static final Supplier<EntityType<LExplosiveProjectile>> ENDER_DYNAMITE = LuckyTNTMod.RH.registerExplosiveProjectile("ender_dynamite", new GeneralDynamiteEffect(() -> ItemRegistry.ENDER_DYNAMITE, dustParticle(0.6f, 0f, 0.9f, 1f), new EnderTNTEffect(10)), 0.25f, false);
	public static final Supplier<EntityType<LExplosiveProjectile>> ARROW_DYNAMITE = LuckyTNTMod.RH.registerExplosiveProjectile("arrow_dynamite", new GeneralDynamiteEffect(() -> ItemRegistry.ARROW_DYNAMITE, new ArrowTNTEffect(150)), 0.25f, false);
	public static final Supplier<EntityType<LExplosiveProjectile>> LIGHTNING_DYNAMITE = LuckyTNTMod.RH.registerExplosiveProjectile("lightning_dynamite", new LightningDynamiteEffect(), 0.25f, false);
	public static final Supplier<EntityType<LExplosiveProjectile>> DIGGING_DYNAMITE = LuckyTNTMod.RH.registerExplosiveProjectile("digging_dynamite", new DiggingDynamiteEffect(), 0.25f, false);
	public static final Supplier<EntityType<LExplosiveProjectile>> COMPACT_DYNAMITE = LuckyTNTMod.RH.registerExplosiveProjectile("compact_dynamite", new GeneralDynamiteEffect(() -> ItemRegistry.COMPACT_DYNAMITE, new StackedPrimedTNTEffect(new TNTXStrengthEffect.Builder().strength(10).randomVecLength(1.1f).knockbackStrength(1.5f).fire(true).build(), Collections.singletonList(new CompactTNTEffect(0.05f, 9, () -> BlockRegistry.TNT)))), 0.25f, false);
	public static final Supplier<EntityType<LExplosiveProjectile>> ANIMAL_DYNAMITE = LuckyTNTMod.RH.registerExplosiveProjectile("animal_dynamite", new AnimalDynamiteEffect(), 0.25f, false);
	public static final Supplier<EntityType<LExplosiveProjectile>> OCEAN_DYNAMITE = LuckyTNTMod.RH.registerExplosiveProjectile("ocean_dynamite", new GeneralDynamiteEffect(() -> ItemRegistry.OCEAN_DYNAMITE, ParticleTypes.SPLASH, new OceanTNTEffect(15, 5, 5)), 0.25f, false);
	public static final Supplier<EntityType<LExplosiveProjectile>> SPIRAL_DYNAMITE = LuckyTNTMod.RH.registerExplosiveProjectile("spiral_dynamite", new SpiralDynamiteEffect(), 0.25f, false);
	public static final Supplier<EntityType<LExplosiveProjectile>> CHEMICAL_DYNAMITE = LuckyTNTMod.RH.registerExplosiveProjectile("chemical_dynamite", new ChemicalDynamiteEffect(), 0.25f, false);
	public static final Supplier<EntityType<LExplosiveProjectile>> REACTION_DYNAMITE = LuckyTNTMod.RH.registerExplosiveProjectile("reaction_dynamite", new ReactionDynamiteEffect(), 0.25f, false);
	public static final Supplier<EntityType<LExplosiveProjectile>> HELLFIRE_DYNAMITE = LuckyTNTMod.RH.registerExplosiveProjectile("hellfire_dynamite", new GeneralDynamiteEffect(() -> ItemRegistry.HELLFIRE_DYNAMITE, ParticleTypes.FLAME, new HellfireTNTEffect(10, 1)), 0.25f, false);
	public static final Supplier<EntityType<LExplosiveProjectile>> FLOATING_ISLAND_DYNAMITE = LuckyTNTMod.RH.registerExplosiveProjectile("floating_island_dynamite", new GeneralDynamiteEffect(() -> ItemRegistry.FLOATING_ISLAND_DYNAMITE, new FloatingIslandEffect(10)), 0.25f, false);
	public static final Supplier<EntityType<LExplosiveProjectile>> ERUPTING_DYNAMITE = LuckyTNTMod.RH.registerExplosiveProjectile("erupting_dynamite", new EruptingDynamiteEffect(), 0.25f, false);
	public static final Supplier<EntityType<LExplosiveProjectile>> SHATTERPROOF_DYNAMITE = LuckyTNTMod.RH.registerExplosiveProjectile("shatterproof_dynamite", new ShatterproofDynamiteEffect(), 0.25f, false);
	public static final Supplier<EntityType<LExplosiveProjectile>> LAVA_OCEAN_DYNAMITE = LuckyTNTMod.RH.registerExplosiveProjectile("lava_ocean_dynamite", new GeneralDynamiteEffect(() -> ItemRegistry.LAVA_OCEAN_DYNAMITE, dustParticle(1f, 0.5f, 0.1f, 1f), new LavaOceanTNTEffect(8, 5)), 0.25f, false);
	public static final Supplier<EntityType<LExplosiveProjectile>> WOOL_DYNAMITE = LuckyTNTMod.RH.registerExplosiveProjectile("wool_dynamite", new GeneralDynamiteEffect(() -> ItemRegistry.WOOL_DYNAMITE, dustParticle(10f, 10f, 10f, 1f), new WoolTNTEffect(20)), 0.25f, false);
	public static final Supplier<EntityType<LExplosiveProjectile>> NUCLEAR_WASTE_DYNAMITE = LuckyTNTMod.RH.registerExplosiveProjectile("nuclear_waste_dynamite", new GeneralDynamiteEffect(() -> ItemRegistry.NUCLEAR_WASTE_DYNAMITE, dustParticle(0.9f, 1f, 0f, 1f), new NuclearWasteTNTEffect(8)), 0.25f, false);
	public static final Supplier<EntityType<LExplosiveProjectile>> TIMER_DYNAMITE = LuckyTNTMod.RH.registerExplosiveProjectile("timer_dynamite", new TimerDynamiteEffect(), 0.25f, false);
	public static final Supplier<EntityType<LExplosiveProjectile>> GRAVITY_DYNAMITE = LuckyTNTMod.RH.registerExplosiveProjectile("gravity_dynamite", new GravityDynamiteEffect(), 0.25f, false);
	public static final Supplier<EntityType<LExplosiveProjectile>> WITHERING_DYNAMITE = LuckyTNTMod.RH.registerExplosiveProjectile("withering_dynamite", new GeneralDynamiteEffect(() -> ItemRegistry.WITHERING_DYNAMITE, new WitheringTNTEffect(10)), 0.25f, false);
	public static final Supplier<EntityType<LExplosiveProjectile>> SENSOR_DYNAMITE = LuckyTNTMod.RH.registerExplosiveProjectile("sensor_dynamite", new SensorDynamiteEffect(), 0.25f, false);
	public static final Supplier<EntityType<LExplosiveProjectile>> RAINBOW_DYNAMITE = LuckyTNTMod.RH.registerExplosiveProjectile("rainbow_dynamite", new RainbowDynamiteEffect(), 0.25f, false);
	public static final Supplier<EntityType<LExplosiveProjectile>> ROULETTE_DYNAMITE = LuckyTNTMod.RH.registerExplosiveProjectile("roulette_dynamite", new GeneralDynamiteEffect(() -> ItemRegistry.ROULETTE_DYNAMITE, new RouletteTNTEffect(5)), 0.25f, false);
	public static final Supplier<EntityType<LExplosiveProjectile>> BOUNCING_DYNAMITE = LuckyTNTMod.RH.registerExplosiveProjectile(LuckyTNTMod.MODID, "bouncing_dynamite", () -> EntityType.Builder.<LExplosiveProjectile>of(BouncingDynamite::new, MobCategory.MISC).sized(0.25f, 0.25f).build(ek("bouncing_dynamite")));
	public static final Supplier<EntityType<LExplosiveProjectile>> IGNITER_DYNAMITE = LuckyTNTMod.RH.registerExplosiveProjectile("igniter_dynamite", new GeneralDynamiteEffect(() -> ItemRegistry.IGNITER_DYNAMITE, new IgniterTNTEffect(6)), 0.25f, false);
	public static final Supplier<EntityType<LExplosiveProjectile>> MULTIPLYING_DYNAMITE = LuckyTNTMod.RH.registerExplosiveProjectile("multiplying_dynamite", new MultiplyingDynamiteEffect(), 0.25f, false);
	public static final Supplier<EntityType<LExplosiveProjectile>> RANDOM_DYNAMITE = LuckyTNTMod.RH.registerExplosiveProjectile("random_dynamite", new GeneralDynamiteEffect(() -> ItemRegistry.RANDOM_DYNAMITE, new RandomTNTEffect(10)), 0.25f, false);
	public static final Supplier<EntityType<LExplosiveProjectile>> HOMING_DYNAMITE = LuckyTNTMod.RH.registerExplosiveProjectile("homing_dynamite", new HomingDynamiteEffect(), 0.25f, false);
	public static final Supplier<EntityType<LExplosiveProjectile>> PULSE_DYNAMITE = LuckyTNTMod.RH.registerExplosiveProjectile("pulse_dynamite", new PulseDynamiteEffect(), 0.25f, false);
	public static final Supplier<EntityType<LExplosiveProjectile>> PHYSICS_DYNAMITE = LuckyTNTMod.RH.registerExplosiveProjectile("physics_dynamite", new GeneralDynamiteEffect(() -> ItemRegistry.PHYSICS_DYNAMITE, new PhysicsTNTEffect(8)), 0.25f, false);
	public static final Supplier<EntityType<LExplosiveProjectile>> PICKY_DYNAMITE = LuckyTNTMod.RH.registerExplosiveProjectile("picky_dynamite", new GeneralDynamiteEffect(() -> ItemRegistry.PICKY_DYNAMITE, new PickyTNTEffect(5)), 0.25f, false);
	public static final Supplier<EntityType<LExplosiveProjectile>> CLUSTER_DYNAMITE = LuckyTNTMod.RH.registerExplosiveProjectile("cluster_dynamite", new ClusterDynamiteEffect(), 0.25f, false);
	public static final Supplier<EntityType<LExplosiveProjectile>> TUNNELING_DYNAMITE = LuckyTNTMod.RH.registerExplosiveProjectile("tunneling_dynamite", new TunnelingDynamiteEffect(), 0.25f, false);
	public static final Supplier<EntityType<LExplosiveProjectile>> XRAY_DYNAMITE = LuckyTNTMod.RH.registerExplosiveProjectile("xray_dynamite", new GeneralDynamiteEffect(() -> ItemRegistry.XRAY_DYNAMITE, new XRayTNTEffect(20)), 0.25f, false);
	public static final Supplier<EntityType<LExplosiveProjectile>> FARMING_DYNAMITE = LuckyTNTMod.RH.registerExplosiveProjectile("farming_dynamite", new GeneralDynamiteEffect(() -> ItemRegistry.FARMING_DYNAMITE, dustParticle(1f, 0.5f, 0.1f, 1f), new FarmingTNTEffect(5)), 0.25f, false);
	public static final Supplier<EntityType<LExplosiveProjectile>> BIG_DYNAMITE = LuckyTNTMod.RH.registerExplosiveProjectile("big_dynamite", new BigDynamiteEffect(), 1f, false);
	public static final Supplier<EntityType<LExplosiveProjectile>> ICE_METEOR_DYNAMITE = LuckyTNTMod.RH.registerExplosiveProjectile("ice_meteor_dynamite", new IceMeteorDynamiteEffect(), 0.25f, false);
	public static final Supplier<EntityType<LExplosiveProjectile>> HONEY_DYNAMITE = LuckyTNTMod.RH.registerExplosiveProjectile("honey_dynamite", new GeneralDynamiteEffect(() -> ItemRegistry.HONEY_DYNAMITE, ParticleTypes.DRIPPING_HONEY, new HoneyTNTEffect(10)), 0.25f, false);
	public static final Supplier<EntityType<LExplosiveProjectile>> ULTRALIGHT_DYNAMITE = LuckyTNTMod.RH.registerExplosiveProjectile("ultralight_dynamite", new UltralightDynamiteEffect(), 0.25f, false);
	public static final Supplier<EntityType<LExplosiveProjectile>> ACCELERATING_DYNAMITE = LuckyTNTMod.RH.registerExplosiveProjectile("acclerating_dynamite", new AcceleratingDynamiteEffect(), 0.25f, false);
	public static final Supplier<EntityType<LExplosiveProjectile>> NETHER_GROVE_DYNAMITE = LuckyTNTMod.RH.registerExplosiveProjectile("nether_grove_dynamite", new GeneralDynamiteEffect(() -> ItemRegistry.NETHER_GROVE_DYNAMITE, new NetherGroveTNTEffect(15)), 0.25f, false);
	public static final Supplier<EntityType<LExplosiveProjectile>> LUSH_DYNAMITE = LuckyTNTMod.RH.registerExplosiveProjectile("lush_dynamite", new GeneralDynamiteEffect(() -> ItemRegistry.LUSH_DYNAMITE, dustParticle(0.44f, 0.57f, 0.18f, 1f), new LushTNTEffect(10)), 0.25f, false);
	public static final Supplier<EntityType<LExplosiveProjectile>> DRIPSTONE_DYNAMITE = LuckyTNTMod.RH.registerExplosiveProjectile("dripstone_dynamite", new GeneralDynamiteEffect(() -> ItemRegistry.DRIPSTONE_DYNAMITE, new DripstoneTNTEffect(10)), 0.25f, false);
	public static final Supplier<EntityType<LExplosiveProjectile>> END_DYNAMITE = LuckyTNTMod.RH.registerExplosiveProjectile("end_dynamite", new GeneralDynamiteEffect(() -> ItemRegistry.END_DYNAMITE, ParticleTypes.END_ROD, new EndTNTEffect(10)), 0.25f, false);
	public static final Supplier<EntityType<LExplosiveProjectile>> CHRISTMAS_DYNAMITE = LuckyTNTMod.RH.registerExplosiveProjectile("christmas_dynamite", new ChristmasDynamiteEffect(), 0.25f, false);
	public static final Supplier<EntityType<LExplosiveProjectile>> PRISM_DYNAMITE = LuckyTNTMod.RH.registerExplosiveProjectile("prism_dynamite", new GeneralDynamiteEffect(() -> ItemRegistry.PRISM_DYNAMITE, new PrismTNTEffect(6)), 0.25f, false);
	public static final Supplier<EntityType<LExplosiveProjectile>> RING_DYNAMITE = LuckyTNTMod.RH.registerExplosiveProjectile("ring_dynamite", new RingDynamiteEffect(), 0.25f, false);
	public static final Supplier<EntityType<LExplosiveProjectile>> SCULK_DYNAMITE = LuckyTNTMod.RH.registerExplosiveProjectile("sculk_dynamite", new GeneralDynamiteEffect(() -> ItemRegistry.SCULK_DYNAMITE, new SculkTNTEffect(10)), 0.25f, false);

	//Minecarts
	public static final Supplier<EntityType<LTNTMinecart>> TNT_X5_MINECART = LuckyTNTMod.RH.registerTNTMinecart("tnt_x5_minecart", TNT_X5, () -> ItemRegistry.TNT_X5_MINECART);
	public static final Supplier<EntityType<LTNTMinecart>> TNT_X20_MINECART = LuckyTNTMod.RH.registerTNTMinecart("tnt_x20_minecart", TNT_X20, () -> ItemRegistry.TNT_X20_MINECART);
	public static final Supplier<EntityType<LTNTMinecart>> TNT_X100_MINECART = LuckyTNTMod.RH.registerTNTMinecart("tnt_x100_minecart", TNT_X100, () -> ItemRegistry.TNT_X100_MINECART);
	public static final Supplier<EntityType<LTNTMinecart>> TNT_X500_MINECART = LuckyTNTMod.RH.registerTNTMinecart("tnt_x500_minecart", TNT_X500, () -> ItemRegistry.TNT_X500_MINECART);
	public static final Supplier<EntityType<LTNTMinecart>> DIGGING_TNT_MINECART = LuckyTNTMod.RH.registerTNTMinecart("digging_tnt_minecart", DIGGING_TNT, () -> ItemRegistry.DIGGING_TNT_MINECART);
	public static final Supplier<EntityType<LTNTMinecart>> DRILLING_TNT_MINECART = LuckyTNTMod.RH.registerTNTMinecart("drilling_tnt_minecart", DRILLING_TNT, () -> ItemRegistry.DRILLING_TNT_MINECART);
	public static final Supplier<EntityType<LTNTMinecart>> SPHERE_TNT_MINECART = LuckyTNTMod.RH.registerTNTMinecart("sphere_tnt_minecart", SPHERE_TNT, () -> ItemRegistry.SPHERE_TNT_MINECART);
	public static final Supplier<EntityType<LTNTMinecart>> FLOATING_ISLAND_MINECART = LuckyTNTMod.RH.registerTNTMinecart("floating_island_minecart", FLOATING_ISLAND, () -> ItemRegistry.FLOATING_ISLAND_MINECART);
	public static final Supplier<EntityType<LTNTMinecart>> OCEAN_TNT_MINECART = LuckyTNTMod.RH.registerTNTMinecart("ocean_tnt_minecart", OCEAN_TNT, () -> ItemRegistry.OCEAN_TNT_MINECART);
	public static final Supplier<EntityType<LTNTMinecart>> HELLFIRE_TNT_MINECART = LuckyTNTMod.RH.registerTNTMinecart("hellfire_tnt_minecart", HELLFIRE_TNT, () -> ItemRegistry.HELLFIRE_TNT_MINECART);
	public static final Supplier<EntityType<LTNTMinecart>> FIRE_TNT_MINECART = LuckyTNTMod.RH.registerTNTMinecart("fire_tnt_minecart", FIRE_TNT, () -> ItemRegistry.FIRE_TNT_MINECART);
	public static final Supplier<EntityType<LTNTMinecart>> SNOW_TNT_MINECART = LuckyTNTMod.RH.registerTNTMinecart("snow_tnt_minecart", SNOW_TNT, () -> ItemRegistry.SNOW_TNT_MINECART);
	public static final Supplier<EntityType<LTNTMinecart>> FREEZE_TNT_MINECART = LuckyTNTMod.RH.registerTNTMinecart("freeze_tnt_minecart", FREEZE_TNT, () -> ItemRegistry.FREEZE_TNT_MINECART);
	public static final Supplier<EntityType<LTNTMinecart>> VAPORIZE_TNT_MINECART = LuckyTNTMod.RH.registerTNTMinecart("vaporize_tnt_minecart", VAPORIZE_TNT, () -> ItemRegistry.VAPORIZE_TNT_MINECART);
	public static final Supplier<EntityType<LTNTMinecart>> GRAVITY_TNT_MINECART = LuckyTNTMod.RH.registerTNTMinecart("gravity_tnt_minecart", GRAVITY_TNT, () -> ItemRegistry.GRAVITY_TNT_MINECART, false);
	public static final Supplier<EntityType<LTNTMinecart>> LIGHTNING_TNT_MINECART = LuckyTNTMod.RH.registerTNTMinecart("lightning_tnt_minecart", LIGHTNING_TNT, () -> ItemRegistry.LIGHTNING_TNT_MINECART, false);
	public static final Supplier<EntityType<LTNTMinecart>> CUBIC_TNT_MINECART = LuckyTNTMod.RH.registerTNTMinecart("cubic_tnt_minecart", CUBIC_TNT, () -> ItemRegistry.CUBIC_TNT_MINECART);
	public static final Supplier<EntityType<LTNTMinecart>> ARROW_TNT_MINECART = LuckyTNTMod.RH.registerTNTMinecart("arrow_tnt_minecart", ARROW_TNT, () -> ItemRegistry.ARROW_TNT_MINECART);
	public static final Supplier<EntityType<LTNTMinecart>> TIMER_TNT_MINECART = LuckyTNTMod.RH.registerTNTMinecart("timer_tnt_minecart", TIMER_TNT, () -> ItemRegistry.TIMER_TNT_MINECART, false);
	public static final Supplier<EntityType<LTNTMinecart>> FLAT_TNT_MINECART = LuckyTNTMod.RH.registerTNTMinecart("flat_tnt_minecart", FLAT_TNT, () -> ItemRegistry.FLAT_TNT_MINECART);
	public static final Supplier<EntityType<LTNTMinecart>> MININGFLAT_TNT_MINECART = LuckyTNTMod.RH.registerTNTMinecart("miningflat_tnt_minecart", MININGFLAT_TNT, () -> ItemRegistry.MININGFLAT_TNT_MINECART);
	public static final Supplier<EntityType<LTNTMinecart>> COMPACT_TNT_MINECART = LuckyTNTMod.RH.registerTNTMinecart("compact_tnt_minecart", COMPACT_TNT, () -> ItemRegistry.COMPACT_TNT_MINECART);
	public static final Supplier<EntityType<LTNTMinecart>> ANIMAL_TNT_MINECART = LuckyTNTMod.RH.registerTNTMinecart("animal_tnt_minecart", ANIMAL_TNT, () -> ItemRegistry.ANIMAL_TNT_MINECART);
	public static final Supplier<EntityType<LTNTMinecart>> ERUPTING_TNT_MINECART = LuckyTNTMod.RH.registerTNTMinecart("erupting_tnt_minecart", ERUPTING_TNT, () -> ItemRegistry.ERUPTING_TNT_MINECART, false);
	public static final Supplier<EntityType<LTNTMinecart>> GROVE_TNT_MINECART = LuckyTNTMod.RH.registerTNTMinecart("grove_tnt_minecart", GROVE_TNT, () -> ItemRegistry.GROVE_TNT_MINECART);
	public static final Supplier<EntityType<LTNTMinecart>> ENDER_TNT_MINECART = LuckyTNTMod.RH.registerTNTMinecart("ender_tnt_minecart", ENDER_TNT, () -> ItemRegistry.ENDER_TNT_MINECART);
	public static final Supplier<EntityType<LTNTMinecart>> METEOR_SHOWER_MINECART = LuckyTNTMod.RH.registerTNTMinecart("meteor_shower_minecart", METEOR_SHOWER, () -> ItemRegistry.METEOR_SHOWER_MINECART, false);
	public static final Supplier<EntityType<LTNTMinecart>> INVERTED_TNT_MINECART = LuckyTNTMod.RH.registerTNTMinecart("inverted_tnt_minecart", INVERTED_TNT, () -> ItemRegistry.INVERTED_TNT_MINECART);
	public static final Supplier<EntityType<LTNTMinecart>> NUCLEAR_TNT_MINECART = LuckyTNTMod.RH.registerTNTMinecart("nuclear_tnt_minecart", NUCLEAR_TNT, () -> ItemRegistry.NUCLEAR_TNT_MINECART);
	public static final Supplier<EntityType<LTNTMinecart>> CHEMICAL_TNT_MINECART = LuckyTNTMod.RH.registerTNTMinecart("chemical_tnt_minecart", CHEMICAL_TNT, () -> ItemRegistry.CHEMICAL_TNT_MINECART);
	public static final Supplier<EntityType<LTNTMinecart>> REACTION_TNT_MINECART = LuckyTNTMod.RH.registerTNTMinecart("reaction_tnt_minecart", REACTION_TNT, () -> ItemRegistry.REACTION_TNT_MINECART, false);
	public static final Supplier<EntityType<LTNTMinecart>> VILLAGE_DEFENSE_MINECART = LuckyTNTMod.RH.registerTNTMinecart("village_defense_minecart", VILLAGE_DEFENSE, () -> ItemRegistry.VILLAGE_DEFENSE_MINECART);
	public static final Supplier<EntityType<LTNTMinecart>> ZOMBIE_APOCALYPSE_MINECART = LuckyTNTMod.RH.registerTNTMinecart("zombie_apocalypse_minecart", ZOMBIE_APOCALYPSE, () -> ItemRegistry.ZOMBIE_APOCALYPSE_MINECART);
	public static final Supplier<EntityType<LTNTMinecart>> SHATTERPROOF_TNT_MINECART = LuckyTNTMod.RH.registerTNTMinecart("shatterproof_tnt_minecart", SHATTERPROOF_TNT, () -> ItemRegistry.SHATTERPROOF_TNT_MINECART);
	public static final Supplier<EntityType<LTNTMinecart>> LAVA_OCEAN_TNT_MINECART = LuckyTNTMod.RH.registerTNTMinecart("lava_ocean_tnt_minecart", LAVA_OCEAN_TNT, () -> ItemRegistry.LAVA_OCEAN_TNT_MINECART);
	public static final Supplier<EntityType<LTNTMinecart>> WOOL_TNT_MINECART = LuckyTNTMod.RH.registerTNTMinecart("wool_tnt_minecart", WOOL_TNT, () -> ItemRegistry.WOOL_TNT_MINECART);
	public static final Supplier<EntityType<LTNTMinecart>> SAY_GOODBYE_MINECART = LuckyTNTMod.RH.registerTNTMinecart("say_goodbye_minecart", SAY_GOODBYE, () -> ItemRegistry.SAY_GOODBYE_MINECART, false);
	public static final Supplier<EntityType<LTNTMinecart>> ANGRY_MINERS_MINECART = LuckyTNTMod.RH.registerTNTMinecart("angry_miners_minecart", ANGRY_MINERS, () -> ItemRegistry.ANGRY_MINERS_MINECART);
	public static final Supplier<EntityType<LTNTMinecart>> WITHERING_TNT_MINECART = LuckyTNTMod.RH.registerTNTMinecart("withering_tnt_minecart", WITHERING_TNT, () -> ItemRegistry.WITHERING_TNT_MINECART);
	public static final Supplier<EntityType<LTNTMinecart>> NUCLEAR_WASTE_TNT_MINECART = LuckyTNTMod.RH.registerTNTMinecart("nuclear_waste_tnt_minecart", NUCLEAR_WASTE_TNT, () -> ItemRegistry.NUCLEAR_WASTE_TNT_MINECART);
	public static final Supplier<EntityType<LTNTMinecart>> PUMPKIN_BOMB_MINECART = LuckyTNTMod.RH.registerTNTMinecart("pumpkin_bomb_minecart", PUMPKIN_BOMB, () -> ItemRegistry.PUMPKIN_BOMB_MINECART);
	public static final Supplier<EntityType<LTNTMinecart>> AIR_STRIKE_MINECART = LuckyTNTMod.RH.registerTNTMinecart("air_strike_minecart", AIR_STRIKE, () -> ItemRegistry.AIR_STRIKE_MINECART, false);
	public static final Supplier<EntityType<LTNTMinecart>> SPAMMING_TNT_MINECART = LuckyTNTMod.RH.registerTNTMinecart("spamming_tnt_minecart", SPAMMING_TNT, () -> ItemRegistry.SPAMMING_TNT_MINECART, false);
	public static final Supplier<EntityType<LTNTMinecart>> ROULETTE_TNT_MINECART = LuckyTNTMod.RH.registerTNTMinecart("roulette_tnt_minecart", ROULETTE_TNT, () -> ItemRegistry.ROULETTE_TNT_MINECART);
	public static final Supplier<EntityType<LTNTMinecart>> XRAY_TNT_MINECART = LuckyTNTMod.RH.registerTNTMinecart("xray_tnt_minecart", XRAY_TNT, () -> ItemRegistry.XRAY_TNT_MINECART);
	public static final Supplier<EntityType<LTNTMinecart>> FARMING_TNT_MINECART = LuckyTNTMod.RH.registerTNTMinecart("farming_tnt_minecart", FARMING_TNT, () -> ItemRegistry.FARMING_TNT_MINECART);
	public static final Supplier<EntityType<LTNTMinecart>> SWAP_TNT_MINECART = LuckyTNTMod.RH.registerTNTMinecart("swap_tnt_minecart", SWAP_TNT, () -> ItemRegistry.SWAP_TNT_MINECART, false);
	public static final Supplier<EntityType<LTNTMinecart>> IGNITER_TNT_MINECART = LuckyTNTMod.RH.registerTNTMinecart("igniter_tnt_minecart", IGNITER_TNT, () -> ItemRegistry.IGNITER_TNT_MINECART);
	public static final Supplier<EntityType<LTNTMinecart>> BUTTER_TNT_MINECART = LuckyTNTMod.RH.registerTNTMinecart("butter_tnt_minecart", BUTTER_TNT, () -> ItemRegistry.BUTTER_TNT_MINECART);
	public static final Supplier<EntityType<LTNTMinecart>> PHYSICS_TNT_MINECART = LuckyTNTMod.RH.registerTNTMinecart("physics_tnt_minecart", PHYSICS_TNT, () -> ItemRegistry.PHYSICS_TNT_MINECART);
	public static final Supplier<EntityType<LTNTMinecart>> ORE_TNT_MINECART = LuckyTNTMod.RH.registerTNTMinecart(LuckyTNTMod.MODID, "ore_tnt_minecart", () -> EntityType.Builder.<LTNTMinecart>of(OreTNTMinecart::new, MobCategory.MISC).sized(0.98f, 0.7f).build(ek("ore_tnt_minecart")));
	public static final Supplier<EntityType<LTNTMinecart>> REDSTONE_TNT_MINECART = LuckyTNTMod.RH.registerTNTMinecart("redstone_tnt_minecart", REDSTONE_TNT, () -> ItemRegistry.REDSTONE_TNT_MINECART);
	public static final Supplier<EntityType<LTNTMinecart>> RANDOM_TNT_MINECART = LuckyTNTMod.RH.registerTNTMinecart("random_tnt_minecart", RANDOM_TNT, () -> ItemRegistry.RANDOM_TNT_MINECART);
	public static final Supplier<EntityType<LTNTMinecart>> TURRET_TNT_MINECART = LuckyTNTMod.RH.registerTNTMinecart("turret_tnt_minecart", TURRET_TNT, () -> ItemRegistry.TURRET_TNT_MINECART, false);
	public static final Supplier<EntityType<LTNTMinecart>> PULSE_TNT_MINECART = LuckyTNTMod.RH.registerTNTMinecart("pulse_tnt_minecart", PULSE_TNT, () -> ItemRegistry.PULSE_TNT_MINECART, false);
	public static final Supplier<EntityType<LTNTMinecart>> PICKY_TNT_MINECART = LuckyTNTMod.RH.registerTNTMinecart("picky_tnt_minecart", PICKY_TNT, () -> ItemRegistry.PICKY_TNT_MINECART);
	public static final Supplier<EntityType<LTNTMinecart>> BIG_TNT_MINECART = LuckyTNTMod.RH.registerTNTMinecart("big_tnt_minecart", BIG_TNT, () -> ItemRegistry.BIG_TNT_MINECART);
	public static final Supplier<EntityType<LTNTMinecart>> HONEY_TNT_MINECART = LuckyTNTMod.RH.registerTNTMinecart("honey_tnt_minecart", HONEY_TNT, () -> ItemRegistry.HONEY_TNT_MINECART);
	public static final Supplier<EntityType<LTNTMinecart>> EATING_TNT_MINECART = LuckyTNTMod.RH.registerTNTMinecart("eating_tnt_minecart", EATING_TNT, () -> ItemRegistry.EATING_TNT_MINECART, false);
	public static final Supplier<EntityType<LTNTMinecart>> LUSH_TNT_MINECART = LuckyTNTMod.RH.registerTNTMinecart("lush_tnt_minecart", LUSH_TNT, () -> ItemRegistry.LUSH_TNT_MINECART);
	public static final Supplier<EntityType<LTNTMinecart>> GEODE_TNT_MINECART = LuckyTNTMod.RH.registerTNTMinecart("geode_tnt_minecart", GEODE_TNT, () -> ItemRegistry.GEODE_TNT_MINECART);
	public static final Supplier<EntityType<LTNTMinecart>> NETHER_GROVE_TNT_MINECART = LuckyTNTMod.RH.registerTNTMinecart("nether_grove_tnt_minecart", NETHER_GROVE_TNT, () -> ItemRegistry.NETHER_GROVE_TNT_MINECART);
	public static final Supplier<EntityType<LTNTMinecart>> DRIPSTONE_TNT_MINECART = LuckyTNTMod.RH.registerTNTMinecart("dripstone_tnt_minecart", DRIPSTONE_TNT, () -> ItemRegistry.DRIPSTONE_TNT_MINECART);
	public static final Supplier<EntityType<LTNTMinecart>> END_TNT_MINECART = LuckyTNTMod.RH.registerTNTMinecart("end_tnt_minecart", END_TNT, () -> ItemRegistry.END_TNT_MINECART);
	public static final Supplier<EntityType<LTNTMinecart>> PRISM_TNT_MINECART = LuckyTNTMod.RH.registerTNTMinecart("prism_tnt_minecart", PRISM_TNT, () -> ItemRegistry.PRISM_TNT_MINECART);
	public static final Supplier<EntityType<LTNTMinecart>> RING_TNT_MINECART = LuckyTNTMod.RH.registerTNTMinecart("ring_tnt_minecart", RING_TNT, () -> ItemRegistry.RING_TNT_MINECART);
	public static final Supplier<EntityType<LTNTMinecart>> SCULK_TNT_MINECART = LuckyTNTMod.RH.registerTNTMinecart("sculk_tnt_minecart", SCULK_TNT, () -> ItemRegistry.SCULK_TNT_MINECART);
	
	public static final Supplier<EntityType<LTNTMinecart>> LUCKY_TNT_MINECART = LuckyTNTMod.RH.registerTNTMinecart(LuckyTNTMod.MODID, "lucky_tnt_minecart", () -> EntityType.Builder.<LTNTMinecart>of((type, level) -> new LuckyTNTMinecart(type, level, BlockRegistry.LUCKY_TNT, () -> ItemRegistry.LUCKY_TNT_MINECART, LuckyTNTMod.RH.minecartLists.get("m")), MobCategory.MISC).sized(0.98f, 0.7f).build(ek("lucky_tnt_minecart")));
	
	//Projectile
	public static final Supplier<EntityType<LExplosiveProjectile>> METEOR = LuckyTNTMod.RH.registerExplosiveProjectile("meteor", new MeteorEffect(40, 2f), 2f, false);
	public static final Supplier<EntityType<LExplosiveProjectile>> LITTLE_METEOR = LuckyTNTMod.RH.registerExplosiveProjectile("little_meteor", new MeteorEffect(20, 1.5f), 1.5f, false);
	public static final Supplier<EntityType<LExplosiveProjectile>> SPIRAL_PROJECTILE = LuckyTNTMod.RH.registerExplosiveProjectile("spiral_projectile", new StackedPrimedTNTEffect(new SpiralTNTEffect(), Collections.singletonList(TNT_X5_EFFECT.build())));
	public static final Supplier<EntityType<LExplosiveProjectile>> ERUPTING_PROJECTILE = LuckyTNTMod.RH.registerExplosiveProjectile("erupting_projectile", new StackedPrimedTNTEffect(new EruptingTNTEffect(), Collections.singletonList(TNT_X5_EFFECT.fire(true).build())), 1f, false);
	public static final Supplier<EntityType<LExplosiveProjectile>> MINI_METEOR = LuckyTNTMod.RH.registerExplosiveProjectile("mini_meteor", new StackedPrimedTNTEffect(new MiniMeteorEffect(), Collections.singletonList(new TNTXStrengthEffect.Builder().strength(7).randomVecLength(1.25f).fire(true).build())), 1f, false);
	public static final Supplier<EntityType<LExplosiveProjectile>> CHEMICAL_PROJECTILE = LuckyTNTMod.RH.registerExplosiveProjectile("chemical_projectile", new ChemicalTNTEffect());
	public static final Supplier<EntityType<LExplosiveProjectile>> CLUSTER_BOMB = LuckyTNTMod.RH.registerExplosiveProjectile("cluster_bomb", new ClusterBombEffect());
	public static final Supplier<EntityType<LExplosiveProjectile>> SHRAPNEL = LuckyTNTMod.RH.registerExplosiveProjectile("shrapnel", new ShrapnelEffect(), 0.25f, true);
	public static final Supplier<EntityType<LExplosiveProjectile>> BOMB = LuckyTNTMod.RH.registerExplosiveProjectile("bomb", new BombEffect());
	public static final Supplier<EntityType<LExplosiveProjectile>> ICE_METEOR = LuckyTNTMod.RH.registerExplosiveProjectile("ice_meteor", new IceMeteorEffect(40, 2f), 2f, false);
	public static final Supplier<EntityType<LExplosiveProjectile>> LITTLE_ICE_METEOR = LuckyTNTMod.RH.registerExplosiveProjectile("little_ice_meteor", new IceMeteorEffect(20, 1.5f), 1.5f, false);
	public static final Supplier<EntityType<LExplosiveProjectile>> POMPEII_PROJECTILE = LuckyTNTMod.RH.registerExplosiveProjectile("pompeii_projectile", new StackedPrimedTNTEffect(new PompeiiEffect(), Collections.singletonList(new TNTXStrengthEffect.Builder().strength(6).randomVecLength(1.25f).knockbackStrength(1.5f).fire(true).build())), 1f, false);
	public static final Supplier<EntityType<LExplosiveProjectile>> CHICXULUB_METEOR = LuckyTNTMod.RH.registerExplosiveProjectile("chicxulub_meteor", new ChicxulubMeteorEffect(), 4f, false);
	public static final Supplier<EntityType<LExplosiveProjectile>> TSAR_BOMBA_BOMB = LuckyTNTMod.RH.registerExplosiveProjectile("tsar_bomba_bomb", new TsarBombaBombEffect(), 1.2f, false);
	public static final Supplier<EntityType<LExplosiveProjectile>> PRESENT = LuckyTNTMod.RH.registerExplosiveProjectile("present", new StackedPrimedTNTEffect(new ChristmasTNTEffect(), Collections.singletonList(TNT_X5_EFFECT.build())));
	public static final Supplier<EntityType<LExplosiveProjectile>> ACIDIC_PROJECTILE = LuckyTNTMod.RH.registerExplosiveProjectile("acidic_projectile", new AcidicTNTEffect(), 1f, false);
	public static final Supplier<EntityType<LExplosiveProjectile>> HAILSTONE = registerEntity("hailstone", () -> EntityType.Builder.<LExplosiveProjectile>of((EntityType<LExplosiveProjectile> type, Level level) -> new HailstoneProjectile(type, level, new HailstoneEffect()), MobCategory.MISC).clientTrackingRange(64).sized(0.1f, 0.1f).build(ek("hailstone")));
	public static final Supplier<EntityType<LExplosiveProjectile>> CHRISTMAS_DYNAMITE_PROJECTILE = LuckyTNTMod.RH.registerExplosiveProjectile("christmas_dynamite_projectile", new ChristmasDynamiteProjectileEffect(), 0.25f, false);
	public static final Supplier<EntityType<LExplosiveProjectile>> DEATH_RAY_RAY = LuckyTNTMod.RH.registerExplosiveProjectile("death_ray_ray", new DeathRayRayEffect(), 0.25f, true);
	public static final Supplier<EntityType<LExplosiveProjectile>> VACUUM_SHOT = LuckyTNTMod.RH.registerExplosiveProjectile("vacuum_shot", new VacuumShotEffect(), 0.25f, true);
	public static final Supplier<EntityType<LExplosiveProjectile>> SOLAR_ERUPTION_PROJECTILE = LuckyTNTMod.RH.registerExplosiveProjectile("solar_eruption_projectile", new SolarEruptionProjectileEffect(), 1f, false);
	public static final Supplier<EntityType<LExplosiveProjectile>> VREDEFORT_PROJECTILE = LuckyTNTMod.RH.registerExplosiveProjectile("vredefort_projectile", new VredefortProjectileEffect(), 6f, false);
	public static final Supplier<EntityType<LExplosiveProjectile>> HYDROGEN_BOMB_BOMB = LuckyTNTMod.RH.registerExplosiveProjectile("hydrogen_bomb_bomb", new HydrogenBombBombEffect(), 1.4f, false);
	public static final Supplier<EntityType<LExplosiveProjectile>> DISINTEGRATING_PROJECTILE = LuckyTNTMod.RH.registerExplosiveProjectile("disintegrating_projectile", new DisintegratingProjectileEffect(), 1f, false);
	public static final Supplier<EntityType<LExplosiveProjectile>> MINI_ICE_METEOR = LuckyTNTMod.RH.registerExplosiveProjectile("mini_ice_meteor", new MiniIceMeteorEffect(), 1f, false);
	public static final Supplier<EntityType<LExplosiveProjectile>> DEIMOS_METEOR = LuckyTNTMod.RH.registerExplosiveProjectile("deimos_meteor", new DeimosMeteorEffect(), 4f, false);
	public static final Supplier<EntityType<LExplosiveProjectile>> PHOBOS_METEOR = LuckyTNTMod.RH.registerExplosiveProjectile("phobos_meteor", new PhobosMeteorEffect(), 6f, false);
	public static final Supplier<EntityType<LExplosiveProjectile>> PRESENT_METEOR = LuckyTNTMod.RH.registerExplosiveProjectile("present_meteor", new PresentMeteorEffect(), 4f, false);
	
	//Other
	public static Supplier<EntityType<AngryMiner>> ANGRY_MINER = registerEntity("angry_miner", () -> EntityType.Builder.<AngryMiner>of(AngryMiner::new, MobCategory.MISC).sized(0.6f, 1.8f).build(ek("angry_miner")));
	public static final Supplier<EntityType<PrimedLTNT>> TOXIC_CLOUD = LuckyTNTMod.RH.registerTNTEntity("toxic_cloud", new ToxicCloudEffect());
	
	//BlockEntities
	public static final Supplier<BlockEntityType<SmokeTNTBlockEntity>> SMOKE_TNT_BLOCK_ENTITY = registerBlockEntity("smoke_tnt_block_entity", () -> new BlockEntityType<>(SmokeTNTBlockEntity::new, java.util.Set.of(BlockRegistry.SMOKE_TNT.get())));
	public static final Supplier<BlockEntityType<ItemFireworkBlockEntity>> ITEM_FIREWORK_BLOCK_ENTITY = registerBlockEntity("item_firework_block_entity", () -> new BlockEntityType<>(ItemFireworkBlockEntity::new, java.util.Set.of(BlockRegistry.ITEM_FIREWORK.get())));

	public static net.minecraft.world.entity.ai.targeting.TargetingConditions.Selector PREDICATE = (living, level) -> {
		return living instanceof Player player ? !player.isCreative() && !player.isSpectator() : false;
	};

	public static net.minecraft.resources.ResourceKey<EntityType<?>> ek(String name) {
		return net.minecraft.resources.ResourceKey.create(net.minecraft.core.registries.Registries.ENTITY_TYPE, Identifier.fromNamespaceAndPath(LuckyTNTMod.MODID, name));
	}

	public static <T extends Entity> Supplier<EntityType<T>> registerEntity(String name, Supplier<EntityType<T>> entitySupplier) {
		EntityType<T> rtype = Registry.register(BuiltInRegistries.ENTITY_TYPE, Identifier.fromNamespaceAndPath(LuckyTNTMod.MODID, name), entitySupplier.get());
		return () -> rtype;
	}
	
	public static <F extends BlockEntity> Supplier<BlockEntityType<F>> registerBlockEntity(String name, Supplier<BlockEntityType<F>> entitySupplier) {
		BlockEntityType<F> rtype = Registry.register(BuiltInRegistries.BLOCK_ENTITY_TYPE, Identifier.fromNamespaceAndPath(LuckyTNTMod.MODID, name), entitySupplier.get());
		return () -> rtype;
	}
	
	public static void init() {}

	private static DustParticleOptions dustParticle(float r, float g, float b, float scale) {
		int ri = Math.max(0, Math.min(255, (int)(r * 255f)));
		int gi = Math.max(0, Math.min(255, (int)(g * 255f)));
		int bi = Math.max(0, Math.min(255, (int)(b * 255f)));
		return new DustParticleOptions(ARGB.color(ri, gi, bi), scale);
	}
}
