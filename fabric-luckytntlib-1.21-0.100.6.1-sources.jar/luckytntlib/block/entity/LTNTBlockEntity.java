package luckytntlib.block.entity;

import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_7225;

public class LTNTBlockEntity extends class_2586 {
	
	protected class_2487 persistentData = new class_2487();
	private String PERSISTENT_DATA_TAG = "PersistentData";

	public LTNTBlockEntity(class_2591<?> type, class_2338 pos, class_2680 state) {
		super(type, pos, state);
	}
	
	@Override
	public void method_11007(class_2487 nbt, class_7225.class_7874 registryLookup) {
		super.method_11007(nbt, registryLookup);
		nbt.method_10566(PERSISTENT_DATA_TAG, persistentData);
	}
	
	@Override
	public void method_11014(class_2487 nbt, class_7225.class_7874 registryLookup) {
		super.method_11014(nbt, registryLookup);
		persistentData = nbt.method_10562(PERSISTENT_DATA_TAG);
	}
	
	public class_2487 getPersistentData() {
		return persistentData;
	}
}
