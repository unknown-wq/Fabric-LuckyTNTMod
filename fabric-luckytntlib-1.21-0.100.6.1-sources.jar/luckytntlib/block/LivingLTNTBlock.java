package luckytntlib.block;

import java.util.Random;
import java.util.function.Supplier;

import org.jetbrains.annotations.Nullable;

import luckytntlib.entity.LivingPrimedLTNT;
import luckytntlib.entity.PrimedLTNT;
import net.minecraft.class_1282;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1541;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3532;
import net.minecraft.class_4970;

/**
 * The LivingLTNTBlock is a simple extension of the {@link LTNTBlock} and only serves the purpose of hosting
 * a {@link LivingPrimedLTNT} instead of a {@link PrimedLTNT}.
 * This class is necessary because Minecraft's {@link class_1309} is fundamentally different from {@link class_1541}.
 */
public class LivingLTNTBlock extends LTNTBlock{

	@Nullable
	protected Supplier<class_1299<LivingPrimedLTNT>> TNT;
	protected Random random = new Random();
	
	public LivingLTNTBlock(class_4970.class_2251 properties, @Nullable Supplier<class_1299<LivingPrimedLTNT>> TNT, boolean randomizedFuseUponExploded) {
		super(properties, null, randomizedFuseUponExploded);
		this.TNT = TNT;
	}
	
	@Override
	@Nullable
	public PrimedLTNT explode(class_1937 level, boolean exploded, double x, double y, double z, @Nullable class_1309 igniter) {
		explodus(level, exploded, x, y, z, igniter);
		return null;
	}
	
	/**
	 * Spawns a new {@link LivingPrimedLTNT} held by this block
	 * @param level  the current level
	 * @param exploded  whether or not the block was destroyed by another explosion (used for randomized fuse)
	 * @param x  the x position
	 * @param y  the y position
	 * @param z  the z position
	 * @param igniter  the owner for the spawned TNT (used primarely for the {@link class_1282})
	 * @return {@link LivingPrimedLTNT} or null
	 * @throws NullPointerException
	 */
	@Nullable
	public LivingPrimedLTNT explodus(class_1937 level, boolean exploded, double x, double y, double z, @Nullable class_1309 igniter) throws NullPointerException {
		if(TNT != null) {
			LivingPrimedLTNT tnt = TNT.get().method_5883(level);
			tnt.setTNTFuse(exploded && randomizedFuseUponExploded() ? tnt.getEffect().getDefaultFuse(tnt) / 8 + random.nextInt(class_3532.method_15340(tnt.getEffect().getDefaultFuse(tnt) / 4, 1, Integer.MAX_VALUE)) : tnt.getEffect().getDefaultFuse(tnt));
			tnt.method_5814(x + 0.5f, y, z + 0.5f);
			tnt.setOwner(igniter);
			level.method_8649(tnt);
			level.method_8396(null, new class_2338((int)x, (int)y, (int)z), class_3417.field_15079, class_3419.field_15250, 1, 1);
			if(level.method_8320(new class_2338((int)x, (int)y, (int)z)).method_26204() == this) {				
				level.method_8652(new class_2338((int)x, (int)y, (int)z), class_2246.field_10124.method_9564(), 3);
			}
			return tnt;
		}
		throw new NullPointerException("Living TNT entity type is null");
	}
}
