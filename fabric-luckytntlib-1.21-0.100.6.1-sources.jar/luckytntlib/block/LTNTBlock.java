package luckytntlib.block;

import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.function.Supplier;

import org.jetbrains.annotations.Nullable;

import luckytntlib.entity.PrimedLTNT;
import net.minecraft.class_1268;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1541;
import net.minecraft.class_1657;
import net.minecraft.class_1676;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1927;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2357;
import net.minecraft.class_2530;
import net.minecraft.class_2680;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3468;
import net.minecraft.class_3481;
import net.minecraft.class_3532;
import net.minecraft.class_3965;
import net.minecraft.class_4838;
import net.minecraft.class_4970;
import net.minecraft.class_5712;
import net.minecraft.class_8567;
import net.minecraft.class_9062;

/**
 * The {@link LTNTBlock} is an extension of the {@link class_2530} and it spawns a {@link PrimedLTNT} instead of a {@link class_1541}.
 * If a {@link class_2357} has been registered dispensers can also spawn the TNT.
 */
public class LTNTBlock extends class_2530 {

	@Nullable
	protected Supplier<class_1299<PrimedLTNT>> TNT;
	protected Random random = new Random();
	protected boolean randomizedFuseUponExploded = true;
	
	public LTNTBlock(class_4970.class_2251 properties, @Nullable Supplier<class_1299<PrimedLTNT>> TNT, boolean randomizedFuseUponExploded) {
		super(properties);
		this.TNT = TNT;
		this.randomizedFuseUponExploded = randomizedFuseUponExploded;
	}
	
	@Override
	public void method_9615(class_2680 state, class_1937 world, class_2338 pos, class_2680 oldState, boolean notify) {
		if (oldState.method_27852(state.method_26204())) {
			return;
		}
		if (world.method_49803(pos)) {
			explode(world, false, pos.method_10263(), pos.method_10264(), pos.method_10260(), null);
			world.method_8650(pos, false);
		}
	}

	@Override
	public void method_9612(class_2680 state, class_1937 world, class_2338 pos, class_2248 sourceBlock, class_2338 sourcePos, boolean notify) {
		if (world.method_49803(pos)) {
			explode(world, false, pos.method_10263(), pos.method_10264(), pos.method_10260(), null);
			world.method_8650(pos, false);
		}
	}

	@Override
	public class_2680 method_9576(class_1937 world, class_2338 pos, class_2680 state, class_1657 player) {
		if (!world.method_8608() && !player.method_7337() && state.method_11654(field_11621).booleanValue()) {
			explode(world, false, pos.method_10263(), pos.method_10264(), pos.method_10260(), null);
		}
		
		method_33614(world, player, pos, state);
        if (state.method_26164(class_3481.field_23800)) {
            class_4838.method_24733(player, false);
        }
        world.method_43276(class_5712.field_28165, pos, class_5712.class_7397.method_43286(player, state));
        return state;
	}
	
	@Override
	public float method_9520() {
		return 0f;
	}
	
	@Override
	public List<class_1799> method_9560(class_2680 state, class_8567.class_8568 builder) {
		return Collections.singletonList(new class_1799(this));
	}
	
	@Override
	public void method_9586(class_1937 level, class_2338 pos, class_1927 explosion) {
		if(!level.method_8608()) {
			explode(level, true, pos.method_10263(), pos.method_10264(), pos.method_10260(), explosion.method_8347());
		}
	}
	
	/**
	 * Spawns a new {@link PrimedLTNT} held by this block
	 * @param level  the current level
	 * @param exploded  whether or not the block was destroyed by another explosion (used for randomized fuse)
	 * @param x  the x position
	 * @param y  the y position
	 * @param z  the z position
	 * @param igniter  the owner for the spawned TNT (used primarely for the {@link class_1282})
	 * @return {@link PrimedLTNT} or null
	 * @throws NullPointerException
	 */
	@Nullable
	public PrimedLTNT explode(class_1937 level, boolean exploded, double x, double y, double z, @Nullable class_1309 igniter) throws NullPointerException {
		if(TNT != null) {
			PrimedLTNT tnt = TNT.get().method_5883(level);
			tnt.method_6967(exploded && randomizedFuseUponExploded() ? tnt.getEffect().getDefaultFuse(tnt) / 8 + random.nextInt(class_3532.method_15340(tnt.getEffect().getDefaultFuse(tnt) / 4, 1, Integer.MAX_VALUE)) : tnt.getEffect().getDefaultFuse(tnt));
			tnt.method_5814(x + 0.5f, y, z + 0.5f);
			tnt.setOwner(igniter);
			level.method_8649(tnt);
			level.method_8396(null, new class_2338((int)x, (int)y, (int)z), class_3417.field_15079, class_3419.field_15250, 1, 1);
			if(level.method_8320(new class_2338((int)x, (int)y, (int)z)).method_26204() == this) {
				level.method_8652(new class_2338((int)x, (int)y, (int)z), class_2246.field_10124.method_9564(), 3);
			}
			return tnt;
		}
		throw new NullPointerException("TNT entity type is null");
	}
	
	@Override
	public class_9062 method_55765(class_1799 stack, class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit) {
		class_1799 itemStack = player.method_5998(hand);
		if (itemStack.method_31574(class_1802.field_8884) || itemStack.method_31574(class_1802.field_8814)) {
			explode(world, false, pos.method_10263(), pos.method_10264(), pos.method_10260(), player);
			world.method_8652(pos, class_2246.field_10124.method_9564(), class_2248.field_31022);
			class_1792 item = itemStack.method_7909();
			if (!player.method_7337()) {
				if (itemStack.method_31574(class_1802.field_8884)) {
					itemStack.method_7970(1, player, hand == class_1268.field_5808 ? class_1304.field_6173 : class_1304.field_6171);
				} else {
					itemStack.method_7934(1);
				}
			}
			player.method_7259(class_3468.field_15372.method_14956(item));
			return class_9062.method_55644(world.field_9236);
		}
		return class_9062.field_47731;
	}

	@Override
	public void method_19286(class_1937 world, class_2680 state, class_3965 hit, class_1676 projectile) {
		if (!world.field_9236) {
			class_2338 blockPos = hit.method_17777();
			class_1297 entity = projectile.method_24921();
			if (projectile.method_5809() && projectile.method_36971(world, blockPos)) {
				explode(world, false, blockPos.method_10263(), blockPos.method_10264(), blockPos.method_10260(), entity instanceof class_1309 ? (class_1309) entity : null);
				world.method_8650(blockPos, false);
			}
		}
	}
	
	public boolean randomizedFuseUponExploded() {
		return randomizedFuseUponExploded;
	}
}
