package luckytntlib.block;

import java.util.List;
import java.util.function.Supplier;

import org.jetbrains.annotations.Nullable;

import luckytntlib.entity.PrimedLTNT;
import luckytntlib.registry.RegistryHelper;
import net.minecraft.class_1282;
import net.minecraft.class_1309;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_4970;

/**
 * The LuckyTNTBlock is an extension of the {@link LTNTBlock} and serves the simple purpose of spawning a random
 * {@link PrimedLTNT} of a {@link LTNTBlock} contained in a {@link List}.
 * The list could for instance be set to one of the many lists of {@link LTNTBlock} found in the {@link RegistryHelper}.
 */
public class LuckyTNTBlock extends LTNTBlock{

	public List<Supplier<LTNTBlock>> TNTs;
	
	public LuckyTNTBlock(class_4970.class_2251 properties, List<Supplier<LTNTBlock>> TNTs) {
		super(properties, null, false);
		this.TNTs = TNTs;
	}
	
	/**
	 * Gets a random {@link LTNTBlock} from the list held by this block and calls its explode method.
	 * Can not explode another {@link LuckyTNTBlock}.
	 * @param level  the current level
	 * @param exploded  whether or not the block was destroyed by another explosion (used for randomized fuse)
	 * @param x  the x position
	 * @param y  the y position
	 * @param z  the z position
	 * @param igniter  the owner for the spawned TNT (used primarely for the {@link class_1282})
	 * @return {@link PrimedLTNT}
	 */
	@Override
	public PrimedLTNT explode(class_1937 level, boolean exploded, double x, double y, double z, @Nullable class_1309 igniter) {
		int rand = random.nextInt(TNTs.size());
		if(level.method_8320(new class_2338((int)x, (int)y, (int)z)).method_26204() == this) {
			level.method_8652(new class_2338((int)x, (int)y, (int)z), class_2246.field_10124.method_9564(), 3);
		}
		return TNTs.get(rand).get().explode(level, exploded, x, y, z, igniter);
	}
}
