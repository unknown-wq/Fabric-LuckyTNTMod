package luckytntlib.registry;

/**
 * Registers the Config Item, which can be used to add your own config screens
 */
import java.util.function.Supplier;

import luckytntlib.LuckyTNTLib;
import luckytntlib.item.TNTConfigItem;
import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class ItemRegistry {
	
	public static final Supplier<class_1792> CONFIG_ITEM = registerItem("tnt_config", new TNTConfigItem());

	public static Supplier<class_1792> registerItem(String name, class_1792 item) {
		class_1792 ritem = class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(LuckyTNTLib.MODID, name), item);
		return () -> ritem;
	}
	
	public static void init() {}
}
