package luckytntlib.registry;

import luckytntlib.LuckyTNTLib;
import luckytntlib.config.LuckyTNTLibConfigValues;
import luckytntlib.config.common.Config;
import luckytntlib.network.ClientReadyC2SPacket;
import luckytntlib.network.UpdateConfigValuesPacket;
import net.fabricmc.api.EnvType;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking.Context;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking.PlayPayloadHandler;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_3218;
import net.minecraft.class_3222;

public class NetworkRegistry {
	
	private static final PlayPayloadHandler<UpdateConfigValuesPacket> UPDATE_C2S = new PlayPayloadHandler<UpdateConfigValuesPacket>() {
		
		@Override
		public void receive(UpdateConfigValuesPacket payload, Context context) {
			class_2487 tag = payload.data;
			
			Config.writeToValues(tag, LuckyTNTLibConfigValues.CONFIG.getConfigValues());
			
			LuckyTNTLibConfigValues.CONFIG.save(context.server().method_3847(class_1937.field_25179));
		}
	};
	private static final PlayPayloadHandler<ClientReadyC2SPacket> READY_C2S = new PlayPayloadHandler<ClientReadyC2SPacket>() {
		
		@Override
		public void receive(ClientReadyC2SPacket payload, Context context) {
			for(class_3218 world : context.server().method_3738()) {
				for(class_3222 entity : world.method_18456()) {
					LuckyTNTLib.RH.sendS2CPacket(entity, new UpdateConfigValuesPacket(LuckyTNTLibConfigValues.CONFIG.getConfigValues()));
				}
			}
		}
	};

	public static void init() {
		PayloadTypeRegistry.playC2S().register(UpdateConfigValuesPacket.ID, UpdateConfigValuesPacket.CODEC);
		PayloadTypeRegistry.playC2S().register(ClientReadyC2SPacket.ID, ClientReadyC2SPacket.CODEC);
		
		PayloadTypeRegistry.playS2C().register(UpdateConfigValuesPacket.ID, UpdateConfigValuesPacket.CODEC);
		
		if(FabricLoader.getInstance().getEnvironmentType() == EnvType.CLIENT) {
			ClientNetworkRegistry.init();
		}
		
		ServerPlayNetworking.registerGlobalReceiver(UpdateConfigValuesPacket.ID, UPDATE_C2S);
		ServerPlayNetworking.registerGlobalReceiver(ClientReadyC2SPacket.ID, READY_C2S);
	}
}
