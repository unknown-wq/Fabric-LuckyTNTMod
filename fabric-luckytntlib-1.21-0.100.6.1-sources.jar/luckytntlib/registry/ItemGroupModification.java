package luckytntlib.registry;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.class_7706;

public class ItemGroupModification {

	public static void init() {
		ItemGroupEvents.modifyEntriesEvent(class_7706.field_41062).register(content -> {
			content.method_45421(ItemRegistry.CONFIG_ITEM.get());
		});
	}
}
