package luckytntlib;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import luckytntlib.block.LTNTBlock;
import luckytntlib.client.ClientAccess;
import luckytntlib.config.LuckyTNTLibConfigValues;
import luckytntlib.registry.EventRegistry;
import luckytntlib.registry.ItemGroupModification;
import luckytntlib.registry.ItemRegistry;
import luckytntlib.registry.NetworkRegistry;
import luckytntlib.registry.RegistryHelper;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2315;
import net.minecraft.class_2338;
import net.minecraft.class_2342;
import net.minecraft.class_2350;
import net.minecraft.class_2530;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2969;
import net.minecraft.class_3218;
import net.minecraft.class_3922;
import net.minecraft.class_4770;
import net.minecraft.class_5544;
import net.minecraft.class_5545;
import net.minecraft.class_5712;

public class LuckyTNTLib implements ModInitializer {
    
	public static final String MODID = "luckytntlib";
	public static final Logger LOGGER = LoggerFactory.getLogger(MODID);
	public static final RegistryHelper RH = new RegistryHelper(MODID);
    
    @Override
	public void onInitialize() {
    	ItemRegistry.init();
    	ItemGroupModification.init();
    	NetworkRegistry.init();
    	
    	if(FabricLoader.getInstance().getEnvironmentType() == EnvType.CLIENT) {
        	EventRegistry.init();
        	
    		RH.registerConfigScreenFactory(class_2561.method_43470("Lucky TNT Lib"), ClientAccess.getFactory());
    	}
    	
    	LuckyTNTLibConfigValues.registerConfig();
    	
    	changeFlintAndSteelDispenserBehavior();
    }
    
	private void changeFlintAndSteelDispenserBehavior() {
		class_2315.method_10009(class_1802.field_8884, new class_2969() {

			@Override
			protected class_1799 method_10135(class_2342 pointer, class_1799 stack) {
				class_3218 world = pointer.comp_1967();
				method_27955(true);
				class_2350 direction = pointer.comp_1969().method_11654(class_2315.field_10918);
				class_2338 blockPos = pointer.comp_1968().method_10093(direction);
				class_2680 blockState = world.method_8320(blockPos);
				if (class_4770.method_30032(world, blockPos, direction)) {
					world.method_8501(blockPos, class_4770.method_24416(world, blockPos));
					world.method_33596(null, class_5712.field_28164, blockPos);
				} else if (class_3922.method_30035(blockState) || class_5544.method_31630(blockState) || class_5545.method_31635(blockState)) {
					world.method_8501(blockPos, (class_2680) blockState.method_11657(class_2741.field_12548, true));
					world.method_33596(null, class_5712.field_28733, blockPos);
				} else if (blockState.method_26204() instanceof class_2530 tnt) {
					if(tnt instanceof LTNTBlock ltnt) {
	    				ltnt.explode(world, false, blockPos.method_10263(), blockPos.method_10264(), blockPos.method_10260(), null);
	    			} else {
	                	class_2530.method_10738(world, blockPos);
	    			}
					world.method_8652(blockPos, class_2246.field_10124.method_9564(), 3);
				} else {
					method_27955(false);
				}
				if (this.method_27954()) {
					stack.method_7956(1, world, null, (i) -> stack.method_7939(0));
				}
				return stack;
			}
		});
	}
}
