package luckytntlib.config.common;

import net.minecraft.class_437;

public interface ConfigScreenFactory {
	class_437 apply();
}
