package luckytntlib.util.tnteffects;

import luckytntlib.entity.LExplosiveProjectile;
import luckytntlib.entity.LTNTMinecart;
import luckytntlib.entity.LivingPrimedLTNT;
import luckytntlib.entity.PrimedLTNT;
import luckytntlib.util.IExplosiveEntity;
import net.minecraft.class_1297;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3532;

/**
 * Extensions of this class serve as a way to define how a TNT, Minecart or Dynamite behaves.
 * <p>
 * It controls what a TNT does upon exploding, what particles it displays, what Block/Item gets rendered 
 * and general logic like conditions for exploding.
 */
public abstract class PrimedTNTEffect{	
	/**
	 * 
	 * This void is the heart of the PrimedTNTEffect. It's executed every tick on both the logical client and the logical server side 
	 * and is slightly different for every entity implementing {@link IExplosiveEntity} provided by this library.
	 * <p>
	 * Its default implementation works for all Explosives with little complexity in their behavior.
	 * <p>
	 * Override this method if you want to change the way your TNT behaves on a basic level 
	 * or if you want to add logic for your own entity implementing {@link IExplosiveEntity}
	 * @param entity  the {@link IExplosiveEntity} this PrimedTNTEffect belongs to.
	 */
	public void baseTick(IExplosiveEntity entity) {
		class_1937 level = entity.getLevel();
		/**
		 * Default logic implementation for TNT and TNT Minecarts
		 */
		if(entity instanceof PrimedLTNT || entity instanceof LivingPrimedLTNT || entity instanceof LTNTMinecart) {
			if(entity.getTNTFuse() <= 0) {
				if(entity.getLevel() instanceof class_3218) {
					if(playsSound()) {
						level.method_45445((class_1297)entity, new class_2338(toBlockPos(entity.getPos())), class_3417.field_15152.comp_349(), class_3419.field_15245, 4f, (1f + (level.field_9229.method_43057() - level.field_9229.method_43057()) * 0.2f) * 0.7f);
					}
					serverExplosion(entity);
				}
				entity.destroy();
			}
			explosionTick(entity);
			entity.setTNTFuse(entity.getTNTFuse() - 1);
		}
		/**
		 * Default logic implementation for Explosive Projectiles
		 */
		else if(entity instanceof LExplosiveProjectile ent) {
			if((ent.inGround() || ent.hitEntity()) && entity.getLevel() instanceof class_3218) {
				if(explodesOnImpact()) {
					ent.setTNTFuse(0);
				}
				if(ent.getTNTFuse() == 0) {
					if(ent.method_37908() instanceof class_3218) {
						if(playsSound()) {
							level.method_45445((class_1297)entity, new class_2338(toBlockPos(entity.getPos())), class_3417.field_15152.comp_349(), class_3419.field_15245, 4f, (1f + (level.field_9229.method_43057() - level.field_9229.method_43057()) * 0.2f) * 0.7f);
						}
						serverExplosion(entity);
					}
					ent.destroy();
				}
			}
			else if(airFuse() && entity.getTNTFuse() == 0) {
				if(ent.method_37908() instanceof class_3218) {
					if(playsSound()) {
						level.method_45445((class_1297)entity, new class_2338(toBlockPos(entity.getPos())), class_3417.field_15152.comp_349(), class_3419.field_15245, 4f, (1f + (level.field_9229.method_43057() - level.field_9229.method_43057()) * 0.2f) * 0.7f);
					}
					serverExplosion(entity);
				}
				ent.destroy();
			}
			if((ent.getTNTFuse() > 0 && airFuse()) || ent.hitEntity() || ent.inGround()) {
				explosionTick(ent);
				ent.setTNTFuse(ent.getTNTFuse() - 1);
			}
		}

		if(level.field_9236) {
			spawnParticles(entity);
		}
	}
	
	/**
	 * This void is executed on the logical client side by {@link PrimedTNTEffect#baseTick(IExplosiveEntity)} every tick.
	 * <p>
	 * Override this void if you want to display different particles or if you want no particles at all.
	 * @param entity  the {@link IExplosiveEntity} this PrimedTNTEffect belongs to.
	 */
	public void spawnParticles(IExplosiveEntity entity) {
		entity.getLevel().method_8406(class_2398.field_11251, entity.x(), entity.y() + 0.5f, entity.z(), 0, 0, 0);
	}
	
	/**
	 * This void is executed on the logical server side by {@link PrimedTNTEffect#baseTick(IExplosiveEntity)} once the fuse hits 0 or another condition, like a projectile hitting a block, is met.
	 * <p>
	 * @implNote Due to the immediate removal of the entity after the execution of this method, synchronization inconsistencies arise and a clientExplosion is not supported. If you require one you need to override {@link PrimedTNTEffect#baseTick(IExplosiveEntity)} or create your own independent function
	 * @param entity  the {@link IExplosiveEntity} this PrimedTNTEffect belongs to.
	 */
	public void serverExplosion(IExplosiveEntity entity) {	
	}
	
	/**
	 * This void is executed on both logical sides by {@link PrimedTNTEffect#baseTick(IExplosiveEntity)} every tick.
	 * @param entity  the {@link IExplosiveEntity} this PrimedTNTEffect belongs to.
	 */
	public void explosionTick(IExplosiveEntity entity) {		
	}
	
	/**
	 * @param entity  the {@link IExplosiveEntity} this PrimedTNTEffect belongs to.
	 * @implNote defaults to 80 (4 seconds)
	 * @return Default Fuse of this Epxlosive Entity.
	 */
	public int getDefaultFuse(IExplosiveEntity entity) {
		return 80;
	}
	
	/**
	 * @param entity  the {@link IExplosiveEntity} this PrimedTNTEffect belongs to.
	 * @implNote defaults to 1f
	 * @return Size of this entity for the renderer.
	 */
	public float getSize(IExplosiveEntity entity) {
		return 1f;
	}
	
	/**
	 * @implNote defaults to true
	 * @return Whether or not this TNT plays an explosion sound when executing {@link PrimedTNTEffect#serverExplosion(IExplosiveEntity)}.
	 */
	public boolean playsSound() {
		return true;
	}
	
	/**
	 * @implNote Only used by {@link LExplosiveProjectile}!
	 * @implNote defaults to true
	 * @return Whether or not this Explosive Projectile explodes upon hitting a block or an entity or not
	 */
	public boolean explodesOnImpact() {
		return true;
	}
	
	/**
	 * @implNote Only used by {@link LExplosiveProjectile}!
	 * @implNote defaults to false
	 * @return Whether or not this Explosive Projectile's fuse should tick down while still in the air
	 */
	public boolean airFuse() {
		return false;
	}
	
	/**
	 * Gets the Itemstack that is rendererd!	 
	 * @implNote Useless if no Item is rendered or this method is not called
	 * @return {@link class_1799} to render.
	 */
	public class_1799 getItemStack() {
		return new class_1799(getItem());
	}
	
	/**
	 * Gets the Item that is rendererd!
	 * @implNote Useless if no Item is rendered or this method is not called
	 * @return {@link class_1792} used for the {@link class_1799} of {@link PrimedTNTEffect#getItemStack()}
	 */
	public class_1792 getItem() {
		return class_1802.field_8162;
	}
	
	/**
	 * Gets the Blockstate that is rendered!
	 * @implNote Useless if no Block is rendered or this method is not called
	 * @param entity  the {@link IExplosiveEntity} this PrimedTNTEffect belongs to.
	 * @return {@link class_2680} to render.
	 */
	public class_2680 getBlockState(IExplosiveEntity entity) {
		return getBlock().method_9564();
	}
	
	/**
	 * Gets the Block that is rendered!
	 * @implNote Useless if no Block is rendered or this method is not called.
	 * @return {@link class_2248} used for the {@link class_2680} of {@link PrimedTNTEffect#getBlockState(IExplosiveEntity)}.
	 */
	public class_2248 getBlock() {
		return class_2246.field_10375;
	}
	
	/**
	 * Converts a vector, idealy the position vector to a BlockPos
	 * @param vec  the vector converted
	 * @return {@link class_2338} 
	 */
	public class_2338 toBlockPos(class_243 vec) {
		return new class_2338(class_3532.method_15357(vec.field_1352), class_3532.method_15357(vec.field_1351), class_3532.method_15357(vec.field_1350));
	}
}
