package luckytntlib.util.explosions;

import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;

/**
 * An IForEachEntityExplosionEffect is used to affect individual blocks gotten by an {@link ImprovedExplosion} 
 * or a function of the {@link ExplosionHelper} in different ways.
 * It is usually used as a parameter of a function.
 */
@FunctionalInterface
public interface IForEachBlockExplosionEffect {

	/**
	 * @param level  the current level
	 * @param pos  the position of the block
	 * @param state  the state of the block
	 * @param distance  the distance of the block to the explosion origin
	 */
	public void doBlockExplosion(class_1937 level, class_2338 pos, class_2680 state, double distance);
	
}
