package luckytntlib.util.explosions;

import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;

/**
 * An IBlockExplosionCondition is used by different explosions to check whether a block is suited for further actions or not.
 * Further actions include blocks getting added to a List or passed to an {@link IForEachBlockExplosionEffect}.
 * It is usually used as a parameter of a function.
 */
@FunctionalInterface
public interface IBlockExplosionCondition {

	/**
	 * Decides which blocks are considered to be passed to an {@link IForEachBlockExplosionEffect} or not.
	 * @param level  the current level
	 * @param pos  the position of the block
	 * @param state  the state of the block
	 * @param distance  the distance of the block to the explosion origin
	 */
	public boolean conditionMet(class_1937 level, class_2338 pos, class_2680 state, double distance);
	
}
