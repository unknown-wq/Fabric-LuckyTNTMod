package luckytntlib.util.explosions;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.jetbrains.annotations.Nullable;

import luckytntlib.config.LuckyTNTLibConfigValues;
import luckytntlib.util.IExplosiveEntity;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1890;
import net.minecraft.class_1893;
import net.minecraft.class_1927;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3532;
import net.minecraft.class_3610;
import net.minecraft.class_4770;
import net.minecraft.class_5361;
import net.minecraft.class_5362;
import net.minecraft.class_6880;
import net.minecraft.class_7924;

/**
 * ImprovedExplosion is an extension of Minecraft's {@link class_1927}.
 * It is needed because the explosion of Minecraft is rather limited in functionality and size,
 * while an ImprovedExplosion has no limit in its size and offers multiple and dynamic ways to interact with and customize the explosion.
 * Similar to Minecraft's explosion it is also raycasted, making it evaluate every block in its path.
 * Due to an improved algorithm, no block drops and no particles it also is more performant, making it best suited for humongous explosions.
 */
public class ImprovedExplosion extends class_1927 {

	public final class_1937 level;
	public final double posX, posY, posZ;
	public final int size;
	public final class_5362 damageCalculator;
	public final class_1282 damageSource;
	List<Integer> affectedBlocks = new ArrayList<>();
	
	private static ImprovedExplosion dummyExplosion;
	
	/**
	 * Creates a new ImprovedExplosion
	 * @implNote size must not be greater than 511 in most cases. See the respective doBlockExplosion method
	 * @param level  the level
	 * @param position  the center position of the explosion
	 * @param size  the rough size of the explosion, which must not be greater than 511 in most cases
	 */
	public ImprovedExplosion(class_1937 level, class_243 position, int size) {
		this(level, null, null, position, size);
	}
	
	/**
	 * Creates a new ImprovedExplosion
	 * @implNote size must not be greater than 511 in most cases. See the respective doBlockExplosion method
	 * @param level  the level
	 * @param source  the DamageSource this explosion uses
	 * @param position  the center position of the explosion
	 * @param size  the rough size of the explosion, which must not be greater than 511 in most cases
	 */
	public ImprovedExplosion(class_1937 level, @Nullable class_1282 source, class_243 position, int size) {
		this(level, null, source, position, size);
	}
	
	/**
	 * Creates a new ImprovedExplosion
	 * @implNote size must not be greater than 511 in most cases. See the respective doBlockExplosion method
	 * @param level  the level
	 * @param entity  the entity not affected by this explosion. Should be the entity causing the explosion and also an IExplosiveEntity
	 * @param position  the center position of the explosion
	 * @param size  the rough size of the explosion, which must not be greater than 511 in most cases
	 */	
	public ImprovedExplosion(class_1937 level, @Nullable class_1297 explodingEntity, class_243 position, int size) {
		this(level, explodingEntity, null, position.field_1352, position.field_1351, position.field_1350, size);
	}
	
	/**
	 * Creates a new ImprovedExplosion
	 * @implNote size must not be greater than 511 in most cases. See the respective doBlockExplosion method
	 * @param level  the level
	 * @param entity  the entity not affected by this explosion. Should be the entity causing the explosion and also an IExplosiveEntity
	 * @param source  the DamageSource this explosion uses
	 * @param position  the center position of the explosion
	 * @param size  the rough size of the explosion, which must not be greater than 511 in most cases
	 */	
	public ImprovedExplosion(class_1937 level, @Nullable class_1297 explodingEntity, @Nullable class_1282 source, class_243 position, int size) {
		this(level, explodingEntity, source, position.field_1352, position.field_1351, position.field_1350, size);
	}
	
	/**
	 * Creates a new ImprovedExplosion
	 * @implNote size must not be greater than 511 in most cases. See the respective doBlockExplosion method
	 * @param level  the level
	 * @param entity  the entity not affected by this explosion. Should be the entity causing the explosion and also an IExplosiveEntity
	 * @param x  the x center position
	 * @param y  the y center position
	 * @param z  the z center position
	 * @param size  the rough size of the explosion, which must not be greater than 511 in most cases
	 */	
	public ImprovedExplosion(class_1937 level, @Nullable class_1297 explodingEntity, double x, double y, double z, int size) {
		this(level, explodingEntity, null, x, y, z, size);
	}
	
	/**
	 * Creates a new ImprovedExplosion
	 * @implNote size must not be greater than 511 in most cases. See the respective doBlockExplosion method
	 * @param level  the level
	 * @param entity  the entity not affected by this explosion. Should be the entity causing the explosion and also an IExplosiveEntity
	 * @param source  the DamageSource this explosion uses
	 * @param x  the x center position
	 * @param y  the y center position
	 * @param z  the z center position
	 * @param size  the rough size of the explosion, which must not be greater than 511 in most cases
	 */	
	public ImprovedExplosion(class_1937 level, @Nullable class_1297 explodingEntity, @Nullable class_1282 source, double x, double y, double z, int size) {
		super(level, explodingEntity, source, null, x, y, z, size, false, class_4179.field_40878, class_2398.field_11236, class_2398.field_11221, class_3417.field_15152);
		this.level = level;
		this.posX = x;
		this.posY = y;
		this.posZ = z;
		this.size = size;
		this.damageSource = source == null ? level.method_48963().method_48807(this) : source;
		damageCalculator = explodingEntity == null ? new class_5362() : new class_5361(explodingEntity);
	}
	
	/**
	 * Creates a new ImprovedExplosion
	 * @implNote size must not be greater than 511 in most cases. See the respective doBlockExplosion method
	 * @param level  the level
	 * @param entity  the entity not affected by this explosion. Should be the entity causing the explosion and also an IExplosiveEntity
	 * @param source  the DamageSource this explosion uses
	 * @param sound  the Sound this explosion will play
	 * @param x  the x center position
	 * @param y  the y center position
	 * @param z  the z center position
	 * @param size  the rough size of the explosion, which must not be greater than 511 in most cases
	 */	
	public ImprovedExplosion(class_1937 level, @Nullable class_1297 explodingEntity, @Nullable class_1282 source, class_3414 sound, double x, double y, double z, int size) {
		super(level, explodingEntity, source, null, x, y, z, size, false, class_4179.field_40878, class_2398.field_11236, class_2398.field_11221, class_6880.method_40223(sound));
		this.level = level;
		this.posX = x;
		this.posY = y;
		this.posZ = z;
		this.size = size;
		this.damageSource = source == null ? level.method_48963().method_48807(this) : source;
		damageCalculator = explodingEntity == null ? new class_5362() : new class_5361(explodingEntity);
	}
	
	/**
	 * Gets all blocks in an area calculated by shooting vectors to the borders of a cube determined by the {@link ImprovedExplosion#size} and destroys them.
	 * If any of the relative coordinates of the affected block exceed 511 they will be clamped to that value.
	 * Encodes block positions into a singular int, increasing performance.
	 * The shape the vectors orient to can either be a sphere or a cube, depending on the players config.
	 * @param xzStrength  a multiplier to the x and z vector addition, which makes the explosion more powerful. It should not be set higher than 1.2, otherwise blocks might be skipped
	 * @param yStrength  a multiplier to the y vector addition, which makes the explosion more powerful. It should not be set to high, otherwise blocks might be skipped
	 * @param resistanceImpact  the relative impact that explosion resistance of blocks has on the penetration force of explosion
	 * @param randomVecLength  the greater this value, the more distributed the length of the explosion vectors will be. Large explosions should have a value less than 1
	 * @param fire  whether or not the explosion should spawn fire afterwards
	 * @param isStrongExplosion  whether or not fluids should be ignored in the explosion resistance calculation. Very useful for large explosions
	 */
	public void doBlockExplosion(float xzStrength, float yStrength, float resistanceImpact, float randomVecLength, boolean fire, boolean isStrongExplosion) {			
		class_2338 posTNT = new class_2338(floor(posX), floor(posY), floor(posZ));
		Set<Integer> blocks = new HashSet<>();
		for (int offX = -size; offX <= size; offX++) {
			for (int offY = -size; offY <= size; offY++) {
				for (int offZ = -size; offZ <= size; offZ++) {
					double distance = Math.sqrt(offX * offX + offY * offY + offZ * offZ);
					if (((int) distance == size && LuckyTNTLibConfigValues.PERFORMANT_EXPLOSION.get()) || (!LuckyTNTLibConfigValues.PERFORMANT_EXPLOSION.get() && (offX == -size || offX == size || offY == -size || offY == size || offZ == -size || offZ == size))) {
						double xStep = offX / distance;
						double yStep = offY / distance;
						double zStep = offZ / distance;
						float vecLength = size * (0.7f + (float) Math.random() * 0.6f * randomVecLength);
						double blockX = posX;
						double blockY = posY;
						double blockZ = posZ;
						for (float vecStep = 0; vecStep < vecLength; vecStep += LuckyTNTLibConfigValues.EXPLOSION_PERFORMANCE_FACTOR.get() * 1.5f - 0.225f) {
							blockX += xStep * LuckyTNTLibConfigValues.EXPLOSION_PERFORMANCE_FACTOR.get() * xzStrength;
							blockY += yStep * LuckyTNTLibConfigValues.EXPLOSION_PERFORMANCE_FACTOR.get() * yStrength;
							blockZ += zStep * LuckyTNTLibConfigValues.EXPLOSION_PERFORMANCE_FACTOR.get() * xzStrength;
							class_2338 pos = new class_2338((int)blockX, (int)blockY, (int)blockZ);
							if (!level.method_24794(pos)) {
								break;
							}
							class_2680 blockState = level.method_8320(pos);
							class_3610 fluidState = level.method_8316(pos);
							if (!(isStrongExplosion && !fluidState.method_15769())) {
								Optional<Float> explosionResistance = damageCalculator.method_29555(this, level, pos, blockState, fluidState);
								if (explosionResistance.isPresent()) {
									vecLength -= (explosionResistance.get() + 0.3f) * 0.3f * resistanceImpact;
								}
								if (vecLength > 0 && damageCalculator.method_29554(this, level, pos, blockState, vecLength) && !blockState.method_26215()) {
									blocks.add(encodeBlockPos(pos.method_10059(posTNT).method_10263(), pos.method_10059(posTNT).method_10264(), pos.method_10059(posTNT).method_10260()));
								}
							} else {
								blocks.add(encodeBlockPos(pos.method_10059(posTNT).method_10263(), pos.method_10059(posTNT).method_10264(), pos.method_10059(posTNT).method_10260()));
							}
						}
					}
				}
			}
		}
		affectedBlocks.addAll(blocks);
		for(int intPos : blocks) {
			class_2338 pos = decodeBlockPos(intPos).method_10081(posTNT);
			level.method_8320(pos).method_26204().method_9586(level, pos, this);
			level.method_8652(pos, class_2246.field_10124.method_9564(), 3);
		}
		if(fire) {
			for(int intPos : blocks) {
				class_2338 pos = decodeBlockPos(intPos).method_10081(posTNT);
				if(Math.random() > 0.75f && level.method_8320(pos).method_26215() && level.method_8320(pos.method_10074()).method_26216(level, pos)) {
					level.method_8501(pos, class_4770.method_24416(level, pos));
				}
			}
		}
	}
	
	/**
	 * Gets all blocks in an area calculated by shooting vectors to the borders of a cube determined by the {@link ImprovedExplosion#size} 
	 * and does to them whatever specified in the {@link IForEachBlockExplosionEffect}. 
	 * If any of the relative coordinates of the affected block exceed 511 they will be clamped to that value.
	 * Encodes block positions into a singular int, increasing performance.
	 * The shape the vectors orient to can either be a sphere or a cube, depending on the players config.
	 * @param xzStrength  a multiplier to the x and z vector addition, which makes the explosion more powerful. It should not be set to high, otherwise blocks might be skipped
	 * @param yStrength  a multiplier to the y vector addition, which makes the explosion more powerful. It should not be set to high, otherwise blocks might be skipped
	 * @param resistanceImpact  the relative impact that explosion resistance of blocks has on the penetration force of explosion
	 * @param randomVecLength  the greater this value, the more distributed the length of the explosion vectors will be. Large explosions should have a value less than 1
	 * @param fire  whether or not the explosion should spawn fire afterwards
	 * @param isStrongExplosion  whether or not fluids should be ignored in the explosion resistance calculation. Very useful for large explosions
	 * @param blockEffect  determines what should happen to the blocks gotten by this explosion
	 */
	public void doBlockExplosion(float xzStrength, float yStrength, float resistanceImpact, float randomVecLength, boolean isStrongExplosion, IForEachBlockExplosionEffect blockEffect) {
		class_2338 posTNT = new class_2338(floor(posX), floor(posY), floor(posZ));
		Set<Integer> blocks = new HashSet<>();
		for(int offX = -size; offX <= size; offX++) {
			for(int offY = -size; offY <= size; offY++) {
				for(int offZ = -size; offZ <= size; offZ++) {
					double distance = Math.sqrt(offX * offX + offY * offY + offZ * offZ);
					if(((int)distance == size && LuckyTNTLibConfigValues.PERFORMANT_EXPLOSION.get()) || (!LuckyTNTLibConfigValues.PERFORMANT_EXPLOSION.get() && (offX == -size || offX == size || offY == -size || offY == size || offZ == -size || offZ == size))) {
						double xStep = offX / distance;
						double yStep = offY / distance;
						double zStep = offZ / distance;
						float vecLength = size * (0.7f + (float)Math.random() * 0.6f * randomVecLength);
						double blockX = posX;
						double blockY = posY;
						double blockZ = posZ;
						for(float vecStep = 0; vecStep < vecLength; vecStep += LuckyTNTLibConfigValues.EXPLOSION_PERFORMANCE_FACTOR.get() * 1.5f - 0.225f) {
							blockX += xStep * LuckyTNTLibConfigValues.EXPLOSION_PERFORMANCE_FACTOR.get() * xzStrength;
							blockY += yStep * LuckyTNTLibConfigValues.EXPLOSION_PERFORMANCE_FACTOR.get() * yStrength;
							blockZ += zStep * LuckyTNTLibConfigValues.EXPLOSION_PERFORMANCE_FACTOR.get() * xzStrength;
							class_2338 pos = new class_2338((int)blockX, (int)blockY, (int)blockZ);
							if(!level.method_24794(pos)) {
								break;
							}
							class_2680 blockState = level.method_8320(pos);
							class_3610 fluidState = level.method_8316(pos);
							if(!(isStrongExplosion && !fluidState.method_15769())) {
								Optional<Float> explosionResistance = damageCalculator.method_29555(this, level, pos, blockState, fluidState);
								if(explosionResistance.isPresent()) {
									vecLength -= (explosionResistance.get() + 0.3f) * 0.3f * resistanceImpact;
								}
								if(vecLength > 0 && damageCalculator.method_29554(this, level, pos, blockState, vecLength) && !blockState.method_26215()) {
									blocks.add(encodeBlockPos(pos.method_10059(posTNT).method_10263(), pos.method_10059(posTNT).method_10264(), pos.method_10059(posTNT).method_10260()));
								}
							}
							else {
								blocks.add(encodeBlockPos(pos.method_10059(posTNT).method_10263(), pos.method_10059(posTNT).method_10264(), pos.method_10059(posTNT).method_10260()));
							}
						}
					}
				}
			}
		}
		affectedBlocks.addAll(blocks);
		for(int intPos : blocks) {
			class_2338 pos = decodeBlockPos(intPos).method_10081(posTNT);
			double distance = Math.sqrt(pos.method_40081(posX, posY, posZ));
			blockEffect.doBlockExplosion(level, pos, level.method_8320(pos), distance);
		}
	}
	
	/**
	 * Gets blocks in an area calculated by shooting vectors to the borders of a cube determined by the {@link ImprovedExplosion#size} if the {@link IBlockExplosionCondition} is met 
	 * and does to them whatever specified in the blockEffect.
	 * If any of the relative coordinates of the affected block exceed 511 they will be clamped to that value.
	 * Encodes block positions into a singular int, increasing performance.
	 * The shape the vectors orient to can either be a sphere or a cube, depending on the players config.
	 * @param xzStrength  a multiplier to the x and z vector addition, which makes the explosion more powerful. It should not be set to high, otherwise blocks might be skipped
	 * @param yStrength  a multiplier to the y vector addition, which makes the explosion more powerful. It should not be set to high, otherwise blocks might be skipped
	 * @param resistanceImpact  the relative impact that explosion resistance of blocks has on the penetration force of explosion
	 * @param randomVecLength  the greater this value, the more distributed the length of the explosion vectors will be. Large explosions should have a value less than 1
	 * @param fire  whether or not the explosion should spawn fire afterwards
	 * @param isStrongExplosion  whether or not fluids should be ignored in the explosion resistance calculation. Very useful for large explosions
	 * @param condition  the condition on which a block is added to the {@link Set} of blocks
	 * @param blockEffect  determines what should happen to the blocks gotten by this explosion
	 */
	public void doBlockExplosion(float xzStrength, float yStrength, float resistanceImpact, float randomVecLength, boolean isStrongExplosion, IBlockExplosionCondition condition, IForEachBlockExplosionEffect blockEffect) {
		class_2338 posTNT = new class_2338(floor(posX), floor(posY), floor(posZ));
		Set<Integer> blocks = new HashSet<>();
		for(int offX = -size; offX <= size; offX++) {
			for(int offY = -size; offY <= size; offY++) {
				for(int offZ = -size; offZ <= size; offZ++) {
					double distance = Math.sqrt(offX * offX + offY * offY + offZ * offZ);
					if(((int)distance == size && LuckyTNTLibConfigValues.PERFORMANT_EXPLOSION.get()) || (!LuckyTNTLibConfigValues.PERFORMANT_EXPLOSION.get() && (offX == -size || offX == size || offY == -size || offY == size || offZ == -size || offZ == size))) {
						double xStep = offX / distance;
						double yStep = offY / distance;
						double zStep = offZ / distance;
						float vecLength = size * (0.7f + (float)Math.random() * 0.6f * randomVecLength);
						double blockX = posX;
						double blockY = posY;
						double blockZ = posZ;
						for(float vecStep = 0; vecStep < vecLength; vecStep += LuckyTNTLibConfigValues.EXPLOSION_PERFORMANCE_FACTOR.get() * 1.5f - 0.225f) {
							blockX += xStep * LuckyTNTLibConfigValues.EXPLOSION_PERFORMANCE_FACTOR.get() * xzStrength;
							blockY += yStep * LuckyTNTLibConfigValues.EXPLOSION_PERFORMANCE_FACTOR.get() * yStrength;
							blockZ += zStep * LuckyTNTLibConfigValues.EXPLOSION_PERFORMANCE_FACTOR.get() * xzStrength;
							class_2338 pos = new class_2338((int)blockX, (int)blockY, (int)blockZ);
							if(!level.method_24794(pos)) {
								break;
							}
							class_2680 blockState = level.method_8320(pos);
							class_3610 fluidState = level.method_8316(pos);
							if(!(isStrongExplosion && !fluidState.method_15769())) {
								Optional<Float> explosionResistance = damageCalculator.method_29555(this, level, pos, blockState, fluidState);
								if(explosionResistance.isPresent()) {
									vecLength -= (explosionResistance.get() + 0.3f) * 0.3f * resistanceImpact;
								}
								if(vecLength > 0 && damageCalculator.method_29554(this, level, pos, blockState, vecLength) && !blockState.method_26215()) {
									if(condition.conditionMet(level, pos, blockState, distance)) {
										blocks.add(encodeBlockPos(pos.method_10059(posTNT).method_10263(), pos.method_10059(posTNT).method_10264(), pos.method_10059(posTNT).method_10260()));
									}
								}
							}
							else {
								if(condition.conditionMet(level, pos, blockState, distance)) {
									blocks.add(encodeBlockPos(pos.method_10059(posTNT).method_10263(), pos.method_10059(posTNT).method_10264(), pos.method_10059(posTNT).method_10260()));
								}
							}
						}
					}
				}
			}
		}
		affectedBlocks.addAll(blocks);
		for(int intPos : blocks) {
			class_2338 pos = decodeBlockPos(intPos).method_10081(posTNT);
			double distance = Math.sqrt(pos.method_40081(posX, posY, posZ));
			blockEffect.doBlockExplosion(level, pos, level.method_8320(pos), distance);
		}
	}
	
	/**
	 * Executes {@link ImprovedExplosion#doBlockExplosion(float, float, float, float, boolean, boolean, blockEffect)} with default values.
	 * @param blockEffect  determines what should happen to the blocks gotten by this explosion
	 * 
	 */
	public void doBlockExplosion(IForEachBlockExplosionEffect blockEffect) {
		doBlockExplosion(1f, 1f, 1f, 1f, false, blockEffect);
	}
	
	/**
	 * Executes {@link ImprovedExplosion#doBlockExplosion(float, float, float, float, boolean, boolean, condition, blockEffect)} with default values.
	 * @param blockEffect  determines what should happen to the blocks gotten by this explosion
	 */
	public void doBlockExplosion(IBlockExplosionCondition condition, IForEachBlockExplosionEffect blockEffect) {
		doBlockExplosion(1f, 1f, 1f, 1f, false, condition, blockEffect);
	}
	
	/**
	 * Executes {@link ImprovedExplosion#doBlockExplosion(float, float, float, float, boolean, boolean)} with default values.
	 */
	public void doBlockExplosion() {
		doBlockExplosion(1f, 1f, 1f, 1f, false, false);
	}
	
	/**
	 * Gets all blocks in an area calculated by shooting vectors to the borders of a cube determined by the {@link ImprovedExplosion#size} and destroys them.
	 * Values of the relative coordinates can exceed 511, allowing for bigger explosions at the cost of more ram usage and slower explosion time.
	 * @param xzStrength  a multiplier to the x and z vector addition, which makes the explosion more powerful. It should not be set to high, otherwise blocks might be skipped
	 * @param yStrength  a multiplier to the y vector addition, which makes the explosion more powerful. It should not be set to high, otherwise blocks might be skipped
	 * @param resistanceImpact  the relative impact that explosion resistance of blocks has on the penetration force of explosion
	 * @param randomVecLength  the greater this value, the more distributed the length of the explosion vectors will be. Large explosions should have a value less than 1
	 * @param fire  whether or not the explosion should spawn fire afterwards
	 * @param isStrongExplosion  whether or not fluids should be ignored in the explosion resistance calculation. Very useful for large explosions
	 * @param saveBlockPos  whether or not affected blocks should be saved to be used externally
	 */
	public void doOldBlockExplosion(float xzStrength, float yStrength, float resistanceImpact, float randomVecLength, boolean fire, boolean isStrongExplosion, boolean saveBlockPos) {
		Set<class_2338> blocks = new HashSet<>();
		for(int offX = -size; offX <= size; offX++) {
			for(int offY = -size; offY <= size; offY++) {
				for(int offZ = -size; offZ <= size; offZ++) {
					double distance = Math.sqrt(offX * offX + offY * offY + offZ * offZ);
					if(((int)distance == size && LuckyTNTLibConfigValues.PERFORMANT_EXPLOSION.get()) || (!LuckyTNTLibConfigValues.PERFORMANT_EXPLOSION.get() && (offX == -size || offX == size || offY == -size || offY == size || offZ == -size || offZ == size))) {
						double xStep = offX / distance;
						double yStep = offY / distance;
						double zStep = offZ / distance;
						float vecLength = size * (0.7f + (float)Math.random() * 0.6f * randomVecLength);
						double blockX = posX;
						double blockY = posY;
						double blockZ = posZ;
						for(float vecStep = 0; vecStep < vecLength; vecStep += LuckyTNTLibConfigValues.EXPLOSION_PERFORMANCE_FACTOR.get() * 1.5f - 0.225f) {
							blockX += xStep * LuckyTNTLibConfigValues.EXPLOSION_PERFORMANCE_FACTOR.get() * xzStrength;
							blockY += yStep * LuckyTNTLibConfigValues.EXPLOSION_PERFORMANCE_FACTOR.get() * yStrength;
							blockZ += zStep * LuckyTNTLibConfigValues.EXPLOSION_PERFORMANCE_FACTOR.get() * xzStrength;
							class_2338 pos = new class_2338((int)blockX, (int)blockY, (int)blockZ);
							if(!level.method_24794(pos)) {
								break;
							}
							class_2680 blockState = level.method_8320(pos);
							class_3610 fluidState = level.method_8316(pos);
							if(!(isStrongExplosion && !fluidState.method_15769())) {
								Optional<Float> explosionResistance = damageCalculator.method_29555(this, level, pos, blockState, fluidState);
								if(explosionResistance.isPresent()) {
									vecLength -= (explosionResistance.get() + 0.3f) * 0.3f * resistanceImpact;
								}
								if(vecLength > 0 && damageCalculator.method_29554(this, level, pos, blockState, vecLength) && !blockState.method_26215()) {
									blocks.add(pos);
								}
							}
							else {
								blocks.add(pos);
							}
						}
					}
				}
			}
		}
		if(saveBlockPos) {
			class_2338 posTNT = new class_2338(floor(posX), floor(posY), floor(posZ));
			for(class_2338 pos : blocks) {
				affectedBlocks.add(encodeBlockPos(pos.method_10059(posTNT).method_10263(), pos.method_10059(posTNT).method_10264(), pos.method_10059(posTNT).method_10260()));
			}
		}
		for(class_2338 pos : blocks) {
			level.method_8320(pos).method_26204().method_9586(level, pos, this);
		}
		if(fire) {
			for(class_2338 pos : blocks) {
				if(Math.random() > 0.75f && level.method_8320(pos).method_26215() && level.method_8320(pos.method_10074()).method_26216(level, pos)) {
					level.method_8501(pos, class_4770.method_24416(level, pos));
				}
			}
		}
	}
	
	/**
	 * Encodes 3 coordinates into a singular int value. 
	 * Coordinates greater than the absolute value of 511 will be clamped to 511.
	 * @implNote coordinates given must be realtive coordinates to the center of the explosion
	 * @param x  the x position of the block
	 * @param y  the y position of the block
	 * @param z  the z position of the block
	 * @return encoded int containing information about x, y and z positions, all of which can have values between -511 and 511
	 */
	protected int encodeBlockPos(int x, int y, int z) {
		int x0 = Integer.signum(x);
		x = Math.abs(x) > 511 ? 511 : Math.abs(x);
		x0 = x0 == -1 ? 0b1000000000 : 0;		
		x += x0;
		
		x = x << 20;
		
		int y0 = Integer.signum(y);
		y = Math.abs(y) > 511 ? 511 : Math.abs(y);
		y0 = y0 == -1 ? 0b1000000000 : 0;
		y += y0;

		y = y << 10;
		
		int z0 = Integer.signum(z);
		z = Math.abs(z) > 511 ? 511 : Math.abs(z);
		z0 = z0 == -1 ? 0b1000000000 : 0;
		z += z0;
		
		return (x + y + z);
	}
	
	/**
	 * Decodes an encoded value generated by {@link ImprovedExplosion#encodeBlockPos(int, int, int)} into a {@link class_2338}.
	 * @param encodedVal  the position encoded by {@link ImprovedExplosion#encodeBlockPos(int, int, int)}
	 * @return BlockPos with the relative x, y and z coordinates decoded again with an absolute max value of 511
	 */
	protected class_2338 decodeBlockPos(int encodedVal) {
		int zRaw = (encodedVal & 0b00000000000000000000000111111111);
		int zNeg = (encodedVal & 0b00000000000000000000001000000000) >> 9;
		int yRaw = (encodedVal & 0b00000000000001111111110000000000) >> 10;
		int yNeg = (encodedVal & 0b00000000000010000000000000000000) >> 19;
		int xRaw = (encodedVal & 0b00011111111100000000000000000000) >> 20;
		int xNeg = (encodedVal & 0b00100000000000000000000000000000) >> 29;
		int xVal = xNeg == 1 ? -xRaw : xRaw;
		int yVal = yNeg == 1 ? -yRaw : yRaw;
		int zVal = zNeg == 1 ? -zRaw : zRaw;
		return new class_2338(xVal, yVal, zVal);
	}
	
	/**
	 * Damages and throws back all entities affected by this explosion determined by the {@link ImprovedExplosion#size}.
	 * @param knockbackStrength  multiplier to the strength of the knockback
	 * @param damageEntities  whether or not entities should be damaged by this explosion
	 */
	public void doEntityExplosion(float knockbackStrength, boolean damageEntities) {
		List<class_1297> entities = level.method_8335(method_46406(), new class_238(posX - size * 2, posY - size * 2, posZ - size * 2, posX + size * 2, posY + size * 2, posZ + size * 2));
		for(class_1297 entity : entities) {
			if(!entity.method_5659(this)) {
				double distance = Math.sqrt(entity.method_5707(method_55109())) / (size * 2);
				if(distance <= 1f) {
					double offX = (entity.method_23317() - posX);
					double offY = (entity.method_23320() - posY);
					double offZ = (entity.method_23321() - posZ);
					double distance2 = Math.sqrt(offX * offX + offY * offY + offZ * offZ);
					offX /= distance2;
					offY /= distance2;
					offZ /= distance2;
					double seenPercent = method_17752(method_55109(), entity);
					float damage = (1f - (float)distance) * (float)seenPercent;
					if(damageEntities) {
						entity.method_5643(damageSource, (damage * damage + damage) / 2f * 7 * size + 1f);
					}
					double knockback = damage;
					if(entity instanceof class_1309 lEnt) {
						knockback = transformExplosionKnockback(lEnt, damage);
					}
					entity.method_18799(entity.method_18798().method_1031(offX * knockback * knockbackStrength, offY * knockback * knockbackStrength, offZ * knockback * knockbackStrength));
					if(entity instanceof class_1657) {
						class_1657 player = (class_1657)entity;
						player.field_6037 = true;
						if(!player.method_7325() && (!player.method_7337() || !player.method_31549().field_7479)) {
							method_8351().put(player, new class_243(offX * damage, offY * damage, offZ * damage));
						}
					}
				}
			}
		}
	}
	
	/**
	 * Does whatever specified in the {@link IForEachBlockExplosionEffect} to all entities gotten by this explosion,
	 * which is determined by the {@link ImprovedExplosion#size}.
	 * @param entityEffect  determines what should be done to the entities gotten by this explosion
	 */
	public void doEntityExplosion(IForEachEntityExplosionEffect entityEffect) {
		List<class_1297> entities = level.method_8335(method_46406(), new class_238(posX - size * 2, posY - size * 2, posZ - size * 2, posX + size * 2, posY + size * 2, posZ + size * 2));
		for(class_1297 entity : entities) {
			if(!entity.method_5659(this)) {
				double distance = Math.sqrt(entity.method_5707(method_55109())) / (size * 2);
				if(distance < 1f && distance != 0) {
					entityEffect.doEntityExplosion(entity, distance);
				}
			}
		}
	}
	
	public static double transformExplosionKnockback(class_1309 entity, double velocity) {
		int i = class_1890.method_8203(entity.method_37908().method_30349().method_30530(class_7924.field_41265).method_40290(class_1893.field_9121), entity);
		if (i > 0) {
			velocity *= class_3532.method_15350(1.0 - (double) i * 0.15, 0.0, 1.0);
		}

		return velocity;
	}
	
	@Nullable
	@Override
	public class_1309 method_8347() {
		if(method_46406() instanceof IExplosiveEntity ent) {
			return ent.owner();
		}
		return super.method_8347();
	}
	
	/**
	 * @implNote This method has been copied from the Forge version to ensure the same behaviour
	 * @param d The double that's supposed to be floored
	 * @return int that has been floored
	 */
	private static int floor(double d) {
		int i = (int) d;
		return d < (double) i ? i - 1 : i;
	}
	
	/** 
	 * @implNote Must	 not be used to create an actual explosion!
	 * @return ImprovedExplosion with no strength and position at (0, 0, 0)
	 */
	public static ImprovedExplosion dummyExplosion(class_1937 level) {
		return dummyExplosion == null ? dummyExplosion = new ImprovedExplosion(level, new class_243(0, 0, 0), 0) : dummyExplosion;
	}

	@Override
	@Deprecated
	public void method_8348() {
	}
	
	@Override
	@Deprecated
	public void method_8350(boolean spawnParticles) {		
	}
	
	@Override
	@Nullable
	public List<class_2338> method_8346() {
		List<class_2338> blocks = new ArrayList<>();
		for(int intPos : affectedBlocks) {
			blocks.add(decodeBlockPos(intPos).method_10069(floor(posX), floor(posY), floor(posZ)));
		}
		return blocks;
	}
}
