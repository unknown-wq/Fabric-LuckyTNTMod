package luckytntlib.util.explosions;

import java.util.HashMap;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_2968;
import net.minecraft.class_3481;
import net.minecraft.class_3532;

/**
 * The ExplosionHelper offers many basic functions that help you get or edit large ares of blocks in the current {@link class_1937}.
 * This includes simple spherical functions, but also more complex methods like getting the top most block in a sphere.
 */
public class ExplosionHelper {

	/**
	 * Gets all blocks in a specified sphere and returns them in a HashMap consisting of {@link class_2338} and {@link class_2680}
	 * @param level  the current level
	 * @param position  the center position of the sphere
	 * @param radius  the radius of the sphere
	 * @return a {@link HashMap} of {@link class_2338} and {@link class_2680}
	 */
	public static HashMap<class_2338, class_2680> getBlocksInSphere(class_1937 level, class_243 position, int radius) {
		HashMap<class_2338, class_2680> blocks = new HashMap<>();
		for(int offX = -radius; offX <= radius; offX++) {
			for(int offY = radius; offY >= -radius; offY--) {
				for(int offZ = -radius; offZ <= radius; offZ++) {
					double distance = Math.sqrt(offX * offX + offY * offY + offZ * offZ);
					if(distance <= radius) {
						class_2338 pos = new class_2338(class_3532.method_15357(position.field_1352), class_3532.method_15357(position.field_1351), class_3532.method_15357(position.field_1350)).method_10069(offX, offY, offZ);
						class_2680 state = level.method_8320(pos);
						blocks.put(pos, state);
					}
				}
			}
		}
		return blocks;
	}
	
	/**
	 * Gets all blocks in a specified cuboid and returns them in a HashMap consisting of {@link class_2338} and {@link class_2680}
	 * @param level  the current level
	 * @param position  the center position of the cuboid
	 * @param radii  the radii for the x, y and z directions
	 * @return a {@link HashMap} of {@link class_2338} and {@link class_2680}
	 */
	public static HashMap<class_2338, class_2680> getBlocksInCuboid(class_1937 level, class_243 position, class_243 radii) {
		HashMap<class_2338, class_2680> blocks = new HashMap<>();
		for(int offX = (int)-radii.field_1352; offX <= (int)radii.field_1352; offX++) {
			for(int offY = (int)radii.field_1351; offY >= (int)-radii.field_1351; offY--) {
				for(int offZ = (int)-radii.field_1350; offZ <= (int)radii.field_1350; offZ++) {
					class_2338 pos = new class_2338(class_3532.method_15357(position.field_1352), class_3532.method_15357(position.field_1351), class_3532.method_15357(position.field_1350)).method_10069(offX, offY, offZ);
					class_2680 state = level.method_8320(pos);
					blocks.put(pos, state);
				}
			}
		}
		return blocks;
	}
	
	/**
	 * Gets all blocks in a specified cylinder and returns them in a HashMap consisting of {@link class_2338} and {@link class_2680}
	 * @param level  the current level
	 * @param position  the center position of the cylinder
	 * @param radius  the radius of the cylinder
	 * @return a {@link HashMap} of {@link class_2338} and {@link class_2680}
	 */
	public static HashMap<class_2338, class_2680> getBlocksInCylinder(class_1937 level, class_243 position, int radius, int radiusY) {
		HashMap<class_2338, class_2680> blocks = new HashMap<>();
		for(int offX = -radius; offX <= radius; offX++) {
			for(int offY = radiusY; offY >= -radiusY; offY--) {
				for(int offZ = -radius; offZ <= radius; offZ++) {
					double distance = Math.sqrt(offX * offX + offZ * offZ);
					if(distance <= radius) {
						class_2338 pos = new class_2338(class_3532.method_15357(position.field_1352), class_3532.method_15357(position.field_1351), class_3532.method_15357(position.field_1350)).method_10069(offX, offY, offZ);
						class_2680 state = level.method_8320(pos);
						blocks.put(pos, state);
					}
				}
			}
		}
		return blocks;
	}
	
	/**
	 * Gets blocks contained in a specified sphere around a center position and edits them according to the given blockEffect.
	 * @param level  the current level
	 * @param position  the center position of the spherical explosion
	 * @param radius  the radius of the sphere
	 * @param blockEffect  determines what should happen to the blocks gotten by this function
	 */
	public static void doSphericalExplosion(class_1937 level, class_243 position, int radius, IForEachBlockExplosionEffect blockEffect) {
		for(int offX = -radius; offX <= radius; offX++) {
			for(int offY = radius; offY >= -radius; offY--) {
				for(int offZ = -radius; offZ <= radius; offZ++) {
					double distance = Math.sqrt(offX * offX + offY * offY + offZ * offZ);
					if(distance <= radius) {
						class_2338 pos = new class_2338(class_3532.method_15357(position.field_1352), class_3532.method_15357(position.field_1351), class_3532.method_15357(position.field_1350)).method_10069(offX, offY, offZ);
						class_2680 state = level.method_8320(pos);
						blockEffect.doBlockExplosion(level, pos, state, distance);
					}
				}
			}
		}
	}

	/**
	 * Gets blocks contained in a specified sphere around a center position and edits them according to the given blockEffect.
	 * The sphere can be scaled in all the 3 directions individually.
	 * @param level  the current level
	 * @param position  the center position of the spherical explosion
	 * @param radius  the radius of the sphere
	 * @param scaling  the scaling of the sphere
	 * @param blockEffect  determines what should happen to the blocks gotten by this function
	 */
	public static void doModifiedSphericalExplosion(class_1937 level, class_243 position, int radius, class_243 scaling, IForEachBlockExplosionEffect blockEffect) {
		for(double offX = -radius * scaling.field_1352; offX <= radius * scaling.field_1352; offX++) {
			for(double offY = radius * scaling.field_1351; offY >= -radius * scaling.field_1351; offY--) {
				for(double offZ = -radius * scaling.field_1350; offZ <= radius * scaling.field_1350; offZ++) {
					double distance = Math.sqrt(offX * offX / scaling.field_1352 + offY * offY / scaling.field_1351 + offZ * offZ / scaling.field_1350);
					if(distance <= radius) {
						class_2338 pos = new class_2338(class_3532.method_15357(position.field_1352), class_3532.method_15357(position.field_1351), class_3532.method_15357(position.field_1350)).method_10069((int)offX, (int)offY, (int)offZ);
						class_2680 state = level.method_8320(pos);
						blockEffect.doBlockExplosion(level, pos, state, distance);
					}
				}
			}
		}
	}

	/**
	 * Gets blocks contained in a specified cube around a center position and edits them according to the given blockEffect.
	 * @param level  the current level
	 * @param position  the center position of the cubical explosion
	 * @param radius  the radius of the cube
	 * @param blockEffect  determines what should happen to the blocks gotten by this function
	 */
	public static void doCubicalExplosion(class_1937 level, class_243 position, int radius, IForEachBlockExplosionEffect blockEffect) {
		for(int offX = -radius; offX <= radius; offX++) {
			for(int offY = -radius; offY <= radius; offY++) {
				for(int offZ = -radius; offZ <= radius; offZ++) {
					double distance = Math.sqrt(offX * offX + offY * offY + offZ * offZ);
					class_2338 pos = new class_2338(class_3532.method_15357(position.field_1352), class_3532.method_15357(position.field_1351), class_3532.method_15357(position.field_1350)).method_10069(offX, offY, offZ);
					class_2680 state = level.method_8320(pos);
					blockEffect.doBlockExplosion(level, pos, state, distance);
				}
			}
		}
	}
	
	/**
	 * Gets blocks contained in a specified cuboid around a center position and edits them according to the given blockEffect.
	 * @param level  the current level
	 * @param position  the center position of the cubical explosion
	 * @param radii  the radii for the x, y and z directions
	 * @param blockEffect  determines what should happen to the blocks gotten by this function
	 */
	public static void doCuboidExplosion(class_1937 level, class_243 position, class_243 radii, IForEachBlockExplosionEffect blockEffect) {
		for(int offX = (int)-radii.field_1352; offX <= (int)radii.field_1352; offX++) {
			for(int offY = (int)-radii.field_1351; offY <= (int)radii.field_1351; offY++) {
				for(int offZ = (int)-radii.field_1350; offZ <= (int)radii.field_1350; offZ++) {
					double distance = Math.sqrt(offX * offX + offY * offY + offZ * offZ);
					class_2338 pos = new class_2338(class_3532.method_15357(position.field_1352), class_3532.method_15357(position.field_1351), class_3532.method_15357(position.field_1350)).method_10069(offX, offY, offZ);
					class_2680 state = level.method_8320(pos);
					blockEffect.doBlockExplosion(level, pos, state, distance);
				}
			}
		}
	}
	
	/**
	 * Gets blocks contained in a specified cylinder around a center position and edits them according to the given blockEffect.
	 * @param level  the current level
	 * @param position  the center position of the cubical explosion
	 * @param radius  the radius of the x and z dimensions of the cylinder
	 * @param radiusY  the radius of the y dimension of the cylinder
	 * @param blockEffect  determines what should happen to the blocks gotten by this function
	 */
	public static void doCylindricalExplosion(class_1937 level, class_243 position, int radius, int radiusY, IForEachBlockExplosionEffect blockEffect) {
		for(int offX = -radius; offX <= radius; offX++) {
			for(int offY = -radiusY; offY <= radiusY; offY++) {
				for(int offZ = -radius; offZ <= radius; offZ++) {
					double distance = Math.sqrt(offX * offX + offZ * offZ);
					if(distance <= radius) {
						class_2338 pos = new class_2338(class_3532.method_15357(position.field_1352), class_3532.method_15357(position.field_1351), class_3532.method_15357(position.field_1350)).method_10069(offX, offY, offZ);
						class_2680 state = level.method_8320(pos);
						blockEffect.doBlockExplosion(level, pos, state, distance);
					}
				}
			}
		}
	}
	
	/**
	 * Gets only the top most blocks in a sphere and edits them according to the given blockEffect.
	 * The function goes from top to bottom and the first block that is air or not solid and followed by a solid block below is considered the top most block.
	 * @param level  the current level
	 * @param position  the center position of the top block explosion
	 * @param radius  the radius of the sphere
	 * @param blockEffect  determines what should happen to the blocks gotten by this function
	 */
	public static void doTopBlockExplosion(class_1937 level, class_243 position, int radius, IForEachBlockExplosionEffect blockEffect) {
		for(int offX = -radius; offX <= radius; offX++) {
			for(int offZ = -radius; offZ <= radius; offZ++) {
				topToBottom: for(int offY = radius; offY >= -radius; offY--) {
					double distance = Math.sqrt(offX * offX + offY * offY + offZ * offZ);
					if(distance <= radius) {
						class_2338 pos = new class_2338(class_3532.method_15357(position.field_1352), class_3532.method_15357(position.field_1351), class_3532.method_15357(position.field_1350)).method_10069(offX, offY, offZ);
						class_2680 state = level.method_8320(pos);
						if((level.method_8320(pos.method_10074()).method_26234(level, pos.method_10074()) || level.method_8320(pos.method_10074()).method_26206(level, pos.method_10074(), class_2350.field_11036)) && (state.method_26215() || state.method_26166(new class_2968(level, pos, class_2350.field_11033, class_1799.field_8037, class_2350.field_11036))  || (!state.method_26234(level, pos) && state.method_26204().method_9520() == 0) || state.method_26164(class_3481.field_20339))) {
							blockEffect.doBlockExplosion(level, pos, state, distance);
							break topToBottom;
						}
					}
				}
			}
		}
	}
	
	/**
	 * Gets only the top most blocks in a sphere and edits them according to the given blockEffect.
	 * The function goes from top to bottom and the block above the first block that is not air is considered the top most block.
	 * If the condition is not met it will continue to search for another top block further down
	 * @param level  the current level
	 * @param position  the center position of the top block explosion
	 * @param radius  the radius of the sphere
	 * @param condition  the condition for the top block to be considered, otherwise a new block further down will be searched for
	 * @param blockEffect  determines what should happen to the blocks gotten by this function
	 */
	public static void doTopBlockExplosion(class_1937 level, class_243 position, int radius, IBlockExplosionCondition condition, IForEachBlockExplosionEffect blockEffect) {
		for(int offX = -radius; offX <= radius; offX++) {
			for(int offZ = -radius; offZ <= radius; offZ++) {
				topToBottom: for(int offY = radius; offY >= -radius; offY--) {
					double distance = Math.sqrt(offX * offX + offY * offY + offZ * offZ);
					if(distance <= radius) {
						class_2338 pos = new class_2338(class_3532.method_15357(position.field_1352), class_3532.method_15357(position.field_1351), class_3532.method_15357(position.field_1350)).method_10069(offX, offY, offZ);
						class_2680 state = level.method_8320(pos);
						if(!level.method_8320(pos.method_10074()).method_26215()) {
							if(condition.conditionMet(level, pos.method_10074(), level.method_8320(pos.method_10074()), Math.sqrt(offX * offX + (offY-1) * (offY-1) + offZ * offZ))) {
								blockEffect.doBlockExplosion(level, pos, state, distance);
								break topToBottom;
							}
						}
					}
				}
			}
		}
	}
	
	/**
	 * Gets all the top blocks in a sphere and edits them according to the given blockEffect.
	 * A top block is any air or non-solid block followed by a solid block below.
	 * @param level  the current level
	 * @param position  the center position of the top block explosion
	 * @param radius  the radius of the sphere
	 * @param blockEffect  determines what should happen to the blocks gotten by this function
	 */
	public static void doTopBlockExplosionForAll(class_1937 level, class_243 position, int radius, IForEachBlockExplosionEffect blockEffect) {
		for(int offX = -radius; offX <= radius; offX++) {
			for(int offZ = -radius; offZ <= radius; offZ++) {
				for(int offY = radius; offY >= -radius; offY--) {
					double distance = Math.sqrt(offX * offX + offY * offY + offZ * offZ);
					if(distance <= radius) {
						class_2338 pos = new class_2338(class_3532.method_15357(position.field_1352), class_3532.method_15357(position.field_1351), class_3532.method_15357(position.field_1350)).method_10069(offX, offY, offZ);
						class_2680 state = level.method_8320(pos);
						if((level.method_8320(pos.method_10074()).method_26234(level, pos.method_10074()) || level.method_8320(pos.method_10074()).method_26206(level, pos.method_10074(), class_2350.field_11036)) && (state.method_26215() || state.method_26166(new class_2968(level, pos, class_2350.field_11033, class_1799.field_8037, class_2350.field_11036)) || (!state.method_26234(level, pos) && state.method_26204().method_9520() == 0) || state.method_26164(class_3481.field_20339))) {
							blockEffect.doBlockExplosion(level, pos, state, distance);
						}
					}
				}
			}
		}
	}
}
