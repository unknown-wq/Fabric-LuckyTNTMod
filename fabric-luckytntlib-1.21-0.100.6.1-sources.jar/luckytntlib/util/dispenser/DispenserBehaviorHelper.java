package luckytntlib.util.dispenser;

import java.util.function.Supplier;

import luckytntlib.block.LTNTBlock;
import luckytntlib.entity.LTNTMinecart;
import luckytntlib.item.LDynamiteItem;
import luckytntlib.item.LTNTMinecartItem;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2241;
import net.minecraft.class_2315;
import net.minecraft.class_2338;
import net.minecraft.class_2342;
import net.minecraft.class_2347;
import net.minecraft.class_2350;
import net.minecraft.class_2357;
import net.minecraft.class_2374;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_2768;
import net.minecraft.class_3481;
import net.minecraft.class_3532;
import net.minecraft.class_9334;

/**
 * Used to register default {@link class_2357}s for {@link LTNTBlock}s, {@link LDynamiteItem}s and {@link LTNTMinecartItem}s
 */
public class DispenserBehaviorHelper {
	
	public static void registerTNTBlockDispenserBehavior(Supplier<LTNTBlock> tnt) {
		LTNTBlock block = tnt.get();
		
		class_2357 behaviour = new class_2357() {
			
			@Override
			public class_1799 dispense(class_2342 source, class_1799 stack) {
				class_1937 level = source.comp_1967();
				class_2374 p = class_2315.method_58682(source);
				class_2338 pos = new class_2338(class_3532.method_15357(p.method_10216()), class_3532.method_15357(p.method_10214()), class_3532.method_15357(p.method_10215()));
				block.explode(level, false, pos.method_10263(), pos.method_10264(), pos.method_10260(), null);
				stack.method_7934(1);
				return stack;
			}
		};
		class_2315.method_10009(block, behaviour);
	}

	public static void registerDynamiteDispenserBehavior(Supplier<LDynamiteItem> dynamite) {
    		LDynamiteItem item = dynamite.get();
    		
    		class_2357 behaviour = new class_2357() {
				
				@Override
				public class_1799 dispense(class_2342 source, class_1799 stack) {
					class_1937 level = source.comp_1967();
					class_243 dispenserPos = new class_243(source.comp_1968().method_10263() + 0.5f, source.comp_1968().method_10264() + 0.5f, source.comp_1968().method_10260() + 0.5f);
					class_2374 pos = class_2315.method_58682(source);
					item.shoot(level, pos.method_10216(), pos.method_10214(), pos.method_10215(), new class_243(pos.method_10216(), pos.method_10214(), pos.method_10215()).method_1031(-dispenserPos.method_10216(), -dispenserPos.method_10214(), -dispenserPos.method_10215()), 2, null);
					stack.method_7934(1);
					return stack;
				}
			};
			class_2315.method_10009(item, behaviour);
	}
	
	public static void registerMinecartDispenserBehavior(Supplier<LTNTMinecartItem> minecart) {
		LTNTMinecartItem item = minecart.get();
		
		class_2357 behaviour = new class_2357() {
			
			@Override
			public class_1799 dispense(class_2342 source, class_1799 stack) {
				class_2350 direction = source.comp_1969().method_11654(class_2315.field_10918);
				class_1937 level = source.comp_1967();
				double x = source.method_53906().method_10216() + (double) direction.method_10148() * 1.125D;
				double y = Math.floor(source.method_53906().method_10214()) + (double) direction.method_10164();
				double z = source.method_53906().method_10215() + (double) direction.method_10165() * 1.125D;
				class_2338 pos = source.comp_1968().method_10093(direction);
				class_2680 state = level.method_8320(pos);
				class_2768 rail = state.method_26204() instanceof class_2241 ? state.method_11654(((class_2241)state.method_26204()).method_9474()) : class_2768.field_12665;
				double railHeight;
				if (state.method_26164(class_3481.field_15463)) {
					if (rail.method_11897()) {
						railHeight = 0.6D;
					} else {
						railHeight = 0.1D;
					}
				} else {
					if (!state.method_26215() || !level.method_8320(pos.method_10074()).method_26164(class_3481.field_15463)) {
						return new class_2347().dispense(source, stack);
					}

					class_2680 stateDown = level.method_8320(pos.method_10074());
					class_2768 railDown = stateDown.method_26204() instanceof class_2241 ? stateDown.method_11654(((class_2241)stateDown.method_26204()).method_9474()) : class_2768.field_12665;
					if (direction != class_2350.field_11033 && railDown.method_11897()) {
						railHeight = -0.4D;
					} else {
						railHeight = -0.9D;
					}
				}

				LTNTMinecart cart = item.createMinecart(level, x, y + railHeight, z, null);
				if (stack.method_57826(class_9334.field_49631) && stack.method_57824(class_9334.field_49631) != null && !stack.method_57824(class_9334.field_49631).getString().equals("")) {
					cart.method_5665(stack.method_7964());
				}
				stack.method_7934(1);
				return stack;
			}
		};
		class_2315.method_10009(item, behaviour);
	}
}
