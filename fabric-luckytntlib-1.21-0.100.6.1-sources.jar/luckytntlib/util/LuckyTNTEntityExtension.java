package luckytntlib.util;

import luckytntlib.mixin.EntityMixin;
import net.minecraft.class_2487;

/**
 * LuckyTNTEntityExtension is used in {@link EntityMixin} to add the possibility for any mod to store additional data that is being
 * synchronized and saved
 */
public interface LuckyTNTEntityExtension {
	
	/**
	 * Gets the additionally stored {@link class_2487}
	 * @return a {@link class_2487}
	 */
	class_2487 getAdditionalPersistentData();
	
	/**
	 * Sets the {@link class_2487} that is stored additionally to a new {@link class_2487}
	 * @param nbt  the {@link class_2487} that will be the new stored data
	 */
	void setAdditionalPersistentData(class_2487 nbt);
}
