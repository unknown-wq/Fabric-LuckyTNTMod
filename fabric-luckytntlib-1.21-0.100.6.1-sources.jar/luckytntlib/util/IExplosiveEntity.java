package luckytntlib.util;

import luckytntlib.util.tnteffects.PrimedTNTEffect;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1541;
import net.minecraft.class_1665;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_2487;

/**
 * IExplosiveEntity is implemented by all entities introduced by Lucky TNT Lib.
 * <p>
 * IExplosiveEntity is required because most of Minecraft's entities qualify as explosive entities but are not interchangeable.
 * Examples are {@link class_1309}, {@link class_1541} and {@link class_1665}.
 * <p>
 * It is advised to use methods given by this Interface rather than Minecraft's methods to make porting easier and to increase universalness.
 * @implNote Only entities implementing this Interface are capeable of using anything extending upon {@link PrimedTNTEffect}
 */
public interface IExplosiveEntity {

	/**
	 * Gets the current fuse of this IExplosiveEntity
	 * @return fuse
	 */
	public int getTNTFuse();
	
	/**
	 * Sets the fuse of this IExplosiveEntity.
	 * 
	 * The fuse should not be set manually in most cases and is usually handled within {@link PrimedTNTEffect#baseTick(IExplosiveEntity)}
	 * @param fuse  the new fuse
	 */
	public void setTNTFuse(int fuse);

	/**
	 * Gets the {@link class_1937} of this IExplosiveEntity
	 * @return
	 */
	public class_1937 getLevel();

	/**
	 * Gets the current position of this IExplosiveEntity
	 * @return pos
	 */
	public class_243 getPos();

	/**
	 * Gets the current x position of this IExplosiveEntity
	 * @return x
	 */
	public double x();

	/**
	 * Gets the current y position of this IExplosiveEntity
	 * @return y
	 */
	public double y();

	/**
	 * Gets the current z position of this IExplosiveEntity
	 * @return z
	 */
	public double z();
	
	/**
	 * Calls the method {@link class_1297#method_31472()}.
	 */
	public void destroy();

	/**
	 * Gets the {@link PrimedTNTEffect} of this IExplosiveEntity
	 * 
	 * @return the PrimedTNTEffect
	 */
	public PrimedTNTEffect getEffect();
	
	/**
	 * Gets the Owner of this IExplosiveEntity.
	 * 
	 * The Owner, usually a Player, of this IExplosiveEntity, which is mostly used for damage sources must not be set manually. It is automatically assigned in all classes implementing this Interface.
	 * @return the Owner
	 */
	public class_1309 owner();
	
	/**
	 * Gets the synchronized {@link class_2487} that contains any custom data that is being saved
	 * 
	 * @return the synchronized data
	 */
	public class_2487 getPersistentData();
	
	/**
	 * Sets the synchronized {@link class_2487} that contains any custom data that is being saved
	 * 
	 * @param tag  the synchronized data
	 */
	public void setPersistentData(class_2487 tag);
}
