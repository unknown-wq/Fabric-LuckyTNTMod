package luckytntlib.entity;

import org.jetbrains.annotations.Nullable;

import luckytntlib.util.IExplosiveEntity;
import luckytntlib.util.tnteffects.PrimedTNTEffect;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1313;
import net.minecraft.class_1541;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import net.minecraft.class_3419;

/**
 * A PrimedLTNT is an extension of Minecraft's {@link class_1541}
 * and uses a {@link PrimedTNTEffect} to easily customize the explosion effect and other parameters.
 * It implements {@link IExplosiveEntity}.
 */
public class PrimedLTNT extends class_1541 implements IExplosiveEntity{

	@Nullable
	private class_1309 igniter;
	private PrimedTNTEffect effect;
	private static final class_2940<class_2487> PERSISTENT_DATA = class_2945.method_12791(PrimedLTNT.class, class_2943.field_13318);
	
	public PrimedLTNT(class_1299<PrimedLTNT> type, class_1937 level, PrimedTNTEffect effect) {
		super(type, level);
		this.effect = effect;
	    double movement = level.field_9229.method_43058() * (double)(Math.PI * 2F);
	    this.method_18800(-Math.sin(movement) * 0.02D, 0.2F, -Math.cos(movement) * 0.02D);
	    this.setTNTFuse(effect.getDefaultFuse(this));
	}
	
	@Override
	public class_3419 method_5634() {
		return class_3419.field_15250;
	}
	
	public void setOwner(@Nullable class_1309 igniter) {
		this.igniter = igniter;
	}
	
	@Override
    public void method_5693(class_2945.class_9222 builder) {
		builder.method_56912(PERSISTENT_DATA, new class_2487());
		super.method_5693(builder);
	}
	
	@Override
	@Nullable
	public class_1309 method_24921() {
		return igniter;
	}
	
	@Override
	public PrimedTNTEffect getEffect() {
		return effect;
	}
	
	@Override
	public void method_5773() {
		if (!method_5740()) {
			method_18799(method_18798().method_1031(0.0D, -0.04D, 0.0D));
			method_5876();
		}
		method_5784(class_1313.field_6308, method_18798());
		method_18799(method_18798().method_1021(0.98D));
		if (method_24828()) {
			method_18799(method_18798().method_18805(0.7D, -0.5D, 0.7D));
		}
		effect.baseTick(this);
	}
	
	@Override
	public void method_5652(class_2487 tag) {
		if(igniter != null) {
			tag.method_10569("igniterID", igniter.method_5628());
		}
		tag.method_10566("PersistentData", getPersistentData());
		super.method_5652(tag);
	}
	
	@Override
	public void method_5749(class_2487 tag) {
		if(method_37908().method_8469(tag.method_10550("igniterID")) instanceof class_1309 lEnt) {
			igniter = lEnt;
		}
		setPersistentData(tag.method_10562("PersistentData"));
		super.method_5749(tag);
	}
	
	@Override
	public void setTNTFuse(int fuse) {
		method_6967(fuse);
	}
	
	@Override
	public int getTNTFuse() {
		return method_6969();
	}

	@Override
	public class_243 method_19538() {
		return method_30950(1);
	}

	@Override
	public void destroy() {
		method_31472();
	}
	
	@Override
	public class_1937 getLevel() {
		return method_37908();
	}

	@Override
	public double x() {
		return method_23317();
	}

	@Override
	public double y() {
		return method_23318();
	}

	@Override
	public double z() {
		return method_23321();
	}
	
	@Override
	public class_1309 owner() {
		return method_24921();
	}

	@Override
	public class_2487 getPersistentData() {
		return field_6011.method_12789(PERSISTENT_DATA);
	}

	@Override
	public void setPersistentData(class_2487 tag) {
		field_6011.method_49743(PERSISTENT_DATA, tag, true);
	}
}
