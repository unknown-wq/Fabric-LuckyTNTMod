package luckytntlib.entity;

import org.jetbrains.annotations.Nullable;

import luckytntlib.util.IExplosiveEntity;
import luckytntlib.util.tnteffects.PrimedTNTEffect;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1665;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import net.minecraft.class_3856;
import net.minecraft.class_3965;
import net.minecraft.class_3966;

/**
 * The LExplosiveProjectile is an extension of Minecraft's {@link class_1665} 
 * and represents a projectile that holds a {@link PrimedTNTEffect}.
 * Unlike a {@link PrimedLTNT} a LExplosiveProjectile has access to other types of logic specifically designed
 * for entities that travel through the world with high speeds and hit blocks or entities, while still retaining the abilities of a TNT
 * through its {@link PrimedTNTEffect}.
 * It implements {@link IExplosiveEntity} and {@link class_3856}.
 */
public class LExplosiveProjectile extends class_1665 implements IExplosiveEntity, class_3856{
	
	private static final class_2940<Integer> DATA_FUSE_ID = class_2945.method_12791(LExplosiveProjectile.class, class_2943.field_13327);
	private static final class_2940<class_2487> PERSISTENT_DATA = class_2945.method_12791(LExplosiveProjectile.class, class_2943.field_13318);
	@Nullable
	private class_1309 thrower;
	private boolean hitEntity = false;
	private PrimedTNTEffect effect;
	
	public LExplosiveProjectile(class_1299<LExplosiveProjectile> type, class_1937 level, PrimedTNTEffect effect) {
		super(type, 0, 0, 0, level, new class_1799(class_1802.field_8179), null);
		setTNTFuse(effect.getDefaultFuse(this));
		field_7572 = class_1665.class_1666.field_7592;
		this.effect = effect;
		method_57313(method_57314());
	}
	
	@Override
	public void method_24920(class_3965 hitResult) {
		class_243 pos = hitResult.method_17784().method_1023(this.method_23317(), this.method_23318(), this.method_23321());
		method_18799(pos);
		class_243 pos2 = pos.method_1029().method_1021((double) 0.05F);
		method_23327(this.method_23317() - pos2.field_1352, this.method_23318() - pos2.field_1351, this.method_23321() - pos2.field_1350);
	    field_7588 = true;
	}
	
	@Override
	public void method_7454(class_3966 hitResult) {
		if(hitResult.method_17782() instanceof class_1657 player) {
			if(!(player.method_7337() || player.method_7325())) {
				hitEntity = true;
			}
		}
		else {
			hitEntity = true;
		}
	}
	
	@Override
	public void method_5773() {
		super.method_5773();
		effect.baseTick(this);
	}
	
	@Override
	public void method_5693(class_2945.class_9222 builder) {
		builder.method_56912(DATA_FUSE_ID, -1);
		builder.method_56912(PERSISTENT_DATA, new class_2487());
		super.method_5693(builder);
	}
	
	@Override
	public void method_5652(class_2487 tag) {
		if(thrower != null) {
			tag.method_10569("throwerID", thrower.method_5628());
		}
		tag.method_10575("Fuse", (short)getTNTFuse());
		tag.method_10566("PersistentData", getPersistentData());
		super.method_5652(tag);
	}
	
	@Override
	public void method_5749(class_2487 tag) {
		if(method_37908().method_8469(tag.method_10550("throwerID")) instanceof class_1309 lEnt) {
			thrower = lEnt;
		}
		setTNTFuse(tag.method_10568("Fuse"));
		setPersistentData(tag.method_10562("PersistentData"));
		super.method_5749(tag);
	}
	
	public PrimedTNTEffect getEffect() {
		return effect;
	}
	
	public boolean inGround() {
		return field_7588;
	}
	
	public boolean hitEntity() {
		return hitEntity;
	}
	
	@Override
	public void setTNTFuse(int fuse) {
		field_6011.method_12778(DATA_FUSE_ID, fuse);
	}
	
	public void setOwner(@Nullable class_1309 thrower) {
		this.thrower = thrower;
	}
	
	@Override
	public void method_7432(class_1297 entity) {
		thrower = entity instanceof class_1309 ? (class_1309) entity : thrower;
	}
	
	@Override
	@Nullable
	public class_1309 method_24921() {
		return thrower;
	}
	
	@Override
	public class_1799 method_7445() {
		return method_7495();
	}
	
	@Override
	public int getTNTFuse() {
		return field_6011.method_12789(DATA_FUSE_ID);
	}
	
	@Override
	public class_243 method_19538() {
		return method_30950(1);
	}

	@Override
	public void destroy() {
		method_31472();
	}
	
	@Override
	public class_1937 getLevel() {
		return method_37908();
	}
	
	@Override
	public double x() {
		return method_23317();
	}

	@Override
	public double y() {
		return method_23318();
	}

	@Override
	public double z() {
		return method_23321();
	}
	
	@Override
	public class_1799 method_7495() {
		return effect == null ? new class_1799(class_1802.field_8179) : effect.getItemStack();
	}
	
	@Override
	public class_1309 owner() {
		return method_24921();
	}
	
	@Override
	public class_2487 getPersistentData() {
		return field_6011.method_12789(PERSISTENT_DATA);
	}

	@Override
	public void setPersistentData(class_2487 tag) {
		field_6011.method_49743(PERSISTENT_DATA, tag, true);
	}

	@Override
	protected class_1799 method_57314() {
		return new class_1799(class_1802.field_8179);
	}
}
