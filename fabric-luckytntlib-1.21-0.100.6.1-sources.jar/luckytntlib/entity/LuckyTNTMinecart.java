package luckytntlib.entity;

import java.util.List;
import java.util.Random;
import java.util.function.Supplier;

import luckytntlib.block.LTNTBlock;
import luckytntlib.item.LTNTMinecartItem;
import luckytntlib.util.tnteffects.PrimedTNTEffect;
import net.minecraft.class_1299;
import net.minecraft.class_1937;
import net.minecraft.class_2248;

/**
 * The LuckyTNTMinecart is an extension of the {@link LTNTMinecart}
 * and turns into a random {@link LTNTMinecart} of a list when fused.
 */
public class LuckyTNTMinecart extends LTNTMinecart{

	private List<Supplier<LTNTMinecartItem>> minecarts;
	
	public LuckyTNTMinecart(class_1299<LTNTMinecart> type, class_1937 level, Supplier<LTNTBlock> defaultRender, Supplier<Supplier<LTNTMinecartItem>> pickItem, List<Supplier<LTNTMinecartItem>> minecarts) {
		super(type, level, null, pickItem, false);
		effect = new PrimedTNTEffect() {
			@Override
			public class_2248 getBlock() {
				return defaultRender.get();
			}
		};
		this.minecarts = minecarts;
		setTNTFuse(-1);
	}
	
	@Override
	public void fuse() {
		LTNTMinecart minecart = minecarts.get(new Random().nextInt(minecarts.size())).get().createMinecart(method_37908(), method_23317(), method_23318(), method_23321(), placer);
		minecart.method_36456(method_36454());
		minecart.method_18799(method_18798());
		method_37908().method_8649(minecart);
		minecart.fuse();
		method_31472();
	}
}
