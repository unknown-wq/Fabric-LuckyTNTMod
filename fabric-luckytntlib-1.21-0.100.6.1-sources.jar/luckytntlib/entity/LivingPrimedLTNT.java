package luckytntlib.entity;

import org.jetbrains.annotations.Nullable;

import luckytntlib.util.IExplosiveEntity;
import luckytntlib.util.tnteffects.PrimedTNTEffect;
import net.minecraft.class_1282;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1314;
import net.minecraft.class_1541;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import net.minecraft.class_8111;

/**
 * A LivingPrimedLTNT is a type of TNT designed to have health points,
 * attack damage and be able to use an AI to wander around and interact with the world,
 * while still retaining the abilities of a TNT through its {@link PrimedTNTEffect}.
 * It has to be registered independetly of the {@link PrimedLTNT} 
 * because Minecraft's {@link class_1541} does not extend any form of a {@link class_1309}.
 * It implements {@link IExplosiveEntity}.
 */
public class LivingPrimedLTNT extends class_1314 implements IExplosiveEntity{
	
	@Nullable 
	private class_1309 igniter;
	private PrimedTNTEffect effect;
	private static final class_2940<Integer> DATA_FUSE_ID = class_2945.method_12791(LivingPrimedLTNT.class, class_2943.field_13327);
	private static final class_2940<class_2487> PERSISTENT_DATA = class_2945.method_12791(LivingPrimedLTNT.class, class_2943.field_13318);
	
	public LivingPrimedLTNT(class_1299<? extends class_1314> type, class_1937 level, @Nullable PrimedTNTEffect effect) {
		super(type, level);
		this.effect = effect;
		this.setTNTFuse(effect.getDefaultFuse(this));
	}
	
	@Override
	public void method_5773() {
		super.method_5773();
		effect.baseTick(this);
	}
		
	@Override
	public void method_5693(class_2945.class_9222 builder) {
		builder.method_56912(DATA_FUSE_ID, -1);
		builder.method_56912(PERSISTENT_DATA, new class_2487());
		super.method_5693(builder);
	}
	
	@Override
	public void method_5652(class_2487 tag) {
		if(igniter != null) {
			tag.method_10569("throwerID", igniter.method_5628());
		}
		tag.method_10575("Fuse", (short)getTNTFuse());
		tag.method_10566("PersistentData", getPersistentData());
		super.method_5652(tag);
	}
	
	@Override
	public void method_5749(class_2487 tag) {
		if(method_37908().method_8469(tag.method_10550("throwerID")) instanceof class_1309 lEnt) {
			igniter = lEnt;
		}
		setTNTFuse(tag.method_10568("Fuse"));
		setPersistentData(tag.method_10562("PersistentData"));
		super.method_5749(tag);
	}
	
	@Override
	public boolean method_5974(double distance) {
		return false;
	}
	
	@Override
	public void method_6070() {
	}
	
	@Override
	public void method_5762(double x, double y, double z) {
	}
	
	public void setOwner(@Nullable class_1309 thrower) {
		this.igniter = thrower;
	}

	@Override
	public boolean method_5643(class_1282 source, float amount) {
		if(source.method_49708(class_8111.field_42347)) {
			return true;
		}
		return false;
	}

	@Override
	public int getTNTFuse() {
		return field_6011.method_12789(DATA_FUSE_ID);
	}

	@Override
	public void setTNTFuse(int fuse) {
		field_6011.method_12778(DATA_FUSE_ID, fuse);
	}

	@Override
	public class_1937 getLevel() {
		return method_37908();
	}

	@Override
	public class_243 method_19538() {
		return method_30950(1);
	}

	@Override
	public double x() {
		return method_23317();
	}

	@Override
	public double y() {
		return method_23318();
	}

	@Override
	public double z() {
		return method_23321();
	}

	@Override
	public void destroy() {
		method_31472();
	}

	@Override
	public PrimedTNTEffect getEffect() {
		return effect;
	}

	@Override
	public class_1309 owner() {
		return igniter;
	}

	@Override
	public class_2487 getPersistentData() {
		return field_6011.method_12789(PERSISTENT_DATA);
	}
	
	@Override
	public void setPersistentData(class_2487 tag) {
		field_6011.method_49743(PERSISTENT_DATA, tag, true);
	}
}
