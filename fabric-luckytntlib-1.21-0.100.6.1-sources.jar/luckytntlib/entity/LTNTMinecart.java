package luckytntlib.entity;

import java.util.function.Supplier;

import org.jetbrains.annotations.Nullable;

import luckytntlib.item.LTNTMinecartItem;
import luckytntlib.util.IExplosiveEntity;
import luckytntlib.util.tnteffects.PrimedTNTEffect;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1665;
import net.minecraft.class_1688;
import net.minecraft.class_1695;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2680;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import net.minecraft.class_3417;
import net.minecraft.class_5712;
import net.minecraft.class_8111;

/**
 * The LTNTMinecart is an extension of Minecraft's {@link class_1688}
 * and can hold an already existing {@link PrimedLTNT} and its {@link PrimedTNTEffect}.
 * It implements {@link IExplosiveEntity}.
 */
public class LTNTMinecart extends class_1695 implements IExplosiveEntity{

	private static final class_2940<Integer> DATA_FUSE_ID = class_2945.method_12791(LTNTMinecart.class, class_2943.field_13327);
	private static final class_2940<class_2487> PERSISTENT_DATA = class_2945.method_12791(LTNTMinecart.class, class_2943.field_13318);
	private boolean explodeInstantly;
	protected PrimedTNTEffect effect;
	protected Supplier<Supplier<LTNTMinecartItem>> pickItem;
	public class_1309 placer;
	
	public LTNTMinecart(class_1299<LTNTMinecart> type, class_1937 level, Supplier<class_1299<PrimedLTNT>> TNT, Supplier<Supplier<LTNTMinecartItem>> pickItem, boolean explodeInstantly) {
		super(type, level);
		if(TNT != null) {
			PrimedLTNT tnt = TNT.get().method_5883(level);
			this.effect = tnt.getEffect();
			tnt.method_31472();
		}
		else if(!(this instanceof LuckyTNTMinecart)) {
			method_31472();
		}
		this.explodeInstantly = explodeInstantly;
		this.pickItem = pickItem;
		setTNTFuse(-1);
	}
	
	@Override
	public void method_5773() {
		super.method_5773();
		if(getTNTFuse() >= 0) {
			getEffect().baseTick(this);
		}
		if(field_5976 && method_18798().method_37268() >= 0.01f && getTNTFuse() < 0) {
			if(explodesInstantly()) {
				fuse();
				setTNTFuse(0);
			}
			else {
				fuse();
			}
		}
	}

	@Override
	public class_1269 method_5688(class_1657 player, class_1268 hand) {
		return class_1269.field_5811;
	}
	
	@Override
	public boolean method_5643(class_1282 source, float amount) {
		if (!method_37908().method_8608() && !method_31481()) {
			class_1297 entity = source.method_5526();
			if (entity instanceof class_1665 abstractarrow) {
				if (abstractarrow.method_5809() && getTNTFuse() < 0) {
					fuse();
				}
			}
			if(source.method_49708(class_8111.field_42336) && getTNTFuse() >= 0) {
				return false;
			}
			if (method_5679(source)) {
				return false;
			} else {
				method_54300(-method_54296());
				method_54299(10);
				method_5785();
				method_54297(method_54294() + amount * 10.0F);
				method_32875(class_5712.field_28736, source.method_5529());
				boolean flag = source.method_5529() instanceof class_1657 && ((class_1657) source.method_5529()).method_31549().field_7477;
				if (flag || method_54294() > 40.0F) {
					method_5772();
					if (flag && !method_16914()) {
						method_31472();
					} else {
					}
				}

				return true;
			}
		} else {
			return true;
		}
	}
	
	@Override
	public void method_7516(class_1282 source) {
		double speed = method_18798().method_37268();
		if (!source.method_49708(class_8111.field_42337) && !source.method_49708(class_8111.field_42331) && !(speed >= 0.01f)) {
			super.method_7516(source);
		} else {
			if(getTNTFuse() < 0) {
				if(explodesInstantly()) {
					fuse();
					class_1937 level = method_37908();
					setTNTFuse(getEffect().getDefaultFuse(this) / 4 + level.field_9229.method_43048(getEffect().getDefaultFuse(this)) / 4);
				}
				else {
					fuse();
				}
			}
		}
	}
	
	@Override
	public boolean method_5747(float ditance, float damage, class_1282 source) {
		if (ditance >= 3.0F && getTNTFuse() < 0) {
			if(explodesInstantly()) {
				fuse();
				setTNTFuse(0);
			}
			else {
				fuse();
			}
		}

		return super.method_5747(ditance, damage, source);
	}
	
	@Override
	public void method_7506(int x, int y, int z, boolean active) {
		if(active && getTNTFuse() < 0) {
			fuse();
		}
	}

	public void fuse() {
		setTNTFuse(getEffect().getDefaultFuse(this));	
		method_37908().method_8396(null, new class_2338((int)method_30950(1).field_1352, (int)method_30950(1).field_1351, (int)method_30950(1).field_1350), class_3417.field_15079, method_5634(), 1f, 1f);
	}
	
	@Override
	public void method_5693(class_2945.class_9222 builder) {
		builder.method_56912(DATA_FUSE_ID, -1);
		builder.method_56912(PERSISTENT_DATA, new class_2487());
		super.method_5693(builder);
	}
	
	@Nullable
	public class_1309 getOwner() {
		return placer;
	}
	
	public void setOwner(class_1309 owner) {
		this.placer = owner;
	}
	
	@Override
	public class_1799 method_31480() {
		return new class_1799(pickItem.get().get());
	}
	
	@Override
	protected class_1792 method_7557() {
		return pickItem.get().get();
	}
	
	@Override
	public class_2680 method_7519() {
		return getEffect().getBlockState(this);
	}
	
	@Override
	public void method_5652(class_2487 tag) {
		if(placer != null) {
			tag.method_10569("placerID", placer.method_5628());
		}
		tag.method_10575("Fuse", (short)getTNTFuse());
		tag.method_10566("PersistentData", getPersistentData());
		super.method_5652(tag);
	}
	
	@Override
	public void method_5749(class_2487 tag) {
		if(method_37908().method_8469(tag.method_10550("placerID")) instanceof class_1309 lEnt) {
			placer = lEnt;
		}
		setTNTFuse(tag.method_10568("Fuse"));
		setPersistentData(tag.method_10562("PersistentData"));
		super.method_5749(tag);
	}
	
	@Override
	public class_1689 method_7518() {
		return class_1688.class_1689.field_7675;
	}
		
	public boolean explodesInstantly() {
		return explodeInstantly;
	}
	
	public PrimedTNTEffect getEffect() {
		return effect;
	}
	
	@Override
	public int getTNTFuse() {
		return field_6011.method_12789(DATA_FUSE_ID);
	}
	
	@Override
	public void setTNTFuse(int fuse) {
		field_6011.method_12778(DATA_FUSE_ID, fuse);
	}
	
	@Override
	public class_243 method_19538() {
		return method_30950(1);
	}

	@Override
	public void destroy() {
		method_31472();
	}
	
	@Override
	public class_1937 getLevel() {
		return method_37908();
	}
	
	@Override
	public double x() {
		return method_23317();
	}

	@Override
	public double y() {
		return method_23318();
	}

	@Override
	public double z() {
		return method_23321();
	}
	
	@Override
	public class_1309 owner() {
		return getOwner();
	}

	@Override
	public class_2487 getPersistentData() {
		return field_6011.method_12789(PERSISTENT_DATA);
	}

	@Override
	public void setPersistentData(class_2487 tag) {
		field_6011.method_49743(PERSISTENT_DATA, tag, true);
	}
}
