package luckytntlib.network;

import luckytntlib.LuckyTNTLib;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public class ClientReadyC2SPacket implements class_8710 {
	
	public static final class_2960 NAME = class_2960.method_60655(LuckyTNTLib.MODID, "client_ready_c2s");
	public static final class_8710.class_9154<ClientReadyC2SPacket> ID = new class_8710.class_9154<>(NAME);
    public static final class_9139<class_9129, ClientReadyC2SPacket> CODEC = class_9139.method_56438(ClientReadyC2SPacket::write, ClientReadyC2SPacket::new);
	
	public ClientReadyC2SPacket() {
	}
	
	public ClientReadyC2SPacket(class_2540 buf) {
	}
	
	public void write(class_2540 buf) {
	}

	@Override
	public class_9154<? extends class_8710> method_56479() {
		return ID;
	}
}
