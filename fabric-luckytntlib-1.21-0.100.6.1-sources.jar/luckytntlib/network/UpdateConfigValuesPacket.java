package luckytntlib.network;

import java.util.List;

import luckytntlib.LuckyTNTLib;
import luckytntlib.config.common.Config;
import luckytntlib.config.common.Config.ConfigValue;
import net.minecraft.class_2487;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public class UpdateConfigValuesPacket implements class_8710 {
	
	public static final class_2960 NAME = class_2960.method_60655(LuckyTNTLib.MODID, "update_config_values");
	public static final class_8710.class_9154<UpdateConfigValuesPacket> ID = new class_8710.class_9154<>(NAME);
    public static final class_9139<class_9129, UpdateConfigValuesPacket> CODEC = class_9139.method_56438(UpdateConfigValuesPacket::write, UpdateConfigValuesPacket::new);
	
	public final class_2487 data;

	public UpdateConfigValuesPacket(List<ConfigValue<?>> configValues) {
		data = Config.valuesToNbtCompound(configValues);
	}
	
	public UpdateConfigValuesPacket(class_2540 buf) {
		data = buf.method_10798();
	}
	
	public void write(class_2540 buf) {
		buf.method_10794(data);
	}

	@Override
	public class_9154<? extends class_8710> method_56479() {
		return ID;
	}
}
