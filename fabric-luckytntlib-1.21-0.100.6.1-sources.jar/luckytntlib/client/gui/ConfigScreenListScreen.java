package luckytntlib.client.gui;

import com.mojang.datafixers.util.Pair;

import luckytntlib.config.common.ConfigScreenFactory;
import luckytntlib.registry.RegistryHelper;
import net.minecraft.class_2561;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5244;
import net.minecraft.class_7845;
import net.minecraft.class_7845.class_7939;
import net.minecraft.class_8132;

public class ConfigScreenListScreen extends class_437 {
	
	class_8132 layout = new class_8132(this, 20, 40);

	public ConfigScreenListScreen() {
		super(class_2561.method_43473());
	}

	@Override
	public void method_25426() {
		class_7845 grid = new class_7845();
		
		grid.method_46458().method_46477(4).method_46475(4).method_46467();
		class_7939 rows = grid.method_47610(3);
		
		for(Pair<class_2561, ConfigScreenFactory> pair : RegistryHelper.configScreens) {
			class_2561 name = pair.getFirst();
			ConfigScreenFactory factory = pair.getSecond();
			
			rows.method_47612(new class_4185.class_7840(name, button -> openScreen(factory.apply())).method_46432(100).method_46431());
		}
		
		layout.method_48999(grid);
		layout.method_48996(new class_4185.class_7840(class_5244.field_24334, button -> method_25419()).method_46432(100).method_46431());
		layout.method_48206(this::method_37063);
		method_48640();
	}
	
    @Override
    protected void method_48640() {
        layout.method_48222();
    }
    
    protected void openScreen(class_437 screen) {
    	field_22787.method_1507(screen);
    }
	
	@Override
	public void method_25419() {
		super.method_25419();
	}
}
