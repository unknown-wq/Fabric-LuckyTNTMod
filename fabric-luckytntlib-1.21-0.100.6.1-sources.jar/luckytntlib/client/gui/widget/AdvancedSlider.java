package luckytntlib.client.gui.widget;

import java.text.DecimalFormat;
import net.minecraft.class_2561;
import net.minecraft.class_3532;
import net.minecraft.class_357;

/**
 * Slider widget implementation which allows inputting values in a certain range
 * with optional step size.
 */
public class AdvancedSlider extends class_357 {

	protected class_2561 prefix;
	protected class_2561 suffix;

	protected double minValue;
	protected double maxValue;
	protected double originalCurrentValue;

	/** Allows input of discontinuous values with a certain step */
	protected double stepSize;

	protected boolean drawString;

	private final DecimalFormat format;

	/**
	 * @param x            x position of upper left corner
	 * @param y            y position of upper left corner
	 * @param width        Width of the widget
	 * @param height       Height of the widget
	 * @param prefix       {@link class_2561} displayed before the value string
	 * @param suffix       {@link class_2561} displayed after the value string
	 * @param minValue     Minimum (left) value of slider
	 * @param maxValue     Maximum (right) value of slider
	 * @param currentValue Starting value when widget is first displayed
	 * @param stepSize     Size of step used. Precision will automatically be
	 *                     calculated based on this value if this value is not 0.
	 * @param precision    Only used when {@code stepSize} is 0. Limited to a
	 *                     maximum of 4 (inclusive).
	 * @param drawString   Should text be displayed on the widget
	 */
	public AdvancedSlider(int x, int y, int width, int height, class_2561 prefix, class_2561 suffix, double minValue, double maxValue, double currentValue, double stepSize, int precision, boolean drawString) {
		super(x, y, width, height, class_2561.method_43473(), 0D);
		this.prefix = prefix;
		this.suffix = suffix;
		this.minValue = minValue;
		this.maxValue = maxValue;
		this.stepSize = Math.abs(stepSize);
		this.originalCurrentValue = currentValue;
		field_22753 = snapToNearest((currentValue - minValue) / (maxValue - minValue));
		this.drawString = drawString;

		if (stepSize == 0D) {
			precision = Math.min(precision, 4);

			StringBuilder builder = new StringBuilder("0");

			if (precision > 0) {
				builder.append('.');
			}

			while (precision-- > 0) {
				builder.append('0');
			}

			format = new DecimalFormat(builder.toString());
		} else if (class_3532.method_20390(this.stepSize, Math.floor(this.stepSize))) {
			format = new DecimalFormat("0");
		} else {
			format = new DecimalFormat(Double.toString(this.stepSize).replaceAll("\\d", "0"));
		}

		method_25346();
	}

	public AdvancedSlider(int x, int y, int width, int height, class_2561 prefix, class_2561 suffix, double minValue, double maxValue, double currentValue, boolean drawString) {
		this(x, y, width, height, prefix, suffix, minValue, maxValue, currentValue, 1D, 0, drawString);
	}

	public double getValue() {
		return snapToNearest(field_22753) * (maxValue - minValue) + minValue;
	}

	public long getValueLong() {
		return Math.round(getValue());
	}

	public int getValueInt() {
		return (int) getValueLong();
	}

	public void setSliderValue(double val) {
		double d = field_22753;
        field_22753 = snapToNearest((val - minValue) / (maxValue - minValue));
        if (d != field_22753) {
            method_25344();
        }
        method_25346();
	}

	public String getValueString() {
		return format.format(getValue());
	}

	public double getInitialValue() {
		return originalCurrentValue;
	}

	private double snapToNearest(double value) {
		if (stepSize <= 0D) {
			return class_3532.method_15350(value, 0D, 1D);
		}

		value = class_3532.method_16436(class_3532.method_15350(value, 0D, 1D), minValue, maxValue);

		value = (stepSize * Math.round(value / stepSize));

		if (minValue > maxValue) {
			value = class_3532.method_15350(value, maxValue, minValue);
		} else {
			value = class_3532.method_15350(value, minValue, maxValue);
		}

		return class_3532.method_33722(value, minValue, maxValue, 0D, 1D);
	}

	@Override
	protected void method_25346() {
		if (drawString) {
			method_25355(class_2561.method_43470("").method_10852(prefix).method_27693(getValueString()).method_10852(suffix));
		} else {
			method_25355(class_2561.method_43473());
		}
	}

	@Override
	protected void method_25344() {
	}
}
