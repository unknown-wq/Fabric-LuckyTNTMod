package luckytntlib.client.gui.widget;

import net.minecraft.class_2561;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_7842;

/**
 * Renders a vertically center-aligned String in a Layout.
 * Is used in the config Screen
 */
public class CenteredStringWidget extends class_7842 {

	public CenteredStringWidget(class_2561 component, class_327 font) {
		super(component, font);
	}

	@Override
	public void method_48579(class_332 graphics, int i1, int i2, float f) {
		graphics.method_51448().method_22903();
		graphics.method_51448().method_46416(0f, 6f, 0f);
		super.method_48579(graphics, i1, i2, f);
		graphics.method_51448().method_22909();
	}
}