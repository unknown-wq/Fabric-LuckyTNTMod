package luckytntlib.client.gui;

import java.util.ArrayList;
import java.util.List;

import luckytntlib.LuckyTNTLib;
import luckytntlib.client.gui.widget.AdvancedSlider;
import luckytntlib.client.gui.widget.CenteredStringWidget;
import luckytntlib.config.LuckyTNTLibConfigValues;
import luckytntlib.config.common.Config;
import luckytntlib.config.common.Config.ConfigValue;
import luckytntlib.network.UpdateConfigValuesPacket;
import net.minecraft.class_2561;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5244;
import net.minecraft.class_7842;
import net.minecraft.class_7845;
import net.minecraft.class_7845.class_7939;
import net.minecraft.class_7847;
import net.minecraft.class_7919;
import net.minecraft.class_8132;
import net.minecraft.class_8667;

/**
 * The config screen of Lucky TNT Lib.
 * Extending this is not advised.
 */
public class ConfigScreen extends class_437 {
	
	boolean performant_explosion_initial_value = false;
	double explosion_performance_factor_initial_value = 0d;

	class_4185 performant_explosion = null;
	
	AdvancedSlider explosion_performance_factor_slider = null;
	
	class_8132 layout = new class_8132(this, 20, 40);
	
	public ConfigScreen() {
		super(class_2561.method_43471("config.title"));
	}
	
	@Override
	public void method_25426() {
		class_8667 linear = layout.method_48992(class_8667.method_52741());
		linear.method_52738(new class_7842(class_2561.method_43471("config.title"), field_22793), class_7847::method_46467);
		class_7845 grid = new class_7845();
		
		grid.method_46458().method_46477(4).method_46475(4).method_46467();
		class_7939 rows = grid.method_47610(3);
		rows.method_47612(performant_explosion = new class_4185.class_7840(LuckyTNTLibConfigValues.PERFORMANT_EXPLOSION.get().booleanValue() ? class_5244.field_24332 : class_5244.field_24333, button -> nextBooleanValue(LuckyTNTLibConfigValues.PERFORMANT_EXPLOSION, button)).method_46432(100).method_46431());
		performant_explosion_initial_value = LuckyTNTLibConfigValues.PERFORMANT_EXPLOSION.get().booleanValue();
		performant_explosion.method_47400(class_7919.method_47407(class_2561.method_43471("config.performant_explosion_tooltip")));
		rows.method_47612(new CenteredStringWidget(class_2561.method_43471("config.performant_explosion"), field_22793));
		rows.method_47612(new class_4185.class_7840(class_2561.method_43471("config.reset"), button -> resetBooleanValue(LuckyTNTLibConfigValues.PERFORMANT_EXPLOSION, performant_explosion)).method_46432(100).method_46431());
		rows.method_47612(explosion_performance_factor_slider = new AdvancedSlider(0, 0, 100, 20, class_2561.method_43473(), class_2561.method_43473(), 30d, 60d, LuckyTNTLibConfigValues.EXPLOSION_PERFORMANCE_FACTOR.get() * 100, true));
		explosion_performance_factor_slider.method_47400(class_7919.method_47407(class_2561.method_43471("config.explosion_performance_factor_tooltip")));
		explosion_performance_factor_initial_value = LuckyTNTLibConfigValues.EXPLOSION_PERFORMANCE_FACTOR.get().doubleValue();
		rows.method_47612(new CenteredStringWidget(class_2561.method_43471("config.explosion_performance_factor"), field_22793));
		rows.method_47612(new class_4185.class_7840(class_2561.method_43471("config.reset"), button -> resetDoubleValue(LuckyTNTLibConfigValues.EXPLOSION_PERFORMANCE_FACTOR, explosion_performance_factor_slider)).method_46432(100).method_46431());
		
		layout.method_48999(grid);
		layout.method_48996(new class_4185.class_7840(class_5244.field_24334, button -> method_25419()).method_46432(100).method_46431());
		layout.method_48206(this::method_37063);
		method_48640();
	}
	
    @Override
    protected void method_48640() {
        layout.method_48222();
    }
	
	@Override
	public void method_25419() {
		if(explosion_performance_factor_slider != null) {
			LuckyTNTLibConfigValues.EXPLOSION_PERFORMANCE_FACTOR.set(explosion_performance_factor_slider.getValue() / 100d);
		}
		
		List<ConfigValue<?>> values = new ArrayList<>();
		if(LuckyTNTLibConfigValues.EXPLOSION_PERFORMANCE_FACTOR.get().doubleValue() != explosion_performance_factor_initial_value) {
			values.add(LuckyTNTLibConfigValues.EXPLOSION_PERFORMANCE_FACTOR);
		}
		if(LuckyTNTLibConfigValues.PERFORMANT_EXPLOSION.get().booleanValue() != performant_explosion_initial_value) {
			values.add(LuckyTNTLibConfigValues.PERFORMANT_EXPLOSION);
		}
		if(!values.isEmpty()) {
			LuckyTNTLib.RH.sendC2SPacket(new UpdateConfigValuesPacket(values));
		}
		
		super.method_25419();
	}
	
	public void resetDoubleValue(Config.DoubleValue config, AdvancedSlider slider) {
		config.set(config.getDefault());
		slider.setSliderValue(config.getDefault() * 100);
	}
	
	public void resetBooleanValue(Config.BooleanValue config, class_4185 button) {
		config.set(config.getDefault());
		button.method_25355(config.getDefault() ? class_5244.field_24332 : class_5244.field_24333);
	}
	
	public void nextBooleanValue(Config.BooleanValue config, class_4185 button) {
		boolean value = config.get().booleanValue();
		if(value) {
			value = false;
		} else {
			value = true;
		}
		config.set(value);
		button.method_25355(value ? class_5244.field_24332 : class_5244.field_24333);
	}
}
