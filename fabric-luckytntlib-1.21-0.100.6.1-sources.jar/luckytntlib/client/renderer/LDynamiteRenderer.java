package luckytntlib.client.renderer;

import luckytntlib.entity.LExplosiveProjectile;
import luckytntlib.util.tnteffects.PrimedTNTEffect;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1059;
import net.minecraft.class_2960;
import net.minecraft.class_3856;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_5617;
import net.minecraft.class_7833;
import net.minecraft.class_811;
import net.minecraft.class_897;
import net.minecraft.class_918;
import net.minecraft.class_953;

/**
 * The LDynamiteRenderer is similar to the {@link class_953}, but the item is also scaled by using
 * the size given by the {@link PrimedTNTEffect} of the {@link LExplosiveProjectile}.
 * @param <T>  is an instance of {@link LExplosiveProjectile} and implements {@link class_3856}
 */
@Environment(value=EnvType.CLIENT)
public class LDynamiteRenderer<T extends LExplosiveProjectile & class_3856> extends class_897<T>{
	
	private final class_918 itemRenderer;
	
	public LDynamiteRenderer(class_5617.class_5618 context) {
		super(context);
		itemRenderer = context.method_32168();
	}
	
	@Override
	public void render(T entity, float yaw, float tickDelta, class_4587 matrices, class_4597 vertexConsumers, int light) {
		if (entity.field_6012 >= 2 || !(field_4676.field_4686.method_19331().method_5858(entity) < 12.25D)) {
			matrices.method_22903();
			matrices.method_22905(entity.getEffect().getSize(entity), entity.getEffect().getSize(entity), entity.getEffect().getSize(entity));
			matrices.method_22907(field_4676.method_24197());
			matrices.method_22907(class_7833.field_40716.rotationDegrees(180.0F));
			itemRenderer.method_23178(entity.method_7495(), class_811.field_4318, light, class_4608.field_21444, matrices, vertexConsumers, entity.method_37908(), entity.method_5628());
			matrices.method_22909();
			super.method_3936(entity, yaw, tickDelta, matrices, vertexConsumers, light);
		}
	}
	
	@SuppressWarnings("deprecation")
	public class_2960 getTexture(T entity) {
		return class_1059.field_5275;
	}
}
