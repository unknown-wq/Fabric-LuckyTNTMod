package luckytntlib.client.renderer;

import luckytntlib.entity.LTNTMinecart;
import luckytntlib.util.IExplosiveEntity;
import luckytntlib.util.tnteffects.PrimedTNTEffect;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5602;
import net.minecraft.class_5617;
import net.minecraft.class_925;
import net.minecraft.class_957;

/**
 * The LTNTMinecartRenderer renders a Minecart with a TNT inside of it.
 * The TNT is scaled using the size parameter of its {@link PrimedTNTEffect}.
 */
@Environment(value=EnvType.CLIENT)
public class LTNTMinecartRenderer extends class_925<LTNTMinecart>{
	
	public LTNTMinecartRenderer(class_5617.class_5618 context) {
		super(context, class_5602.field_27666);
	}
	
	@Override
	public void renderBlock(LTNTMinecart entity, float partialTicks, class_2680 state, class_4587 stack, class_4597 buffer, int light) {
		int fuse = entity.getTNTFuse();
		if(fuse > -1 && (float) fuse - partialTicks + 1f < 10f) {
			float scaleMult = 1f - ((float)fuse - partialTicks + 1f) / 10f;
			scaleMult = class_3532.method_15363(scaleMult, 0f, 1f);
			scaleMult *= scaleMult;
			scaleMult *= scaleMult;
			float scale = 1f + scaleMult * 0.3f;
			stack.method_22905(scale, scale, scale);
		}
		stack.method_46416((-entity.getEffect().getSize(entity) + 1) / 2f, 0, (-entity.getEffect().getSize(entity) + 1) / 2f);
		stack.method_22905(entity.getEffect().getSize((IExplosiveEntity)entity), entity.getEffect().getSize((IExplosiveEntity)entity), entity.getEffect().getSize((IExplosiveEntity)entity));
		class_957.method_23190(class_310.method_1551().method_1541(), state, stack, buffer, light, fuse > -1 && fuse / 5 % 2 == 0);
	}
}
