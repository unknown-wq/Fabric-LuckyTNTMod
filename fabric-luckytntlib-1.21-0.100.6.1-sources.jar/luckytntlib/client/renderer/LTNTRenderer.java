package luckytntlib.client.renderer;

import luckytntlib.util.IExplosiveEntity;
import luckytntlib.util.tnteffects.PrimedTNTEffect;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1059;
import net.minecraft.class_1297;
import net.minecraft.class_2530;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5617;
import net.minecraft.class_776;
import net.minecraft.class_897;
import net.minecraft.class_957;

/**
 * The LTNTRenderer renders an {@link IExplosiveEntity} as a block.
 * The block can be a type of TNT, in which case it will also be animated, or any other block,
 * in which case it is rendered like a normal block.
 * The block is also scaled using the size of its {@link PrimedTNTEffect}.
 */
@Environment(value=EnvType.CLIENT)
public class LTNTRenderer extends class_897<class_1297>{
	private class_776 blockRenderer;
	
	public LTNTRenderer(class_5617.class_5618 context) {
		super(context);
		this.blockRenderer = context.method_43337();
	}
	
	public void method_3936(class_1297 entity, float yaw, float partialTicks, class_4587 posestack, class_4597 buffer, int light) {
    	if(entity instanceof IExplosiveEntity ent) {
			posestack.method_22903();
	        posestack.method_46416(0, 0, 0);
	        int i = ent.getTNTFuse();
	        if ((float)i - partialTicks + 1.0F < 10.0F && ent.getEffect().getBlockState((IExplosiveEntity)entity).method_26204() instanceof class_2530) {
	           float f = 1.0F - ((float)i - partialTicks + 1.0F) / 10.0F;
	           f = class_3532.method_15363(f, 0.0F, 1.0F);
	           f *= f;
	           f *= f;
	           float f1 = 1.0F + f * 0.3F;
	           posestack.method_22905(f1, f1, f1);
	        }
	        posestack.method_22905(ent.getEffect().getSize((IExplosiveEntity)entity), ent.getEffect().getSize((IExplosiveEntity)entity), ent.getEffect().getSize((IExplosiveEntity)entity));
	        posestack.method_22904(-0.5d, 0, -0.5d);
	        class_957.method_23190(blockRenderer, ent.getEffect().getBlockState((IExplosiveEntity)entity), posestack, buffer, light, ent.getEffect().getBlockState((IExplosiveEntity)entity).method_26204() instanceof class_2530 ? i / 5 % 2 == 0 : false);
	        posestack.method_22909();
    	}
        super.method_3936(entity, yaw, partialTicks, posestack, buffer, light);
    }
	
	@SuppressWarnings("deprecation")
	@Override
    public class_2960 method_3931(class_1297 tntEntity) {
        return class_1059.field_5275;
    }
}
