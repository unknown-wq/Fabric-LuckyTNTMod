package luckytntlib.client;

import luckytntlib.client.gui.ConfigScreen;
import luckytntlib.client.gui.ConfigScreenListScreen;
import luckytntlib.config.common.ConfigScreenFactory;
import net.minecraft.class_310;
import net.minecraft.class_437;

public class ClientAccess {

	private static final ConfigScreenFactory screenFactory = new ConfigScreenFactory() {
		
		@Override
		public class_437 apply() {
			return new ConfigScreen();
		}
	};
	
	public static void openConfigScreenListScreen() {
		class_310 minecraft = class_310.method_1551();
		minecraft.method_1507(new ConfigScreenListScreen());
	}
	
	public static ConfigScreenFactory getFactory() {
		return screenFactory;
	}
}
