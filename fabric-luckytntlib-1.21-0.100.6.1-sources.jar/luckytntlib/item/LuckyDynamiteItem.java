package luckytntlib.item;

import java.util.List;
import java.util.function.Supplier;

import luckytntlib.entity.LExplosiveProjectile;
import luckytntlib.registry.RegistryHelper;
import net.minecraft.class_1282;
import net.minecraft.class_1309;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_3222;

/**
 * The LuckyDynamiteItem is an extension of the {@link LDynamiteItem} and serves the simple purpose of spawning a random
 * {@link LExplosiveProjectile} of a {@link LDynamiteItem} contained in a {@link List}.
 * The list could for instance be set to one of the many lists of {@link LDynamiteItem} found in the {@link RegistryHelper}.
 */
public class LuckyDynamiteItem extends LDynamiteItem{

	public List<Supplier<LDynamiteItem>> dynamites;
	
	public LuckyDynamiteItem(class_1792.class_1793 properties, List<Supplier<LDynamiteItem>> dynamites) {
		super(properties, null);
		this.dynamites = dynamites;
	}
	
	@Override
	public void method_7852(class_1937 level, class_1309 player, class_1799 stack, int count) {
		if(player instanceof class_3222 sPlayer) {
			shoot(level, player.method_23317(), player.method_23318() + player.method_5751(), player.method_23321(), player.method_5828(1), 2, player);		
			if(!sPlayer.method_7337()) {
				stack.method_7934(1);
			}
		}
	}
	
	/**
	 * Gets a random {@link LDynamiteItem} from the list held by this item and calls its shoot method.
	 * Can not shoot another {@link LuckyDynamiteItem}.
	 * @param level  the current level
	 * @param x  the x position
	 * @param y  the y position (eye level needs to be added manually!)
	 * @param z  the z position
	 * @param direction  the direction the projectile will be thrown in
	 * @param power  the power with which the projectile is thrown
	 * @param thrower  the owner for the spawned projectile (used primarely for the {@link class_1282})
	 * @return {@link LExplosiveProjectile}
	 */
	@Override
	public LExplosiveProjectile shoot(class_1937 level, double x, double y, double z, class_243 direction, float power, class_1309 thrower) {
		int rand = random.nextInt(dynamites.size());
		return dynamites.get(rand).get().shoot(level, x, y, z, direction, power, thrower);
	}
}
