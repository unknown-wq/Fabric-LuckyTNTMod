package luckytntlib.item;

import java.util.function.Supplier;

import org.jetbrains.annotations.Nullable;

import luckytntlib.entity.LTNTMinecart;
import net.minecraft.class_1269;
import net.minecraft.class_1282;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1688;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1808;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2241;
import net.minecraft.class_2338;
import net.minecraft.class_2357;
import net.minecraft.class_2680;
import net.minecraft.class_2768;
import net.minecraft.class_3481;
import net.minecraft.class_5712;
import net.minecraft.class_9334;

/**
 * The LTNTMinecartItem is an important step in making a custom TNT minecart.
 * It can be used to spawn a {@link LTNTMinecart} onto rails.
 * If a {@link class_2357} has been registered dispensers can also spawn the minecart.
 */
public class LTNTMinecartItem extends class_1808{

	@Nullable Supplier<Supplier<class_1299<LTNTMinecart>>> minecart;
	
	public LTNTMinecartItem(class_1792.class_1793 properties, @Nullable Supplier<Supplier<class_1299<LTNTMinecart>>> minecart) {
		super(class_1688.class_1689.field_7675, properties);
		this.minecart = minecart;
	}
	
	@Override
	public class_1269 method_7884(class_1838 context) {
		class_1937 level = context.method_8045();
		class_2338 pos = context.method_8037();
		class_2680 state = level.method_8320(pos);
		if(!state.method_26164(class_3481.field_15463)) {
			return class_1269.field_5814;
		}
		class_1799 stack = context.method_8041();
		double railHeight = 0;
		if(!level.field_9236) {
            class_2768 rail = state.method_26204() instanceof class_2241 ? state.method_11654(((class_2241)state.method_26204()).method_9474()) : class_2768.field_12665;
            if (rail.method_11897()) {
               railHeight = 0.5D;
            }
		}
		LTNTMinecart minecart = createMinecart(level, pos.method_10263() + 0.5f, pos.method_10264() + 0.0625f + railHeight, pos.method_10260() + 0.5f, context.method_8036());
		minecart.setOwner(context.method_8036());
        if (stack.method_57826(class_9334.field_49631) && stack.method_57824(class_9334.field_49631) != null && !stack.method_57824(class_9334.field_49631).getString().equals("")) {
            minecart.method_5665(stack.method_7964());
        }
        level.method_33596(context.method_8036(), class_5712.field_28738, pos);
		stack.method_7934(1);
		return class_1269.method_29236(level.field_9236);
	}
	
	/**
	 * Spawns a new {@link LTNTMinecart} held by this item at the given position.
	 * @param level  the current level
	 * @param x  the x position 
	 * @param y  the y position
	 * @param z  the z position
	 * @param placer  the owner of the spawned minecart (used primarely for the {@link class_1282})
	 * @return {@link LTNTMinecart} or null
	 * @throws NullPointerException
	 */
	@Nullable
	public LTNTMinecart createMinecart(class_1937 level, double x, double y, double z, @Nullable class_1309 placer) throws NullPointerException{
		if(minecart != null) {
			LTNTMinecart cart = minecart.get().get().method_5883(level);
			cart.method_5814(x, y, z);
			level.method_8649(cart);
			return cart;
		}
		throw new NullPointerException("Minecart entity type is null");
	}
}
