package luckytntlib.item;

import java.util.Random;
import java.util.function.Supplier;

import org.jetbrains.annotations.Nullable;

import luckytntlib.entity.LExplosiveProjectile;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1271;
import net.minecraft.class_1282;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2357;
import net.minecraft.class_243;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;

/**
 * The LDynamiteItem is an important step in making a custom explosive projectile.
 * It can be thrown and spawns a {@link LExplosiveProjectile} similar to an egg or a snowball.
 * If a {@link class_2357} has been registered dispensers can also throw the dynamite.
 */
public class LDynamiteItem extends class_1792{
	
	@Nullable
	protected Supplier<class_1299<LExplosiveProjectile>> dynamite;
	protected Random random = new Random();
	
	public LDynamiteItem(class_1792.class_1793 properties, @Nullable Supplier<class_1299<LExplosiveProjectile>> dynamite) {
		super(properties);
		this.dynamite = dynamite;
	}
	
	@Override
	public class_1271<class_1799> method_7836(class_1937 level, class_1657 player, class_1268 hand) {
		method_7852(level, player, player.method_5998(hand) , player.method_5998(hand).method_7947());
		return new class_1271<class_1799>(class_1269.field_5812, player.method_5998(hand));
	}
	
	@Override
	public void method_7852(class_1937 level, class_1309 player, class_1799 stack, int count) {
		if(player instanceof class_3222 sPlayer && dynamite != null) {
			shoot(level, player.method_23317(), player.method_23318() + player.method_5751(), player.method_23321(), player.method_5828(1), 2, player);		
			if(!sPlayer.method_7337()) {
				stack.method_7934(1);
			}
		}
	}
	
	/**
	 * Spawns a new {@link LExplosiveProjectile} held by this item and launches it in the given direction.
	 * @param level  the current level
	 * @param x  the x position
	 * @param y  the y position (eye level needs to be added manually!)
	 * @param z  the z position
	 * @param direction  the direction the projectile will be thrown in
	 * @param power  the power with which the projectile is thrown
	 * @param thrower  the owner for the spawned projectile (used primarely for the {@link class_1282})
	 * @return {@link LExplosiveProjectile} or null
	 * @throws NullPointerException
	 */
	@Nullable
	public LExplosiveProjectile shoot(class_1937 level, double x, double y, double z, class_243 direction, float power, @Nullable class_1309 thrower) throws NullPointerException {
		if(dynamite != null) {
			LExplosiveProjectile dyn = dynamite.get().method_5883(level);
			dyn.method_5814(x, y, z);
			dyn.method_7485(direction.field_1352, direction.field_1351, direction.field_1350, power, 0);
			dyn.setOwner(thrower);
			level.method_8649(dyn);
			level.method_8396(null, new class_2338((int)x, (int)y, (int)z), class_3417.field_14873, class_3419.field_15250, 1, 0.5f);
			return dyn;
		}
		throw new NullPointerException("Explosive projectile entity type is null");
	}
}
