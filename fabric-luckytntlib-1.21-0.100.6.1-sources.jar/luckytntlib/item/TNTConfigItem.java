package luckytntlib.item;

import luckytntlib.client.ClientAccess;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;

public class TNTConfigItem extends class_1792 {

	public TNTConfigItem() {
		super(new class_1792.class_1793().method_7889(1));
	}

	@Override
    public class_1271<class_1799> method_7836(class_1937 world, class_1657 user, class_1268 hand) {
		if(user.method_5715()) {
			return class_1271.method_22431(user.method_5998(hand));
		}
		
		if(world.field_9236) {
			ClientAccess.openConfigScreenListScreen();
		}
		
		return class_1271.method_29237(user.method_5998(hand), true);
	}
}
