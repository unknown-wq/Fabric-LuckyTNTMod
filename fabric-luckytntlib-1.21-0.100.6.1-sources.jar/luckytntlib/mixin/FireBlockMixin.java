package luckytntlib.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import luckytntlib.block.LTNTBlock;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2358;
import net.minecraft.class_2530;
import net.minecraft.class_2680;
import net.minecraft.class_5819;

/**
 * This Mixin ensures that TNT is turning into the correct TNT when it's lit by fire
 */
@Mixin(class_2358.class)
public abstract class FireBlockMixin {
	
	@Shadow
	protected abstract class_2680 getStateWithAge(class_1936 world, class_2338 pos, int age);
	
	@Shadow
	protected abstract int getSpreadChance(class_2680 state);
	
	@Inject(method = "trySpreadingFire", at = @At(value = "HEAD"), cancellable = true)
	private void redirectPrimeTnt(class_1937 world, class_2338 pos, int spreadFactor, class_5819 random, int currentAge, CallbackInfo ci) {
		class_2680 blockState = world.method_8320(pos);
        class_2248 block = blockState.method_26204();
        
        if (!(block instanceof class_2530)) {
        	return;
        }
        
		int i = getSpreadChance(world.method_8320(pos));
        if (random.method_43048(spreadFactor) < i) {
            if (random.method_43048(currentAge + 10) < 5 && !world.method_8520(pos)) {
                int j = Math.min(currentAge + random.method_43048(5) / 4, 15);
                world.method_8652(pos, getStateWithAge(world, pos, j), class_2248.field_31036);
            } else {
                world.method_8650(pos, false);
            }
            
            if (block instanceof class_2530 tnt) {
            	if(tnt instanceof LTNTBlock ltnt) {
    				ltnt.explode(world, false, pos.method_10263(), pos.method_10264(), pos.method_10260(), null);
    			} else {
                	class_2530.method_10738(world, pos);
    			}
    			world.method_8652(pos, class_2246.field_10124.method_9564(), 3);
            }
        }
        ci.cancel();
	}
}
