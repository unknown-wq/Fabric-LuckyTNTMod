package luckytntlib.mixin;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import com.llamalad7.mixinextras.sugar.Local;
import com.llamalad7.mixinextras.sugar.ref.LocalRef;

import luckytntlib.util.LuckyTNTEntityExtension;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;

/**
 * This mixin basically exists to replace the missing {@code NbtCompound Entity.persistentData} that was provided by default by Forge 
 * and was commonly used by the LuckyTNTMod to store addditional data
 */
@Mixin(class_1297.class)
public abstract class EntityMixin implements LuckyTNTEntityExtension {

	@Shadow
	@Final
	protected class_2945 dataTracker;
	
	private static final class_2940<class_2487> PERSISTENT_DATA = class_2945.method_12791(class_1297.class, class_2943.field_13318);
	
	@Inject(method = "<init>", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/Entity;initDataTracker(Lnet/minecraft/entity/data/DataTracker$Builder;)V"))
	private void injectionConstructor(class_1299<?> type, class_1937 world, CallbackInfo info, @Local(ordinal = 0) LocalRef<class_2945.class_9222> builder) {
		class_2945.class_9222 build = builder.get();
		build.method_56912(PERSISTENT_DATA, new class_2487());
		builder.set(build);
	}
	
	@Inject(method = "readNbt", at = @At("HEAD"))
	private void injectionReadNbt(class_2487 tag, CallbackInfo info) {
		setAdditionalPersistentData(tag.method_10562("AdditionalData"));
	}
	
	@Inject(method = "writeNbt", at = @At("HEAD"))
	private void injectionWriteNbt(class_2487 tag, CallbackInfoReturnable<class_2487> info) {
		tag.method_10566("AdditionalData", getAdditionalPersistentData());
	}

	@Unique
	public class_2487 getAdditionalPersistentData() {
		return dataTracker.method_12789(PERSISTENT_DATA);
	}

	@Unique
	public void setAdditionalPersistentData(class_2487 nbt) {
		dataTracker.method_49743(PERSISTENT_DATA, nbt, true);
	}
}
